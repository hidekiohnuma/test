//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

// デバッグログ
#ifdef DEBUG
    #define LOG_METHOD NSLog(@"[isMain : %d] %s", [NSThread isMainThread], __FUNCTION__)
    #define LOG(fmt, ...) NSLog(@"[isMain : %d] %s " fmt, [NSThread isMainThread], __PRETTY_FUNCTION__, ## __VA_ARGS__)
#else
    #define LOG_METHOD do {} while (0)
    #define LOG(...) do {} while (0)
#endif

// RGBA色設定
#define art_UIColorWithRGBA(r, g, b, a) [UIColor colorWithRed : ((float)r) / 255.0 green : ((float)g) / 255.0 blue : ((float)b) / 255.0 alpha : (float)(float)a]

// 確認してからブロック実行。第一引数にブロック本体を、続けてブロックに渡す引数を記述
#define art_SafeBlockCall(block, ...)      \
    do {                                   \
        if (block) { block(__VA_ARGS__); } \
    } while (0)

// バージョン判定
#define art_SystemVersonEqualOrLaterTo(v) ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)

// iPhoneか判定
#define art_isiPhone [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone

// 汎用通知
#define art_PostNotisName(__STR) [[NSNotificationCenter defaultCenter] performSelectorOnMainThread : @selector(postNotification:) withObject :[NSNotification notificationWithName:__STR object:nil] waitUntilDone : NO]

// ディレクトリパスの取得
// ドキュメント
#define ARNDocumentDirectory [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]
// ライブラリ
#define ARNLibraryDirectory [NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES) objectAtIndex:0]
// キャッシュ
#define ARNCachesDirectory [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) objectAtIndex:0]
// テンポラリ
#define ARNTempDirectory NSTemporaryDirectory()
// アプリケーションサポート
#define ARNAppSupportDirectory [NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES) objectAtIndex:0]

// GCD
#define art_main_queue   dispatch_get_main_queue()
#define art_grobal_queue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)
