//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTFavoriteView.h"

#import "ARTStaffListViewCell.h"
#import "ARTStoreListViewCell.h"

#import "ARTFavoriteUO.h"

@interface ARTFavoriteView ()

@property (nonatomic, weak) IBOutlet UIButton *staffButton;
@property (nonatomic, weak) IBOutlet UIButton *storeButton;

@property (nonatomic, strong) ARTStoreListViewCell *prototypeStoreCell;

@end

@implementation ARTFavoriteView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    __weak typeof(self) weakSelf = self;
    
    [ARTUtils addNotisForName:ARTNofiricationLogined
                        block:^(NSNotification *note) {
                            [weakSelf startUO];
                        }];
    //[ARTUtils setBaseButtonStyle:self.staffButton];
    [ARTUtils setBaseButtonStyleGray:self.staffButton];
    self.staffButton.layer.borderWidth = 1;
    //self.staffButton.layer.borderColor = [UIColor lightGrayColor].CGColor;
    self.staffButton.layer.borderColor = art_UIColorWithRGBA(220, 220, 220, 1).CGColor;
    
    //[ARTUtils setBaseButtonStyle:self.storeButton];
    [ARTUtils setBaseButtonStyleGray:self.storeButton];
    self.storeButton.layer.borderWidth = 1;
    //self.storeButton.layer.borderColor = [UIColor lightGrayColor].CGColor;
    self.storeButton.layer.borderColor = art_UIColorWithRGBA(220, 220, 220, 1).CGColor;
    
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTStaffListViewCell class]) bundle:nil]
          forCellWithReuseIdentifier:NSStringFromClass([ARTStaffListViewCell class])];
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTStoreListViewCell class]) bundle:nil]
          forCellWithReuseIdentifier:NSStringFromClass([ARTStoreListViewCell class])];
    
    self.staffButton.selected = YES;
    self.storeButton.selected = NO;
    
    [self cleateNeedLoginView];
    if (![[ARTUserManager shared] isLogined]) {
        [self dispNeedLoginView];
        return;
    }
    
    [self startUO];
}

- (void)startUO
{
    if (self.isLoading) { return; }
    self.isLoading = YES;
    
    if (self.staffButton.selected) {
        self.nothingRowText = @"登録中のスタッフはありません";
    } else {
        self.nothingRowText = @"登録中のお店はありません";
    }
    
    [ARTFavoriteUO uoGetFavoriteListWithTarget:self
                                       isStaff:self.staffButton.selected
                                        userId:[ARTUserManager shared].userId
                                         index:@(self.index)
                               completionBlock:[self uoCompletionBlock]];
}

- (NSArray *)rowDataArray
{
    if (self.staffButton.selected) {
        return [Staff art_allFavoriteEntiteis];
    } else {
        return [Shop art_allFavoriteEntiteis];
    }
}

- (void)reloadData
{
    [super reloadData];
    [[ARTViewContainer shared] showTabViewAnimationWithScrollView:self.collectionView];
}

- (IBAction)tapStaffButton:(UIButton *)sender
{
    [ARTPopping scaleAnimationWithView:self.staffButton];
    self.staffButton.selected = YES;
    self.storeButton.selected = NO;
    [self clearData];
    [self.collectionView reloadData];
    [self startUO];
    [self.collectionView setContentOffset:CGPointMake(0, 0)];
}

- (IBAction)tapStoreButton:(UIButton *)sender
{
    [ARTPopping scaleAnimationWithView:self.storeButton];
    self.staffButton.selected = NO;
    self.storeButton.selected = YES;
    [self clearData];
    [self.collectionView reloadData];
    [self startUO];
    [self.collectionView setContentOffset:CGPointMake(0, 0)];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView DataSource

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.staffButton.selected) {
        ARTStaffListViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTStaffListViewCell class])
                                                                               forIndexPath:indexPath];
        
        [cell setIndexPath:indexPath];
        Staff *staffData = self.rowData[indexPath.row];
        [cell setStaffData:staffData];
        Shop *shopData = [Shop art_shopWithShopId:staffData.shopId localContext:nil];
        [cell setShopData:shopData];
        
        __weak typeof(self) weakSelf = self;
        cell.updateCellBlock = ^(NSNumber *itemId) {
            NSMutableArray *mArray = [weakSelf.rowData mutableCopy];
            for (Staff *entity in mArray) {
                if (entity.identifier.integerValue == itemId.integerValue) {
                    [mArray removeObject:entity];
                    break;
                }
                
            }
            weakSelf.rowData = mArray;
            [weakSelf.collectionView reloadData];
        };
        
        return cell;
    } else {
        ARTStoreListViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTStoreListViewCell class])
                                                                               forIndexPath:indexPath];
        [cell setIndexPath:indexPath];
        Shop *shopData = self.rowData[indexPath.row];
        [cell setShopData:shopData];
        
        __weak typeof(self) weakSelf = self;
        cell.updateCellBlock = ^(NSNumber *itemId) {
            NSMutableArray *mArray = [weakSelf.rowData mutableCopy];
            for (Shop *entity in mArray) {
                if (entity.identifier.integerValue == itemId.integerValue) {
                    [mArray removeObject:entity];
                    break;
                }
                
            }
            weakSelf.rowData = mArray;
            [weakSelf.collectionView reloadData];
        };
        
        return cell;
    }
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionViewFlowLayout Delegate

- (CGSize)  collectionView:(UICollectionView *)collectionView
                    layout:(UICollectionViewLayout *)collectionViewLayout
    sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //return CGSizeMake(300, 175);
    return CGSizeMake(320, 280);
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView Delegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
    [ARTUtils selectActionForView:cell];
    
    if (self.staffButton.selected) {
        Staff *staffData = self.rowData[indexPath.row];
        
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory staffDetailViewControllerWithStaffId:staffData.identifier]];
    } else {
        Shop *shopData = self.rowData[indexPath.row];
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory storeDetailViewControllerWithShopId:shopData.identifier]];
    }
}

@end
