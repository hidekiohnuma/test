//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTJobPickerView : UIView

@property (nonatomic, copy) void (^doneBlock)(NSNumber *selectJobId);

- (void)setJobDataArray:(NSArray *)jobDataArray;
- (void)show;
- (void)hide;

@end
