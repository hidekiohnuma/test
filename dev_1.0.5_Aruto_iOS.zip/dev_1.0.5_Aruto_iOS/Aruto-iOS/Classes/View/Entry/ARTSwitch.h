//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTSwitch : UIView

@property (nonatomic, copy) void (^valueChangedBlock)(ARTSwitch *artSwitch);
@property (nonatomic, readonly) BOOL isOn;

- (instancetype)initWithFrame:(CGRect)frame buttonColor:(UIColor *)buttonColor;

- (void)setLeftText:(NSString *)leftText rightText:(NSString *)rightText;
- (void)setIsOn:(BOOL)isOn needAnimation:(BOOL)needAnimation;

@end
