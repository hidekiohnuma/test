//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTDayPickerView.h"

@interface ARTDayPickerView ()

@property (nonatomic, weak) IBOutlet UIDatePicker *birthDayPicker;

@end

@implementation ARTDayPickerView

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    self.alpha = 0;
}

- (void)show
{
    [UIView animateWithDuration:0.2
                     animations: ^{
         self.alpha = 1;
     }];
}

- (void)hide
{
    [self hideDayPickerAndCallBlock:NO];
}

- (void)hideDayPickerAndCallBlock:(BOOL)callBlock
{
    [UIView animateWithDuration:0.2
                     animations: ^{
         self.alpha = 0;
     } completion: ^(BOOL finished) {
         if (callBlock) {
             art_SafeBlockCall(self.doneBlock, self.birthDayPicker.date);
         }
     }];
}

- (IBAction)tapDoneButton:(UIButton *)sender
{
    [self hideDayPickerAndCallBlock:YES];
}

- (IBAction)tapCancelButton:(UIButton *)sender
{
    [self hideDayPickerAndCallBlock:NO];
}

@end
