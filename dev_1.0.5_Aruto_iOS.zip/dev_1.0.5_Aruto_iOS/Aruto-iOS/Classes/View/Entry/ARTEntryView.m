//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTEntryView.h"

#import "ARTJobPickerView.h"
#import "ARTDayPickerView.h"
#import "ARTSwitch.h"

#import "ARTEntryUO.h"

#define KM_IE_TITLE_WIDTH 100
#define KM_IE_CELL_HEIGHT 50.0f

@interface ARTEntryView () <UITextFieldDelegate>

@property (nonatomic, weak) IBOutlet UITableView *tableView;
@property (nonatomic, weak) IBOutlet UIButton    *sendButton;

@property (nonatomic, strong) UILabel          *jobLabel;
@property (nonatomic, strong) UILabel          *birthDayLabel;
@property (nonatomic, strong) ARTSwitch        *contactSwitch;
@property (nonatomic, strong) UITextField      *firstNameField;
@property (nonatomic, strong) UITextField      *lastNameField;
@property (nonatomic, strong) UITextField      *firstNameKanaField;
@property (nonatomic, strong) UITextField      *lastNameKanaField;
@property (nonatomic, strong) UITextField      *contactField;
@property (nonatomic, strong) ARTJobPickerView *jobPickerView;
@property (nonatomic, strong) ARTDayPickerView *dayPickerView;
@property (nonatomic, weak) UITextField        *activeField;

@property (nonatomic, copy) NSNumber *shopId;
@property (nonatomic, copy) NSNumber *jobId;
@property (nonatomic, assign) BOOL    isUsingPhone;
@property (nonatomic, copy) NSDate   *selectbirthDay;

@end

@implementation ARTEntryView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    self.sendButton.exclusiveTouch = YES;

    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 44, 0);

    User *entity = [User art_userForLocalContext:nil];

    if (entity && [entity.contactType isEqualToString:@"tel"]) {
        self.isUsingPhone = YES;
    } else {
        self.isUsingPhone = NO;
    }
    if (entity.birthDayDate) {
        self.selectbirthDay = entity.birthDayDate;
    }

    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:NSStringFromClass([self class])];

    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];

    __weak typeof(self) weakSelf = self;

    [nc addObserverForName:UIKeyboardWillShowNotification
                    object:nil
                     queue:[NSOperationQueue mainQueue]
                usingBlock: ^(NSNotification *note) {
         // キーボードの表示完了時の場所と大きさを取得。
         CGRect keyboardFrameEnd = [[note.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
         CGRect screenBounds = [[UIScreen mainScreen] bounds];
         float screenHeight = screenBounds.size.height;

         float fieldPosition = 50 + KM_IE_CELL_HEIGHT * weakSelf.activeField.tag;
         float keyboardHeight = screenHeight - keyboardFrameEnd.size.height - 20;

         if (fieldPosition > keyboardHeight) {
             // テキストフィールドがキーボードで隠れるようなら
             // 選択中のテキストフィールドの直ぐ下にキーボードの上端が付くように、スクロールビューの位置を上げる
             [UIView animateWithDuration:0.3
                              animations: ^{
                  weakSelf.frame = CGRectMake(0, 0 - (fieldPosition - keyboardHeight),
                      weakSelf.width,
                      weakSelf.height);
              }];
         }
     }];

    [nc addObserverForName:UIKeyboardWillHideNotification
                    object:nil
                     queue:[NSOperationQueue mainQueue]
                usingBlock: ^(NSNotification *note) {
         [UIView animateWithDuration:0.3
                          animations: ^{
              weakSelf.activeField = nil;
              weakSelf.frame = weakSelf.bounds;
          }];
     }];
}

- (void)setShopId:(NSNumber *)shopId
{
    _shopId = shopId;

    Shop *shopData = [Shop art_shopWithShopId:self.shopId localContext:nil];
    [self.parentController setHeaderImageForURL:[NSURL URLWithString:shopData.image1URL]];
}

- (IBAction)tapSendButton:(UIButton *)sender
{
    NSString *errorMsg = nil;

    if (!self.shopId) {
        errorMsg = @"応募する求人の取得に失敗しました";
    } else if (!self.jobId) {
        errorMsg = @"応募する求人を選択して下さい";
    } else if (self.firstNameField.text.length == 0) {
        errorMsg = @"氏名(姓)が入力されていません";
    } else if (self.lastNameField.text.length == 0) {
        errorMsg = @"氏名(名)が入力されていません";
    } else if (self.firstNameKanaField.text.length == 0) {
        errorMsg = @"フリガナ(姓)が入力されていません";
    } else if (self.lastNameKanaField.text.length == 0) {
        errorMsg = @"フリガナ(名)が入力されていません";
    } else if (!self.selectbirthDay) {
        errorMsg = @"生年月日が選択されていません";
    } else if (self.isUsingPhone && self.contactField.text.length == 0) {
        errorMsg = @"電話番号が入力されていません";
    }

    if (errorMsg) {
        [ARNAlert showNoActionAlertWithTitle:nil
                                     message:errorMsg
                                 buttonTitle:nil];
        return;
    }

    if (![[ARTUserManager shared] isLogined]) {
        [ARNAlert showNoActionAlertWithTitle:nil
                                     message:@"応募にはログインする必要があります"
                                 buttonTitle:nil];
        [[ARTViewContainer shared] showUserAuthModalView];
        return;
    }

    NSString *contactType = @"";
    NSString *phoneNumber = @"";
    if (self.isUsingPhone) {
        phoneNumber = self.contactField.text;
        contactType = @"2";
    } else {
        contactType = @"1";
    }

    [self showIndicator];

    __weak typeof(self) weakSelf = self;

    [ARTEntryUO uoPostEntryListWithTarget:self
                                   userId:[ARTUserManager shared].userId
                                    jobId:self.jobId
                              contactType:contactType
                                firstName:self.firstNameField.text
                                 lastName:self.lastNameField.text
                            firstNameKana:self.firstNameKanaField.text
                             lastNameKana:self.lastNameKanaField.text
                              phoneNumber:phoneNumber
                                 birthday:[self.selectbirthDay art_stringWithFormatYYYYMMDD_HHMMSS]
                          completionBlock: ^(id resultObject) {
         [weakSelf hideIndicator];
         if (!weakSelf) { return; }

         if ([resultObject isKindOfClass:[NSError class]]) {
             NSError *error = (NSError *)resultObject;
             [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                          message:error.localizedFailureReason
                                      buttonTitle:nil];
             
         } else {
             [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory entryFinishViewController]];
         }
     }];
}

- (UITextField *)cellTextField
{
    UITextField *field = [[UITextField alloc] initWithFrame:CGRectMake(KM_IE_TITLE_WIDTH, 0, self.width - KM_IE_TITLE_WIDTH - 5, KM_IE_CELL_HEIGHT)];
    field.delegate                  = self;
    field.font                      = [UIFont fontWithName:@"HelveticaNeue-Light" size:15];
    field.contentVerticalAlignment  = UIControlContentVerticalAlignmentCenter;
    field.textColor                 = [UIColor darkGrayColor];
    field.backgroundColor           = [UIColor clearColor];
    field.returnKeyType             = UIReturnKeyDone;
    field.adjustsFontSizeToFitWidth = YES;

    field.inputAccessoryView = [ARTUtils keyboardToolbarWithTarget:self selector:@selector(art_closeKeyboad) width:self.width];

    return field;
}

- (void)showJobPicker
{
    if (!self.jobPickerView) {
        self.jobPickerView       = [ARTJobPickerView art_createViewByNib];
        self.jobPickerView.frame = self.bounds;

        NSArray *jobArray = [Job art_jobListForShopId:self.shopId];
        [self.jobPickerView setJobDataArray:jobArray];

        __weak typeof(self) weakSelf = self;

        self.jobPickerView.doneBlock = ^(NSNumber *selectJobId) {
            weakSelf.jobId = selectJobId;
            Job *entity = [Job art_jobWithJobId:selectJobId localContext:nil];
            weakSelf.jobLabel.text = [JobType art_nameForId:entity.jobTypeId];
        };
        [self addSubview:self.jobPickerView];
    }
    [self.jobPickerView show];
}

- (void)showDayPicker
{
    if (!self.dayPickerView) {
        self.dayPickerView       = [ARTDayPickerView art_createViewByNib];
        self.dayPickerView.frame = self.bounds;

        __weak typeof(self) weakSelf = self;

        self.dayPickerView.doneBlock = ^(NSDate *selectDate) {
            weakSelf.birthDayLabel.text = [selectDate art_stringWithFormatJapaneseYYYYMD];
            weakSelf.selectbirthDay     = selectDate;
        };
        [self addSubview:self.dayPickerView];
    }
    [self.dayPickerView show];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UITableView DataSource

// セクション数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

// セクションのセル数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (self.isUsingPhone) {
        return 8;
    }
    return 7;
}

// セルの表示内容
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class]) forIndexPath:indexPath];

    cell.textLabel.font      = [UIFont fontWithName:@"HelveticaNeue-Light" size:14];
    cell.textLabel.textColor = [UIColor darkGrayColor];
    cell.clipsToBounds       = YES;
    cell.selectionStyle      = UITableViewCellSelectionStyleNone;

    UIView *line = [[UIView alloc] init];
    line.backgroundColor = art_UIColorWithRGBA(226, 216, 214, 1);
    line.frame           = CGRectMake(0, 49.5, self.width, 0.5);
    [cell addSubview:line];

    User *entity = [User art_userForLocalContext:nil];

    if (indexPath.row == 0) {
        cell.textLabel.text = @"応募求人";
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        if (!self.jobLabel) {
            self.jobLabel                 = [[UILabel alloc] initWithFrame:CGRectMake(KM_IE_TITLE_WIDTH, 0, self.width - KM_IE_TITLE_WIDTH - 5, KM_IE_CELL_HEIGHT)];
            self.jobLabel.font            = [UIFont fontWithName:@"HelveticaNeue-Light" size:15];
            self.jobLabel.textColor       = [UIColor darkGrayColor];
            self.jobLabel.backgroundColor = [UIColor clearColor];
            self.jobLabel.text            = @"応募する求人を選択";
            if (self.jobId) {
                self.jobLabel.text = [JobType art_nameForId:self.jobId];
            }
            [cell.contentView addSubview:self.jobLabel];
        }
    } else if (indexPath.row == 1) {
        cell.textLabel.text = @"氏名(姓)";
        if (!self.firstNameField) {
            self.firstNameField             = [self cellTextField];
            self.firstNameField.tag         = indexPath.row + 1;
            self.firstNameField.placeholder = @"氏名(姓)を入力";
            if (entity) {
                self.firstNameField.text = entity.firstName;
            }
            [cell.contentView addSubview:self.firstNameField];
        }
    } else if (indexPath.row == 2) {
        cell.textLabel.text = @"氏名(名)";
        if (!self.lastNameField) {
            self.lastNameField             = [self cellTextField];
            self.lastNameField.tag         = indexPath.row + 1;
            self.lastNameField.placeholder = @"氏名(名)を入力";
            if (entity) {
                self.lastNameField.text = entity.lastName;
            }
            [cell.contentView addSubview:self.lastNameField];
        }
    } else if (indexPath.row == 3) {
        cell.textLabel.text = @"フリガナ(姓)";
        if (!self.firstNameKanaField) {
            self.firstNameKanaField             = [self cellTextField];
            self.firstNameKanaField.tag         = indexPath.row + 1;
            self.firstNameKanaField.placeholder = @"フリガナ(姓)を入力";
            if (entity) {
                self.firstNameKanaField.text = entity.firstNameKana;
            }
            [cell.contentView addSubview:self.firstNameKanaField];
        }
    } else if (indexPath.row == 4) {
        cell.textLabel.text = @"フリガナ(名)";
        if (!self.lastNameKanaField) {
            self.lastNameKanaField             = [self cellTextField];
            self.lastNameKanaField.tag         = indexPath.row + 1;
            self.lastNameKanaField.placeholder = @"フリガナ(名)を入力";
            if (entity) {
                self.lastNameKanaField.text = entity.lastNameKana;
            }
            [cell.contentView addSubview:self.lastNameKanaField];
        }
    } else if (indexPath.row == 5) {
        cell.textLabel.text = @"生年月日";
        cell.selectionStyle = UITableViewCellSelectionStyleGray;
        if (!self.birthDayLabel) {
            self.birthDayLabel                 = [[UILabel alloc] initWithFrame:CGRectMake(KM_IE_TITLE_WIDTH, 0, self.width - KM_IE_TITLE_WIDTH - 5, KM_IE_CELL_HEIGHT)];
            self.birthDayLabel.font            = [UIFont fontWithName:@"HelveticaNeue-Light" size:15];
            self.birthDayLabel.textColor       = [UIColor darkGrayColor];
            self.birthDayLabel.backgroundColor = [UIColor clearColor];
            self.birthDayLabel.text            = @"生年月日を選択";
            if (self.selectbirthDay) {
                self.birthDayLabel.text = [self.selectbirthDay art_stringWithFormatJapaneseYYYYMD];
            }
            [cell.contentView addSubview:self.birthDayLabel];
        }
    } else if (indexPath.row == 6) {
        cell.textLabel.text = @"連絡方法";
        if (!self.contactSwitch) {
            self.contactSwitch = [[ARTSwitch alloc] initWithFrame:CGRectMake(KM_IE_TITLE_WIDTH, 10, self.width - KM_IE_TITLE_WIDTH - 10, 30)
                                                      buttonColor:art_UIColorWithRGBA(243, 182, 80, 1)];
            [self.contactSwitch setLeftText:@"メッセージ" rightText:@"電話"];
            if (self.isUsingPhone) {
                [self.contactSwitch setIsOn:NO needAnimation:NO];
            } else {
                [self.contactSwitch setIsOn:YES needAnimation:NO];
            }

            __weak typeof(self) weakSelf = self;

            self.contactSwitch.valueChangedBlock = ^(ARTSwitch *aSwitch) {
                if (weakSelf.isUsingPhone == !aSwitch.isOn) { return; }

                [weakSelf art_closeKeyboad];
                weakSelf.isUsingPhone      = !aSwitch.isOn;
                weakSelf.contactField.text = nil;
                if (weakSelf.isUsingPhone) {
                    [weakSelf.tableView insertRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:7 inSection:0]]
                                              withRowAnimation:UITableViewRowAnimationFade];
                } else {
                    [weakSelf.tableView deleteRowsAtIndexPaths:@[[NSIndexPath indexPathForRow:7 inSection:0]]
                                              withRowAnimation:UITableViewRowAnimationFade];
                }
            };

            [cell.contentView addSubview:self.contactSwitch];
        }
    } else if (indexPath.row == 7) {
        cell.textLabel.text = @"連絡先";
        if (!self.contactField) {
            self.contactField     = [self cellTextField];
            self.contactField.tag = indexPath.row + 1;
            [cell.contentView addSubview:self.contactField];
            self.contactField.placeholder  = @"電話番号を入力";
            self.contactField.keyboardType = UIKeyboardTypeNumberPad;
            if (entity) {
                self.contactField.text = entity.tel;
            }
        }
    }

    return cell;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UITableView Delegate

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell.backgroundColor = [UIColor clearColor];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        [self art_closeKeyboad];
        [self showJobPicker];
    } else if (indexPath.row == 5) {
        [self art_closeKeyboad];
        [self showDayPicker];
    }

    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UITextField Delegate

// キーボードのreturnキーを押したときの処理
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self art_closeKeyboad];
    return YES;
}

// テキストフィールドへフォーカスされた時に起動
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    _activeField = textField;
}

@end
