//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTJobPickerView.h"

@interface ARTJobPickerView ()

@property (nonatomic, weak) IBOutlet UIPickerView *jobPicker;

@property (nonatomic, strong) NSArray *rowData;
@property (nonatomic, copy) NSNumber  *selectJobId;

@end

@implementation ARTJobPickerView

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    self.alpha = 0;
}

- (void)setJobDataArray:(NSArray *)jobDataArray
{
    if (!jobDataArray || jobDataArray.count == 0) { return; }

    self.rowData = jobDataArray;
    [self.jobPicker reloadAllComponents];

    Job *entity = self.rowData[0];
    self.selectJobId = entity.identifier;
}

- (void)show
{
    [UIView animateWithDuration:0.2
                     animations: ^{
         self.alpha = 1;
     }];
}

- (void)hide
{
    [self hideDayPickerAndCallBlock:NO];
}

- (void)hideDayPickerAndCallBlock:(BOOL)callBlock
{
    [UIView animateWithDuration:0.2
                     animations: ^{
         self.alpha = 0;
     } completion: ^(BOOL finished) {
         if (callBlock) {
             art_SafeBlockCall(self.doneBlock, self.selectJobId);
         }
     }];
}

- (IBAction)tapDoneButton:(UIButton *)sender
{
    [self hideDayPickerAndCallBlock:YES];
}

- (IBAction)tapCancelButton:(UIButton *)sender
{
    [self hideDayPickerAndCallBlock:NO];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UIPickerView Datasource

// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return self.rowData.count;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UIPickerView Delegate

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    Job *entity = self.rowData[row];
    return [JobType art_nameForId:entity.jobTypeId];
}

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    Job *entity = self.rowData[row];
    self.selectJobId = entity.identifier;
}

@end
