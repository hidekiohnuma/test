//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSwitch.h"

@interface ARTSwitch ()

@property (nonatomic, strong) UIView  *buttonView;
@property (nonatomic, strong) UILabel *leftLabel;
@property (nonatomic, strong) UILabel *rightLabel;

@property (nonatomic, readwrite) BOOL isOn;

@end

@implementation ARTSwitch

- (void)dealloc
{
    LOG_METHOD;
    while (self.gestureRecognizers.count) {
        [self removeGestureRecognizer:[self.gestureRecognizers objectAtIndex:0]];
    }
}

- (instancetype)initWithFrame:(CGRect)frame buttonColor:(UIColor *)buttonColor
{
    if (!(self = [super initWithFrame:frame])) { return nil; }

    self.clipsToBounds      = YES;
    self.backgroundColor    = [UIColor whiteColor];
    self.layer.borderColor  = buttonColor.CGColor;
    self.layer.borderWidth  = 1;
    self.layer.cornerRadius = frame.size.height / 6;

    self.buttonView                 = [[UIView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width / 2, frame.size.height)];
    self.buttonView.clipsToBounds   = YES;
    self.buttonView.backgroundColor = buttonColor;
    [self addSubview:_buttonView];

    self.leftLabel                 = [[UILabel alloc] initWithFrame:_buttonView.frame];
    self.leftLabel.backgroundColor = [UIColor clearColor];
    self.leftLabel.textAlignment   = NSTextAlignmentCenter;
    self.leftLabel.font            = [UIFont fontWithName:@"HelveticaNeue-Light" size:15];
    [self addSubview:_leftLabel];

    self.rightLabel                 = [[UILabel alloc] initWithFrame:CGRectMake(_leftLabel.right, 0, frame.size.width / 2, frame.size.height)];
    self.rightLabel.backgroundColor = [UIColor clearColor];
    self.rightLabel.textAlignment   = NSTextAlignmentCenter;
    self.rightLabel.font            = [UIFont fontWithName:@"HelveticaNeue-Light" size:15];
    [self addSubview:_rightLabel];

    UIPanGestureRecognizer *panGestureRecognizer = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(dragView:)];
    [self addGestureRecognizer:panGestureRecognizer];

    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapView:)];
    [self addGestureRecognizer:tapGestureRecognizer];

    return self;
}

- (void)setLeftText:(NSString *)leftText rightText:(NSString *)rightText
{
    self.leftLabel.text  = leftText;
    self.rightLabel.text = rightText;
}

- (void)setIsOn:(BOOL)isOn needAnimation:(BOOL)needAnimation
{
    self.isOn = isOn;
    if (!needAnimation) {
        if (isOn) {
            self.buttonView.left      = 0;
            self.leftLabel.textColor  = [UIColor whiteColor];
            self.rightLabel.textColor = ART_BaseColor_Orange;
        } else {
            self.buttonView.right     = self.width;
            self.leftLabel.textColor  = ART_BaseColor_Orange;
            self.rightLabel.textColor = [UIColor whiteColor];
        }
        return;
    }

    [UIView animateWithDuration:0.15 animations: ^{
         if (isOn) {
             self.buttonView.left = 0;
             self.leftLabel.textColor = [UIColor whiteColor];
             self.rightLabel.textColor = ART_BaseColor_Orange;
         } else {
             self.buttonView.right = self.width;
             self.leftLabel.textColor = ART_BaseColor_Orange;
             self.rightLabel.textColor = [UIColor whiteColor];
         }
     } completion: ^(BOOL finished) {
         art_SafeBlockCall(self.valueChangedBlock, self);
     }];
}

- (void)dragView:(UIPanGestureRecognizer *)sender
{
    UIView *targetView = sender.view;
    CGPoint p          = [sender translationInView:targetView];
    float   positionX  = p.x;
    if (sender.state == UIGestureRecognizerStateChanged) {
        if (positionX > 0) {
            if (positionX >= self.width / 2) {
                positionX = self.width / 2;
            }
            _buttonView.left = positionX;
        } else {
            positionX = self.width / 2 + positionX;
            if (positionX < 0) {
                positionX = 0;
            }
            _buttonView.left = positionX;
        }
    }

    if (sender.state == UIGestureRecognizerStateEnded) {
        if (_isOn) {
            if (_buttonView.left >= self.width / 4) {
                [self setIsOn:NO needAnimation:YES];
            } else {
                [self setIsOn:YES needAnimation:YES];
            }
        } else {
            if (_buttonView.right >= (self.width / 4) * 3) {
                [self setIsOn:NO needAnimation:YES];
            } else {
                [self setIsOn:YES needAnimation:YES];
            }
        }
    }
}

- (void)tapView:(UITapGestureRecognizer *)sender
{
    UIView *targetView = sender.view;
    CGPoint p          = [sender locationInView:targetView];
    float   positionX  = p.x;

    if (positionX >= (self.width / 2)) {
        if (self.isOn == YES) {
            [self setIsOn:NO needAnimation:YES];
        }
    } else {
        if (self.isOn == NO) {
            [self setIsOn:YES needAnimation:YES];
        }
    }
}

@end
