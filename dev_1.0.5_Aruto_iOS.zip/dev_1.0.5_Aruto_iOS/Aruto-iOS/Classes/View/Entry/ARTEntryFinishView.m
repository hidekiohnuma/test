//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTEntryFinishView.h"

@interface ARTEntryFinishView ()

@property (nonatomic, weak) IBOutlet UIButton *myPageButton;

@end

@implementation ARTEntryFinishView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    self.myPageButton.exclusiveTouch     = YES;
    self.myPageButton.layer.cornerRadius = 5;
}

- (IBAction)tapMyPageButton:(UIButton *)sender
{
    [[ARTViewContainer shared] setTopController:[ARTViewControllerFactory myPageViewController]
                                     needToggle:YES];
}

@end
