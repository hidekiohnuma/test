//  Copyright (c) 2015年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

//@interface ARTSpecialEditionDetailView : ARTBaseListView<UICollectionViewDataSource,UICollectionViewDelegate>
@interface ARTSpecialEditionDetailView : ARTBaseListView

- (void)setBlogSelectedItem:(NSString *)selectedItem;

@property NSArray* items;
@property NSString *svStr;
//@property (strong, nonatomic) IBOutlet UICollectionView *collectionView;

@property (strong, nonatomic) IBOutlet UIView *blogView;
@property (strong, nonatomic) IBOutlet UIScrollView *blogScroll;

//@property (strong, nonatomic) IBOutlet UIImageView *imageView;

//- (IBAction)shopInfoButton;

@end