//  Copyright (c) 2015年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTSpecialEditionListView : ARTBaseListView

//- (void)setBlogData:(Blog *)blogData;

@end
