// 特集一覧
//  Copyright (c) 2015年 Aruto Corp. All rights reserved.

#import "ARTSpecialEditionView.h"
#import "ARTSpecialEditionDetailView.h"

@interface ARTSpecialEditionView (){
    IBOutlet UIButton *topButton;
    NSString* selectedItem;
}

@end

@implementation ARTSpecialEditionView

- (void)deallocChild
{
    LOG_METHOD;
}


- (void)awakeFromNib
{
    [super awakeFromNib];
    
    // scroll
    _scroll.contentSize = CGSizeMake(320, 600);
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    // 空の配列を用意
    self.items = [NSArray array];
    
    // キャッシュ全削除
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
    
    // workLocationTitle
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    // add Id
    NSString *prefectureAreaSelectedId = [ud stringForKey:@"prefectureAreaSelectedId"];
    NSString *prefectureAreaIdTitle = [ud stringForKey:@"prefectureAreaId"];
    
    if(prefectureAreaIdTitle != nil){
        self.workLocationTitle.text = prefectureAreaIdTitle;
    }else{
        self.workLocationTitle.hidden = YES; //　エリア未選択時非表示
    }

    [self getJSON];
    
}

- (void)getJSON
{
    // getId
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSString *prefectureAreaSelectedId = [ud stringForKey:@"prefectureAreaSelectedId"];
    
    // url取得
    NSURL *url = [NSURL URLWithString:[ARTBaseURL stringByAppendingFormat:@"blog/list/?prefecture_area_id=%@",prefectureAreaSelectedId]];
    // bk
//    NSURL *url = [NSURL URLWithString:[ARTBaseURL stringByAppendingString:@"blog/list.json"]];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        
        NSDictionary *jsonDictionary = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        
        // アプリデータの配列をプロパティに保持
        self.items = [jsonDictionary objectForKey:@"Blogs"];
        
        // TableView をリロード
        [self.tableView reloadData];
    }];
}

// セルの数を設定
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.items count];
}

// セルの高さ設定
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 300.0f;
}
// テーブルセルの内容を設定
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    NSDictionary *item = [self.items objectAtIndex:indexPath.row];
    

    cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    cell.accessoryType = UITableViewCellAccessoryNone;
    
    // blog title
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(15,10,265,36)];
    label.font = [UIFont fontWithName:@"AppleGothic" size:13];
    label.font = [UIFont boldSystemFontOfSize:13];
    label.numberOfLines = 2;
    label.text = [[item objectForKey:@"Blog"] objectForKey:@"post_title"];
    [cell addSubview:label];
    
    //画像スムーズスクロール
    dispatch_queue_t q_global = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_queue_t q_main = dispatch_get_main_queue();
    
    dispatch_async(q_global, ^{
        NSString *imageURL = [[item objectForKey:@"Blog"] objectForKey:@"thumbnail_url"];
        UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfURL: [NSURL URLWithString: imageURL]]];
        
        dispatch_async(q_main, ^{
            UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(20,40, 290, 210)];
            imageView.image = image;
            
            //アクセサリービューにイメージを設定
            cell.accessoryView = imageView;
            [cell setNeedsLayout];
        });
    });
    
    return cell;
}

// tap action
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *item = [self.items objectAtIndex:indexPath.row];
    selectedItem = [[item objectForKey:@"Blog"] objectForKey:@"ID"];
    
    //詳細画面へ遷移 引数：selectedItem
    [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory specialEditionDetailView:selectedItem]];
        
    // 選択状態の解除
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)buttonTouchUpInsideEvent:(id)sender
{
    UIButton *button = (UIButton *)sender;
    
    // buttonに格納された値をNumber化
    NSInteger num = button.tag;
    NSString *shopId=[[NSString alloc] initWithFormat:@"%@",num];
    
    [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory storeDetailViewControllerWithShopId:shopId]];
}

// prefecture area button action
- (IBAction)topButton:(id)sender {
    // 特集画面へ遷移
    [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory prefectureAreaChangeView]];

}

@end
