//  Copyright (c) 2015年 Aruto Corp. All rights reserved.
#import <UIKit/UIKit.h>

@interface ARTSpecialEditionView : ARTBaseListView<UITableViewDelegate, UITableViewDataSource>

//テーブルの一覧にセットする配列
@property NSArray* items;

@property (weak, nonatomic) IBOutlet UITableView *tableView;
// 勤務地エリアボタン3次開発より実装
//@property (strong, nonatomic) IBOutlet UIButton *changeButton;
@property (strong, nonatomic) IBOutlet UILabel *workLocationTitle;
@property (nonatomic, weak) IBOutlet UILabel     *notFoundLabel;
@property (nonatomic, weak) IBOutlet UIImageView *notFoundImageView;
@property (strong, nonatomic) IBOutlet UIScrollView *scroll;


- (IBAction)topButton:(id)sender;

@end