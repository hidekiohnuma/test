//  Copyright (c) 2015年 Aruto Corp. All rights reserved.

#import "ARTSpecialEditionListView.h"

#import "ARTStaffListViewCell.h"
#import "ARTStoreListViewCell.h"

#import "ARTBlogUO.h"
#import "ARTRankUO.h"

@interface ARTSpecialEditionListView ()

@property (nonatomic, strong) ARTStaffListViewCell *prototypeCell;

@property (nonatomic, assign) ARTRankListType listType;


@end

@implementation ARTSpecialEditionListView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
//    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTStaffListViewCell class]) bundle:nil]
//          forCellWithReuseIdentifier:NSStringFromClass([ARTStaffListViewCell class])];
    
    self.nothingRowText = @"特集情報を取得できませんでした";
}
//- (void)setBlogData:(Blog *)blogData
//{
//    
//    
//}

//- (void)setRankType:(ARTRankListType)rankType
//{
//    self.listType = rankType;
//    
//    if ([[ARTUOCacheManager shared] isAlreadyRankUOForlistType:rankType]) {
//        [self reloadData];
//        if (!self.rowData || self.rowData.count == 0) {
//            [self startUO];
//        }
//    } else {
//        [self startUO];
//    }
//}

- (ARTStaffListViewCell *)prototypeCell
{
    if (!_prototypeCell) {
        _prototypeCell = [ARTStaffListViewCell art_createViewByNib];
    }
    return _prototypeCell;
}

- (void)startUO
{
    if (self.isLoading) { return; }
    self.isLoading = YES;
    
    [ARTRankUO uoGetRankListWithTarget:self
                              listType:self.listType
                       completionBlock:[self uoCompletionBlock]];
}

- (void)reloadData
{
    // 現状、ランキング系は20件固定だからこんな感じ
    self.rowData = [Staff art_staffListForListType:self.listType];
    self.index = 999;
    [self.collectionView reloadData];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView DataSource

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    ARTStaffListViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTStaffListViewCell class])
                                                                           forIndexPath:indexPath];
    
    [cell setIndexPath:indexPath];
    Staff *staffData = self.rowData[indexPath.row];
    [cell setStaffData:staffData];
    Shop *shopData = [Shop art_shopWithShopId:staffData.shopId localContext:nil];
    [cell setShopData:shopData];
    
    return cell;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionViewFlowLayout Delegate

- (CGSize)  collectionView:(UICollectionView *)collectionView
                    layout:(UICollectionViewLayout *)collectionViewLayout
    sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //return CGSizeMake(300, 175);
    //return CGSizeMake(320, 175);
    return CGSizeMake(320, 280);
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView Delegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
    [ARTUtils selectActionForView:cell];
    
    Staff *staffData = self.rowData[indexPath.row];
    
    [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory staffDetailViewControllerWithStaffId:staffData.identifier]];
}

@end
