//  特集詳細
//  Copyright (c) 2015年 Aruto Corp. All rights reserved.

#import "ARTSpecialEditionDetailView.h"
#import "ARTStaffListViewCell.h"
#import "ARTStoreListViewCell.h"

@interface ARTSpecialEditionDetailView ()

@property (strong, nonatomic) IBOutlet UIImageView *blogViewFirst;
@property (strong, nonatomic) IBOutlet UILabel *blogTitle;
@property (strong, nonatomic) IBOutlet UITextView *textView;

@property (strong, nonatomic) IBOutlet UIImageView *blogViewSecond;
@property (strong, nonatomic) IBOutlet UILabel *blogTitleSecond;
@property (strong, nonatomic) IBOutlet UITextView *textViewSecond;

@property (strong, nonatomic) IBOutlet UIImageView *blogViewThird;
@property (strong, nonatomic) IBOutlet UILabel *blogTitleThird;
@property (strong, nonatomic) IBOutlet UITextView *textViewThird;

@end

@implementation ARTSpecialEditionDetailView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    // scroll
    self.blogScroll.contentSize = CGSizeMake(320, 1380);
}

- (void)setBlogSelectedItem:(NSString *)selectedItem
{
    NSURL *url = [NSURL URLWithString:[ARTBaseURL stringByAppendingFormat:@"blog/list/?ID=%@",selectedItem]];

    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        
        NSDictionary *jsonDictionary = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        // アプリデータの配列をプロパティに保持
        self.items = [jsonDictionary objectForKey:@"Blogs"];
        
        // ブログ記事(特集)
        NSDictionary *item = [self.items objectAtIndex:0];
        LOG(@"%@",item);
        // 画像 top
        if([[[item objectForKey:@"Blog"] objectForKey:@"post_content"] objectForKey:@"image-top"] != nil)
        {
            NSString *imageURL = [[[item objectForKey:@"Blog"] objectForKey:@"post_content"] objectForKey:@"image-top"];
            UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfURL: [NSURL URLWithString: imageURL]]];
            _blogViewFirst.image = image;

        }else{
            NSString *imageURL = [[item objectForKey:@"Blog"] objectForKey:@"thumbnail_url"];
            UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfURL: [NSURL URLWithString: imageURL]]];
            _blogViewFirst.image = image;

        }
        
        self.blogTitle.font = [UIFont fontWithName:@"AppleGothic" size:15];
        self.blogTitle.font = [UIFont boldSystemFontOfSize:15];
        self.blogTitle.text = [[item objectForKey:@"Blog"] objectForKey:@"post_title"];
        self.blogTitle.numberOfLines = 2;
        if([[[item objectForKey:@"Blog"] objectForKey:@"post_content"] objectForKey:@"shop-feature"] != nil){
            self.textView.text = [[[item objectForKey:@"Blog"] objectForKey:@"post_content"] objectForKey:@"shop-feature"];
        }
        // 画像 middle
        if([[[item objectForKey:@"Blog"] objectForKey:@"post_content"] objectForKey:@"image-middle"] != nil)
        {
            NSString *imageURLSecond = [[[item objectForKey:@"Blog"] objectForKey:@"post_content"] objectForKey:@"image-middle"];
            UIImage *imageSecond = [UIImage imageWithData:[NSData dataWithContentsOfURL: [NSURL URLWithString: imageURLSecond]]];
            _blogViewSecond.image = imageSecond;
        }else{
            NSString *imageURLSecond = [[item objectForKey:@"Blog"] objectForKey:@"thumbnail_url"];
            UIImage *imageSecond = [UIImage imageWithData:[NSData dataWithContentsOfURL: [NSURL URLWithString: imageURLSecond]]];
            _blogViewSecond.image = imageSecond;
        }
        
        
        self.blogTitleSecond.font = [UIFont fontWithName:@"AppleGothic" size:13];
        self.blogTitleSecond.font = [UIFont boldSystemFontOfSize:15];
        self.blogTitleSecond.text = [[item objectForKey:@"Blog"] objectForKey:@"post_title"];
        self.blogTitleSecond.numberOfLines = 2;
        
        if([[[item objectForKey:@"Blog"] objectForKey:@"post_content"] objectForKey:@"shop-detail"] != nil){
            self.textViewSecond.text = [[[item objectForKey:@"Blog"] objectForKey:@"post_content"] objectForKey:@"shop-detail"];
        }
        // 画像 bottom
        if([[[item objectForKey:@"Blog"] objectForKey:@"post_content"] objectForKey:@"image-bottom"] != nil)
        {
            NSString *imageURLThird = [[[item objectForKey:@"Blog"] objectForKey:@"post_content"] objectForKey:@"image-bottom"];
            UIImage *imageThird = [UIImage imageWithData:[NSData dataWithContentsOfURL: [NSURL URLWithString: imageURLThird]]];
            _blogViewThird.image = imageThird;
            
        }else{
            NSString *imageURLThird = [[item objectForKey:@"Blog"] objectForKey:@"thumbnail_url"];
            UIImage *imageThird = [UIImage imageWithData:[NSData dataWithContentsOfURL: [NSURL URLWithString: imageURLThird]]];
            _blogViewThird.image = imageThird;
            
        }
        
        self.blogTitleThird.font = [UIFont fontWithName:@"AppleGothic" size:13];
        self.blogTitleThird.font = [UIFont boldSystemFontOfSize:15];
        self.blogTitleThird.text = [[item objectForKey:@"Blog"] objectForKey:@"post_title"];
        self.blogTitleThird.numberOfLines = 2;
        
        if([[[item objectForKey:@"Blog"] objectForKey:@"post_content"] objectForKey:@"shop-recommend"] != nil){
            self.textViewThird.text = [[[item objectForKey:@"Blog"] objectForKey:@"post_content"] objectForKey:@"shop-recommend"];
        }
        
        // button set
        UIButton *button = [UIButton buttonWithType:UIButtonTypeRoundedRect];
        [button setBackgroundColor:[UIColor orangeColor]];
        // 透過設定(orange)
        [button setBackgroundColor:[UIColor colorWithRed: (255.0)/255.0 green: (165.0)/255.0 blue: (0.0)/255.0 alpha: 1.0]];
        [button setTintColor:[UIColor whiteColor]];
        [button setTitle:@"お店、求人を見る" forState:UIControlStateNormal];
        [button setTitle:@"お店、求人を見る" forState:UIControlStateHighlighted];
        // 配置に関して実機で確認し調整
        [button setFrame:CGRectMake((self.blogView.frame.size.width / 2) - (320 / 2),
                                    (self.blogView.frame.size.height / 2) + 210 ,
                                    320,
                                    44)];
        
        button.tag = [[item objectForKey:@"Blog"] objectForKey:@"shop_id"];
        //ボタンイベント定義
        [button addTarget:self action:@selector(buttonTouchUpInsideEvent:)
         forControlEvents:UIControlEventTouchUpInside];
        //ボタンをステージに追加
        [self.blogView addSubview:button];
    }];
}

// 店舗詳細へ値渡す
- (void)buttonTouchUpInsideEvent:(id)sender
{
    UIButton *button = (UIButton *)sender;

    // buttonに格納された値をNumber化
    NSInteger num = button.tag;
    NSString *shopId=[[NSString alloc] initWithFormat:@"%@",num];

    [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory storeDetailViewControllerWithShopId:shopId]];
}

@end