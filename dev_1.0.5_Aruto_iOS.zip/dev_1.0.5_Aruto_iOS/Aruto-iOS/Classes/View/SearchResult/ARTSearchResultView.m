//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSearchResultView.h"

#import "ARTStaffListViewCell.h"
#import "ARTStoreListViewCell.h"

#import "ARTCustomCollectionViewLayout.h"

@interface ARTSearchResultView ()

@property (nonatomic, weak) IBOutlet UILabel     *notFoundLabel;
@property (nonatomic, weak) IBOutlet UIImageView *notFoundImageView;
@property (nonatomic, weak) IBOutlet UIView      *totalCountView;
@property (nonatomic, weak) IBOutlet UILabel     *totalCountLabel;

@property (nonatomic, strong) ARTStoreListViewCell *prototypeStoreCell;

@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentCtrl;
@end

@implementation ARTSearchResultView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    self.nothingRowText = @"";

    self.collectionView.contentInset = UIEdgeInsetsMake(30, 0, 50, 0);

    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTStaffListViewCell class]) bundle:nil]
          forCellWithReuseIdentifier:NSStringFromClass([ARTStaffListViewCell class])];
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTStoreListViewCell class]) bundle:nil]
          forCellWithReuseIdentifier:NSStringFromClass([ARTStoreListViewCell class])];

    self.totalCountLabel.adjustsFontSizeToFitWidth = YES;
    
    self.segmentCtrl.selectedSegmentIndex = !ARTSearchManager.shared.isStaffSearch;
    self.segmentCtrl.tintColor = ART_BaseColor_Orange;

    __weak typeof(self) weakSelf = self;
    
    [ARTUtils addNotisForName:ARTNofiricationSearched
                        block:^(NSNotification *note) {
                            [weakSelf reloadData];
                        }];
    // TODO : 実験
//    ARTCustomCollectionViewLayout *viewLayout = ARTCustomCollectionViewLayout.new;
//    viewLayout.cellSize = CGSizeMake(300, 175);
//    [self.collectionView setCollectionViewLayout:viewLayout animated:NO];
}

- (void)setting
{
    [self reloadData];
    
    if (self.rowData.count < ART_UO_Index_Interval) {
        self.canNextCall = NO;
    }
}

- (void)startUO
{
    if (self.isLoading) { return; }
    self.isLoading = YES;
    
    [[ARTSearchManager shared] startMoreLoadWithCompletionBlock:[self uoCompletionBlock]
                                                          index:self.index];
}

- (NSArray *)rowDataArray
{
    if (ARTSearchManager.shared.isStaffSearch) {
        return [Staff art_searchResultEntities];
    } else {
        return [Shop art_searchResultEntities];
    }
}

- (void)reloadData
{
    [super reloadData];
    [self notFoundLabelIsShowOfHide];
    
    // 要チェック※人とお店を切り替える前は入っていなかった。ARTFavoriteView.mを参考
    [[ARTViewContainer shared] showTabViewAnimationWithScrollView:self.collectionView];
}

- (void)notFoundLabelIsShowOfHide
{
    if (!self.rowData || self.rowData.count == 0) {
        self.notFoundLabel.hidden     = NO;
        self.notFoundLabel.text       = @"検索結果がありません。\n現在Arutoが全力で探しています。\nもうしばらくお待ちください";
        self.notFoundImageView.hidden = NO;
        self.totalCountView.hidden    = YES;
    } else {
        self.notFoundLabel.hidden     = YES;
        self.notFoundImageView.hidden = YES;
        self.totalCountView.hidden    = NO;
        self.totalCountLabel.text     = [NSString stringWithFormat:@"該当件数 : %d 件", (int)ARTSearchManager.shared.totalCount];
    }
}



- (IBAction)segment_ValueChanged:(id)sender
{
    UISegmentedControl *segment = (UISegmentedControl *)sender;
    switch (segment.selectedSegmentIndex) {
        case 0: //人を選択した時
            ARTSearchManager.shared.isStaffSearch = YES;
            [self clearData];
            [self.collectionView reloadData];
            [self startUO];
            //[self reloadData];
            [self.collectionView setContentOffset:CGPointMake(0, 0)];
            break;
            
        case 1: //店を選択した時
            ARTSearchManager.shared.isStaffSearch = NO;
            [self clearData];
            [self.collectionView reloadData];
            [self startUO];
            [self.collectionView setContentOffset:CGPointMake(0, 0)];
            break;
        default:
            break;
    }
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView DataSource

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (ARTSearchManager.shared.isStaffSearch) {
        ARTStaffListViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTStaffListViewCell class])
                                                                               forIndexPath:indexPath];
        [cell setIndexPath:indexPath];
        Staff *staffData = self.rowData[indexPath.row];
        [cell setStaffData:staffData];
        Shop *shopData = [Shop art_shopWithShopId:staffData.shopId localContext:nil];
        [cell setShopData:shopData];

        return cell;
    } else {
        ARTStoreListViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTStoreListViewCell class])
                                                                               forIndexPath:indexPath];
        [cell setIndexPath:indexPath];
        Shop *shopData = self.rowData[indexPath.row];
        [cell setShopData:shopData];

        return cell;
    }
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionViewFlowLayout Delegate

- (CGSize)  collectionView:(UICollectionView *)collectionView
                    layout:(UICollectionViewLayout *)collectionViewLayout
    sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //return CGSizeMake(320, 175);
    return CGSizeMake(320, 280);
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView Delegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
    [ARTUtils selectActionForView:cell];

    if (ARTSearchManager.shared.isStaffSearch) {
        Staff *staffData = self.rowData[indexPath.row];
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory staffDetailViewControllerWithStaffId:staffData.identifier]];
    } else {
        Shop *shopData = self.rowData[indexPath.row];
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory storeDetailViewControllerWithShopId:shopData.identifier]];
    }
}

@end
