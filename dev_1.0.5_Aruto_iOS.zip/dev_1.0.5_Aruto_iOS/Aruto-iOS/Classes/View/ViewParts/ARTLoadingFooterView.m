//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTLoadingFooterView.h"

@interface ARTLoadingFooterView ()

@property (nonatomic, weak) IBOutlet UILabel                 *label;
@property (nonatomic, weak) IBOutlet UIActivityIndicatorView *animationView;

@property (nonatomic, assign) ARTLoadingViewState viewState;
@property (nonatomic, copy) NSString             *nothingTextString;

@end

@implementation ARTLoadingFooterView

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    self.label.adjustsFontSizeToFitWidth = YES;

    self.animationView.layer.cornerRadius = self.animationView.width * 0.5;

    self.nothingTextString = @"データがありませんでした";
}

- (void)setNothingText:(NSString *)nothingText
{
    self.nothingTextString = nothingText;
}

- (void)setViewState:(ARTLoadingViewState)viewState completion:(void (^)(void))completion
{
    if (viewState == ARTLoadingViewStateLoading) {
        [UIView animateWithDuration:0.2 animations: ^{
             self.animationView.alpha = YES;
             self.label.text = @"読み込み中...";
         } completion: ^(BOOL finished) {
             art_SafeBlockCall(completion);
         }];
    } else if (viewState == ARTLoadingViewStateFinishLoading) {
        [UIView animateWithDuration:0.2 animations: ^{
             self.animationView.alpha = NO;
             self.label.text = nil;
         } completion: ^(BOOL finished) {
             art_SafeBlockCall(completion);
         }];
    } else if (viewState == ARTLoadingViewStateNothing) {
        [UIView animateWithDuration:0.2 animations: ^{
             self.animationView.alpha = NO;
             self.label.text = self.nothingTextString;
         } completion: ^(BOOL finished) {
             art_SafeBlockCall(completion);
         }];
    } else if (viewState == ARTLoadingViewStateWait) {
        [UIView animateWithDuration:0.2 animations: ^{
             self.animationView.alpha = NO;
             self.label.text = nil;
         } completion: ^(BOOL finished) {
             art_SafeBlockCall(completion);
         }];
    }

    _viewState = viewState;
}

@end
