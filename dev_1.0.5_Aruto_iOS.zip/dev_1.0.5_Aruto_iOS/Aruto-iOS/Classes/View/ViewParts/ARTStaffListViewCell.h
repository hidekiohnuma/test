//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTStaffListViewCell : UICollectionViewCell

@property (nonatomic, copy) void (^updateCellBlock)(NSNumber *itemId);

- (void)setIndexPath:(NSIndexPath *)indexPath;
- (void)setStaffData:(Staff *)entity;
- (void)setShopData:(Shop *)entity;

- (void)setBottomButtonTitle:(NSString *)title
                       image:(UIImage *)image
                    tapBlock:(void (^)(id resultObj))tapBlock;

@end
