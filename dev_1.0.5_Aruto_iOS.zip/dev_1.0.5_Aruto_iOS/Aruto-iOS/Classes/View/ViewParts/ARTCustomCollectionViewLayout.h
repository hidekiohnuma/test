//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

// TODO : 実験中、本番使用不可

@interface ARTCustomCollectionViewLayout : UICollectionViewLayout

@property (nonatomic, assign) CGSize cellSize;
@property (nonatomic, assign) CGSize footerSize;

@end
