//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTStoreListViewCell : UICollectionViewCell

@property (nonatomic, copy) void (^updateCellBlock)(NSNumber *itemId);

- (void)setIndexPath:(NSIndexPath *)indexPath;
- (void)setShopData:(Shop *)entity;

- (void)setBottomButtonTitle:(NSString *)title
                       image:(UIImage *)image
                    tapBlock:(void (^)(id resultObj))tapBlock;

@end
