//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTBaseListView.h"

#import "ARTLoadingFooterView.h"

@interface ARTBaseListView ()

@property (nonatomic, strong) UIRefreshControl *refreshControl;

@end

@implementation ARTBaseListView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    self.collectionView.contentInset = UIEdgeInsetsMake(0, 0, 50, 0);
    
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTLoadingFooterView class]) bundle:nil]
          forSupplementaryViewOfKind:UICollectionElementKindSectionFooter
                 withReuseIdentifier:NSStringFromClass([ARTLoadingFooterView class])];
    
    [self refreshisNeed:YES];
    [self clearData];
}

- (void)clearData
{
    self.index       = 0;
    self.rowData     = nil;
    self.canNextCall = YES;
    self.isLoading   = NO;
}

- (void)startUO
{
    // need override
}

- (NSArray *)rowDataArray
{
    // need override
    return nil;
}

- (void)reloadData
{
    self.rowData = [self rowDataArray];
    
    if (self.rowData && self.rowData.count > 0) {
        self.index += ART_UO_Index_Interval;
    } else {
        self.index = 0;
    }
    
    [self.collectionView reloadData];
}

- (void)refreshisNeed:(BOOL)isNeed
{
    if (isNeed) {
        if (self.refreshControl) { return; }
        
        self.refreshControl = UIRefreshControl.new;
        
        [self.refreshControl addTarget:self action:@selector(refresh) forControlEvents:UIControlEventValueChanged];
        self.refreshControl.tintColor = ART_BaseColor_Orange;
        [self.collectionView addSubview:self.refreshControl];
    } else {
        [self.refreshControl removeFromSuperview];
        self.refreshControl = nil;
    }
}

- (void)refresh
{
    if (!self.refreshControl) { return; }
    
    [self.refreshControl beginRefreshing];
    
    [self clearData];
    [self startUO];
}

- (ARTLoadingViewState)loadingViewState
{
    if (self.refreshControl.isRefreshing) {
        return ARTLoadingViewStateRefreshing;
    }
    if (self.isLoading ||
        (self.canNextCall &&
         self.rowData.count >= self.index &&
         self.rowData.count >= ART_UO_Index_Interval)) {
        return ARTLoadingViewStateLoading;
    }
    if (self.rowData && !self.rowData.count) {
        return ARTLoadingViewStateNothing;
    }
    if (!self.canNextCall || (self.rowData && self.rowData.count < ART_UO_Index_Interval)) {
        return ARTLoadingViewStateFinishLoading;
    }
    return ARTLoadingViewStateWait;
}

- (ARTCompletionBlock)uoCompletionBlock
{
    __weak typeof(self) weakSelf = self;
    return ^(id resultObject) {
        weakSelf.isLoading = NO;
        if (!weakSelf) { return; }
        
        if ([resultObject isKindOfClass:[NSError class]]) {
            weakSelf.canNextCall = NO;
            NSError *error = (NSError *)resultObject;
            [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                         message:error.localizedFailureReason
                                     buttonTitle:nil];
        } else if ([resultObject isKindOfClass:[NSNumber class]]) {
            weakSelf.canNextCall = [(NSNumber *)resultObject boolValue];
        }
        [weakSelf reloadData];
        
        if (weakSelf.refreshControl.isRefreshing) {
            [weakSelf.refreshControl endRefreshing];
        }
    };
}

- (void)setContentsScrollView
{
    self.parentController.targetScrollView = self.collectionView;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView DataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.rowData.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    // need override
    return nil;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionViewFlowLayout Delegate

- (CGSize)  collectionView:(UICollectionView *)collectionView
                    layout:(UICollectionViewLayout *)collectionViewLayout
    sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    // need override
    return CGSizeZero;
}

// フッターサイズ
- (CGSize)           collectionView:(UICollectionView *)collectionView
                             layout:(UICollectionViewLayout *)collectionViewLayout
    referenceSizeForFooterInSection:(NSInteger)section
{
    if ([self loadingViewState] == ARTLoadingViewStateLoading ||
        [self loadingViewState] == ARTLoadingViewStateNothing) {
        return CGSizeMake(self.width, 50);
    }
    return CGSizeZero;
}

// ヘッダー・フッター設定
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView
           viewForSupplementaryElementOfKind:(NSString *)kind
                                 atIndexPath:(NSIndexPath *)indexPath
{
    if ([kind isEqualToString:UICollectionElementKindSectionFooter]) {
        ARTLoadingFooterView *footerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind
                                                                              withReuseIdentifier:NSStringFromClass([ARTLoadingFooterView class])
                                                                                     forIndexPath:indexPath];
        if (self.nothingRowText) {
            [footerView setNothingText:self.nothingRowText];
        }
        [footerView setViewState:[self loadingViewState] completion:nil];
        
        if ([self loadingViewState] == ARTLoadingViewStateLoading) {
            [self startUO];
        }
        
        return footerView;
    }
    
    return nil;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UIScrollView Delegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [[ARTViewContainer shared] hideTabViewAnimationWithScrollView:scrollView];
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [[ARTViewContainer shared] showTabViewAnimationWithScrollView:scrollView];
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if (!decelerate) {
        [[ARTViewContainer shared] showTabViewAnimationWithScrollView:scrollView];
    }
}

@end
