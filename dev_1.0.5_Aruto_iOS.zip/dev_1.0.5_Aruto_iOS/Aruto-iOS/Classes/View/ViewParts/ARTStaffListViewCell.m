//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTStaffListViewCell.h"

@interface ARTStaffListViewCell ()

@property (nonatomic, weak) IBOutlet UIImageView *imageView;
@property (nonatomic, weak) IBOutlet UILabel     *nameLabel;
@property (nonatomic, weak) IBOutlet UILabel     *genderLabel;
@property (nonatomic, weak) IBOutlet UILabel     *ageLabel;
@property (nonatomic, weak) IBOutlet UILabel     *storeLabel;
@property (nonatomic, weak) IBOutlet UILabel     *messageLabel;
@property (nonatomic, weak) IBOutlet UILabel     *hobbyLabel;
@property (nonatomic, weak) IBOutlet UIButton    *bottomButton;
@property (nonatomic, weak) IBOutlet UIView      *miniView;
@property (nonatomic, weak) IBOutlet UIView      *imageLayerView;

@property (nonatomic, copy) NSIndexPath *currentIndexPath;
@property (nonatomic, copy) NSNumber *staffId;

@property (nonatomic, copy) void (^buttonTapBlock)(id resultObj);

@end

@implementation ARTStaffListViewCell

- (void)dealloc
{
    LOG_METHOD;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    self.nameLabel.adjustsFontSizeToFitWidth    = YES;

    self.bottomButton.exclusiveTouch = YES;

    /*
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame  = self.bounds;
    gradient.colors = @[(id)[art_UIColorWithRGBA(250, 240, 210, 1.0) CGColor],
                        (id)[art_UIColorWithRGBA(250, 230, 180, 1.0) CGColor]];
    [self.layer insertSublayer:gradient atIndex:0];
    */
    
    CALayer *layer = [CALayer layer];
    layer.frame = self.bounds;
    layer.backgroundColor = [UIColor whiteColor].CGColor;
    [self.layer insertSublayer:layer atIndex:0];
    
    self.miniView.layer.cornerRadius     = 5.0f;
    self.bottomButton.layer.cornerRadius = 5.0f;
    
    __weak typeof(self) weakSelf = self;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [ARTUtils addNotisForName:ARTNofiricationFavoriteStaffChenged
                        block:^(NSNotification *note) {
                            NSNumber *staffId = note.object;
                            if (!staffId) { return; }
                            if (weakSelf.staffId.integerValue == staffId.integerValue) {
                                if (weakSelf.updateCellBlock) {
                                    art_SafeBlockCall(weakSelf.updateCellBlock, weakSelf.staffId.copy);
                                } else {
                                    [weakSelf updateButton];
                                }
                            }
                        }];
}

- (void)setIndexPath:(NSIndexPath *)indexPath
{
    self.currentIndexPath = indexPath;
}

- (void)setStaffData:(Staff *)entity
{
    if (!entity) { return; }

    self.staffId = entity.identifier.copy;
#ifdef DEBUG
    self.nameLabel.text = [NSString stringWithFormat:@"%@ %@", entity.name, entity.identifier];
#else
    self.nameLabel.text = entity.name.copy;
#endif

    if (entity.otherAnswers && entity.otherAnswers[@"selling_point"]) {
        self.messageLabel.hidden = NO;
        self.messageLabel.text   = [(NSString *)entity.otherAnswers[@"selling_point"] copy];
    } else {
        self.messageLabel.hidden = YES;
        self.messageLabel.text   = nil;
    }

    if (entity.sexId.integerValue == 1) {
        self.genderLabel.text = @"男性";
    } else {
        self.genderLabel.text = @"女性";
    }
    if (entity.birthday) {
        self.ageLabel.text = [Generation art_generationForAge:@([entity.birthday art_ageForDate])];
    } else {
        self.ageLabel.text = nil;
    }

    if (entity.hobbyId) {
        self.hobbyLabel.text = [NSString stringWithFormat:@"趣味\n%@", [Hobby art_nameForId:entity.hobbyId]];
    } else {
        self.hobbyLabel.text = nil;
    }
    [self.imageView art_setImageWithURL:[NSURL URLWithString:entity.thumbnailURL]
                       placeholderImage:nil
                                noImage:nil
                                  alpha:1
                             parentView:self.imageLayerView
                          needAnimation:YES];
    
    [self updateButton];
}

- (void)setShopData:(Shop *)entity
{
    if (!entity) { return; }

    self.storeLabel.text = [Shop art_shopNameForShop:entity];
}

- (void)updateButton
{
    if (!self.buttonTapBlock) {
        if ([FavoriteStaff art_isFavoriteForStaffId:self.staffId]) {
            [self.bottomButton art_setTitleForAddFavorite:NO];
        } else {
            [self.bottomButton art_setTitleForAddFavorite:YES];
        }
    }
}

- (IBAction)tapBottomButton:(UIButton *)sender
{
    [ARTPopping poppinAnimationWithView:sender];

    if (self.buttonTapBlock) {
        art_SafeBlockCall(self.buttonTapBlock, self.staffId);
    } else {
        if (![self.bottomButton art_canChangeFavorite]) { return; }

        if ([FavoriteStaff art_isFavoriteForStaffId:self.staffId]) {
            [self.bottomButton art_removeFavoriteForStaffId:self.staffId];
        } else {
            [self.bottomButton art_addFavoriteForStaffId:self.staffId];
        }
    }
    [self setNeedsDisplay];
}

- (void)setBottomButtonTitle:(NSString *)title
                       image:(UIImage *)image
                    tapBlock:(void (^)(id resultObj))tapBlock
{
    [self.bottomButton setTitle:title forState:UIControlStateNormal];
    [self.bottomButton setImage:image forState:UIControlStateNormal];
    self.buttonTapBlock = tapBlock;
}

- (void)drawRect:(CGRect)rect
{
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = self.bounds;
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds
                                                   byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight | UIRectCornerBottomLeft | UIRectCornerBottomRight
                                                         cornerRadii:CGSizeMake(0, 0)];//7,7
    
    maskLayer.path  = maskPath.CGPath;
    self.layer.mask = maskLayer;
}

@end
