//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTNeedLoginView.h"

@interface ARTNeedLoginView ()

@property (nonatomic, weak) IBOutlet UIButton *needLoginButton;

@end

@implementation ARTNeedLoginView

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    [ARTUtils setBaseButtonStyle:self.needLoginButton];
    self.needLoginButton.layer.cornerRadius = 5;
}

- (IBAction)tapNeedLoginButton:(UIButton *)sender
{
    [[ARTViewContainer shared] showUserAuthModalView];
}

@end
