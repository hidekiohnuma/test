//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTBaseListView : ARTBaseContentsView

@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;

@property (nonatomic, assign) BOOL      isLoading;
@property (nonatomic, assign) BOOL      canNextCall;
@property (nonatomic, strong) NSArray  *rowData;
@property (nonatomic, assign) NSInteger index;
@property (nonatomic, copy) NSString *nothingRowText;

- (void)clearData;
- (void)startUO;
- (NSArray *)rowDataArray;
- (void)reloadData;

- (void)refresh;
- (void)refreshisNeed:(BOOL)isNeed;

- (ARTLoadingViewState)loadingViewState;

- (ARTCompletionBlock)uoCompletionBlock;

- (void)setContentsScrollView;

@end
