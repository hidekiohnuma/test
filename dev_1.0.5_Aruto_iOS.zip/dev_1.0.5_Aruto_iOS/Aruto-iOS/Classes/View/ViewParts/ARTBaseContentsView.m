//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTBaseContentsView.h"
#import "ARTNeedLoginView.h"

@interface ARTBaseContentsView ()

@property (nonatomic, strong) ARTNeedLoginView *needLoginView;

@property (nonatomic, copy, readwrite) NSString *identifier;

@end

@implementation ARTBaseContentsView

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    while (self.gestureRecognizers.count) {
        [self removeGestureRecognizer:[self.gestureRecognizers objectAtIndex:0]];
    }
    [self hideIndicator];
    [self deallocChild];
}

- (void)deallocChild
{
    // override if you needed
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    __weak typeof(self) weakSelf = self;
    [ARTUtils addNotisForName:ARTNofiricationLogined
                        block:^(NSNotification *note) {
                            [weakSelf hideNeedLoginView];
                        }];
    [ARTUtils addNotisForName:ARTNofiricationLogouted
                        block:^(NSNotification *note) {
                            [weakSelf dispNeedLoginView];
                        }];
}

- (void)cleateNeedLoginView
{
    if (!self.needLoginView) {
        self.needLoginView        = [ARTNeedLoginView art_createViewByNib];
        self.needLoginView.frame  = self.bounds;
        self.needLoginView.hidden = YES;
        [self addSubview:self.needLoginView];
    }
}

- (void)dispNeedLoginView
{
    if (self.needLoginView &&
        ![[ARTUserManager shared] isLogined]) {
        self.needLoginView.hidden = NO;
    }
}

- (void)hideNeedLoginView
{
    if (self.needLoginView) {
        self.needLoginView.hidden = YES;
    }
}

- (void)showIndicator
{
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeClear];
}

- (void)hideIndicator
{
    [SVProgressHUD dismiss];
}

- (void)sendViewName:(NSString *)viewName
{
    [ARTAnalytics sendGAScreenName:viewName];
}

@end
