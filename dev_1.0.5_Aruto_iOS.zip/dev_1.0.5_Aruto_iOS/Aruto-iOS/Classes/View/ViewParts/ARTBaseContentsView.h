//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTBaseContentsView : UIView

@property (nonatomic, weak) ARTBaseViewController *parentController;

- (void)deallocChild;

- (void)cleateNeedLoginView;
- (void)dispNeedLoginView;
- (void)hideNeedLoginView;

- (void)showIndicator;
- (void)hideIndicator;

- (void)sendViewName:(NSString *)viewName;

@end
