//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTStoreListViewCell.h"

@interface ARTStoreListViewCell ()

@property (nonatomic, weak) IBOutlet UIImageView *imageView;
@property (nonatomic, weak) IBOutlet UILabel     *nameLabel;
@property (nonatomic, weak) IBOutlet UILabel     *jobLabel;
@property (nonatomic, weak) IBOutlet UILabel     *ratioLabel;
@property (nonatomic, weak) IBOutlet UILabel     *ageLabel;
@property (nonatomic, weak) IBOutlet UILabel     *messageLabel;
@property (nonatomic, weak) IBOutlet UIButton    *bottomButton;
@property (nonatomic, weak) IBOutlet UIView      *miniView;
@property (nonatomic, weak) IBOutlet UIView      *imageLayerView;

@property (nonatomic, copy) NSIndexPath *currentIndexPath;
@property (nonatomic, copy) NSNumber *shopId;

@property (nonatomic, copy) void (^buttonTapBlock)(id resultObj);

@end

@implementation ARTStoreListViewCell

- (void)dealloc
{
    LOG_METHOD;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    self.nameLabel.adjustsFontSizeToFitWidth    = YES;
    self.ratioLabel.adjustsFontSizeToFitWidth   = YES;
    self.ageLabel.adjustsFontSizeToFitWidth     = YES;

    self.bottomButton.exclusiveTouch = YES;

    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame  = self.bounds;
    gradient.colors = @[(id)[art_UIColorWithRGBA(250, 240, 210, 1.0) CGColor],
                        (id)[art_UIColorWithRGBA(250, 230, 180, 1.0) CGColor]];
    [self.layer insertSublayer:gradient atIndex:0];

    //self.miniView.layer.cornerRadius     = 5.0f;
    self.miniView.layer.cornerRadius     = 0.0f;
    self.bottomButton.layer.cornerRadius = 5.0f;
    
    __weak typeof(self) weakSelf = self;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [ARTUtils addNotisForName:ARTNofiricationFavoriteShopChenged
                        block:^(NSNotification *note) {
                            NSNumber *shopId = note.object;
                            if (!shopId) { return; }
                            if (weakSelf.shopId.integerValue == shopId.integerValue) {
                                if (weakSelf.updateCellBlock) {
                                    art_SafeBlockCall(weakSelf.updateCellBlock, weakSelf.shopId.copy);
                                } else {
                                    [weakSelf updateButton];
                                }
                            }
                        }];
}

- (void)setIndexPath:(NSIndexPath *)indexPath
{
    self.currentIndexPath = indexPath;
}

- (void)setShopData:(Shop *)entity
{
    if (!entity) { return; }

    self.shopId = entity.identifier;

#ifdef DEBUG
    self.nameLabel.text = [NSString stringWithFormat:@"%@ %@", [Shop art_shopNameForShop:entity], entity.identifier];
#else
    self.nameLabel.text = [Shop art_shopNameForShop:entity];
#endif
    self.ratioLabel.text = [NSString stringWithFormat:@"男女比 %@", entity.gendarRatio];
    self.ageLabel.text   = [NSString stringWithFormat:@"平均年齢 %@", entity.ageAverage];

    if (entity.shopFeature && entity.shopFeature.length > 0) {
        self.messageLabel.hidden = NO;
        self.messageLabel.text   = entity.shopFeature.copy;
    } else {
        self.messageLabel.hidden = YES;
        self.messageLabel.text   = nil;
    }
    
    [self updateButton];

    NSArray *jobArray = [Job art_jobListForShopId:entity.identifier];
    if (jobArray && jobArray.count > 0) {
        NSMutableString *jobString = [NSMutableString string];
        for (int i = 0; i < jobArray.count; ++i) {
            Job *entity = [jobArray objectAtIndex:i];
            //[jobString appendString:[NSString stringWithFormat:@"%@\n", [JobType art_nameForId:entity.jobTypeId]]];//前のバージョンは改行コードが入っている
            [jobString appendString:[NSString stringWithFormat:@"%@", [JobType art_nameForId:entity.jobTypeId]]];
        }
        self.jobLabel.text = jobString;
    } else {
        self.jobLabel.text = @"なし";
    }

    [self.imageView art_setImageWithURL:[NSURL URLWithString:entity.thumbnailURL]
                       placeholderImage:nil
                                noImage:nil
                                  alpha:1
                             parentView:self.imageLayerView
                          needAnimation:YES];

    [self setNeedsDisplay];
}

- (void)updateButton
{
    if (!self.buttonTapBlock) {
        if ([FavoriteShop art_isFavoriteForShopId:self.shopId]) {
            [self.bottomButton art_setTitleForAddFavorite:NO];
        } else {
            [self.bottomButton art_setTitleForAddFavorite:YES];
        }
    }
}

- (IBAction)tapBottomButton:(UIButton *)sender
{
    [ARTPopping poppinAnimationWithView:sender];

    if (self.buttonTapBlock) {
        art_SafeBlockCall(self.buttonTapBlock, self.shopId);
    } else {
        if (![self.bottomButton art_canChangeFavorite]) { return; }

        if ([FavoriteShop art_isFavoriteForShopId:self.shopId]) {
            [self.bottomButton art_removeFavoriteForShopId:self.shopId];
        } else {
            [self.bottomButton art_addFavoriteForShopId:self.shopId];
        }
    }
}

- (void)setBottomButtonTitle:(NSString *)title
                       image:(UIImage *)image
                    tapBlock:(void (^)(id resultObj))tapBlock
{
    [self.bottomButton setTitle:title forState:UIControlStateNormal];
    [self.bottomButton setImage:image forState:UIControlStateNormal];
    self.buttonTapBlock = tapBlock;
}

- (void)drawRect:(CGRect)rect
{
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = self.bounds;
    UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds
                                                   byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight | UIRectCornerBottomLeft | UIRectCornerBottomRight
                                                         cornerRadii:CGSizeMake(0, 0)];//7,7
    maskLayer.path  = maskPath.CGPath;
    self.layer.mask = maskLayer;
}

@end
