//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTLoadingFooterView : UICollectionReusableView

- (void)setNothingText:(NSString *)nothingText;

- (void)setViewState:(ARTLoadingViewState)viewState completion:(void (^)(void))completion;

@end
