//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTTabView.h"

@interface ARTTabView ()

@property (nonatomic, weak) IBOutlet UIView   *contentsView;
@property (nonatomic, weak) IBOutlet UIButton *myPageButton;
@property (nonatomic, weak) IBOutlet UIButton *searchButton;
@property (nonatomic, weak) IBOutlet UIButton *favoriteButton;
@property (nonatomic, weak) IBOutlet UIButton *rankingButton;
@property (nonatomic, weak) IBOutlet UIButton *settingButton;
@property (nonatomic, weak) IBOutlet UIButton *specialEditionButton;
@property (nonatomic, weak) IBOutlet UIButton *prefectureArea;
@property (nonatomic, weak) IBOutlet UIButton *galleryButton;

@property (nonatomic, strong) IBOutlet NSLayoutConstraint *verticalSpaceConstraint;

@property (nonatomic, assign) BOOL isShowAnimating;
@property (nonatomic, assign) BOOL isHideAnimating;

@end

@implementation ARTTabView

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)view;
            button.exclusiveTouch = YES;
        }
    }
    
    [self.myPageButton setImage:[ARTIcons imageWithIcon:aruto_icon_mypage
                                              iconColor:[UIColor lightGrayColor]
                                               iconSize:20
                                              imageSize:CGSizeMake(30, 30)] forState:UIControlStateNormal];
    
    [self.rankingButton setImage:[ARTIcons imageWithIcon:aruto_icon_ranking
                                               iconColor:[UIColor lightGrayColor]
                                                iconSize:20
                                               imageSize:CGSizeMake(30, 30)] forState:UIControlStateNormal];
    
    [self.galleryButton setImage:[ARTIcons imageWithIcon:aruto_icon_gallery
                                               iconColor:[UIColor lightGrayColor]
                                                iconSize:20
                                               imageSize:CGSizeMake(30, 30)] forState:UIControlStateNormal];
   
    [self.specialEditionButton setImage:[ARTIcons imageWithIcon:aruto_icon_house
                                              iconColor:[UIColor darkGrayColor]
                                               iconSize:20
                                              imageSize:CGSizeMake(30, 30)] forState:UIControlStateNormal];
    
    [self.prefectureArea setImage:[ARTIcons imageWithIcon:aruto_icon_position
                                                      iconColor:[UIColor lightGrayColor]
                                                       iconSize:20
                                                      imageSize:CGSizeMake(30, 30)] forState:UIControlStateNormal];
    
    /*
    [self.rankingButton setImage:[IonIcons imageWithIcon:@"a"
                                               iconColor:[UIColor blackColor]
                                                iconSize:35
                                               imageSize:CGSizeMake(35, 35)] forState:UIControlStateNormal];
    
    [self.searchButton setImage:[IonIcons imageWithIcon:icon_ios7_search
                                              iconColor:art_UIColorWithRGBA(80, 50, 0, 1)
                                               iconSize:35
                                              imageSize:CGSizeMake(35, 35)] forState:UIControlStateNormal];
    
    
    [self.settingButton setImage:[IonIcons imageWithIcon:icon_ios7_gear_outline
                                               iconColor:art_UIColorWithRGBA(80, 50, 0, 1)
                                                iconSize:35
                                               imageSize:CGSizeMake(35, 35)] forState:UIControlStateNormal];
    */
    
    // unuse button
    //self.settingButton.hidden = YES;
}

- (IBAction)tapMyPageButton:(UIButton *)sender
{
    [ARTPopping scaleAnimationWithView:self.myPageButton];
    [[ARTViewContainer shared] setTopController:[ARTViewControllerFactory myPageViewController]
                                     needToggle:YES];
    [self activeButton:self.myPageButton iconType:aruto_icon_mypage];
}

- (IBAction)tapSearchButton:(UIButton *)sender
{
    [ARTPopping scaleAnimationWithView:self.searchButton];
    [[ARTViewContainer shared] setTopController:[ARTViewControllerFactory searchRootController]
                                    needToggle:YES];
    
    //[[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupSelectOptionType];
    
    [self activeButton:self.searchButton iconType:aruto_icon_gallery];
}

- (IBAction)tapFavoriteButton:(UIButton *)sender
{
    [ARTPopping scaleAnimationWithView:self.favoriteButton];
    [[ARTViewContainer shared] setTopController:[ARTViewControllerFactory favoriteViewControllerWithNeedBack:NO]
                                     needToggle:YES];
    //[self activeButton:self.favoriteButton iconType:aruto_icon_ranking];
}

- (IBAction)tapRankingButton:(UIButton *)sender
{
    [ARTPopping scaleAnimationWithView:self.rankingButton];
    [[ARTViewContainer shared] setTopController:[ARTViewControllerFactory rankingSelectViewControllerWithNeedBack:NO]
                                     needToggle:YES];
    [self activeButton:self.rankingButton iconType:aruto_icon_ranking];
}

- (IBAction)tapSpecialEditionButton:(UIButton *)sender
{
    [ARTPopping scaleAnimationWithView:self.specialEditionButton];
    [[ARTViewContainer shared] setTopController:[ARTViewControllerFactory specialEditionView] needToggle:YES];
    //[[ARTViewContainer shared] setTopController:[ARTViewControllerFactory favoriteViewControllerWithNeedBack:NO] needToggle:YES];
    [self activeButton:self.specialEditionButton iconType:aruto_icon_house];
}
- (IBAction)tapPrefectureAreaButton:(UIButton *)sender
{
    [ARTPopping scaleAnimationWithView:self.prefectureArea];
    [[ARTViewContainer shared] setTopController:[ARTViewControllerFactory prefectureAreaView] needToggle:YES];
    [self activeButton:self.prefectureArea iconType:aruto_icon_position];
}
- (IBAction)tapGalleryButton:(UIButton *)sender
{
    [ARTPopping scaleAnimationWithView:self.galleryButton];
    [[ARTViewContainer shared] setTopController:[ARTViewControllerFactory galleryView] needToggle:YES];
    [self activeButton:self.galleryButton iconType:aruto_icon_gallery];
}
/*
- (IBAction)tapSettingButton:(UIButton *)sender
{
    [ARTPopping scaleAnimationWithView:self.settingButton];
    [[ARTViewContainer shared] setTopController:[ARTViewControllerFactory settingViewController]
                                     needToggle:YES];
}
- (IBAction)tapSpecialEditionButton:(UIButton *)sender
{
    [ARTPopping scaleAnimationWithView:self.specialEditionButton];
    [[ARTViewContainer shared] setTopController:[ARTViewControllerFactory specialEditionView]
                                     needToggle:YES];
}
=======
*/

- (void)activeButton:(UIButton *)senderBtn iconType:(NSString *)iconType
{
    [self.myPageButton setImage:[ARTIcons imageWithIcon:aruto_icon_mypage
                                              iconColor:[UIColor lightGrayColor]
                                               iconSize:20
                                              imageSize:CGSizeMake(30, 30)] forState:UIControlStateNormal];
    
    [self.rankingButton setImage:[ARTIcons imageWithIcon:aruto_icon_ranking
                                               iconColor:[UIColor lightGrayColor]
                                                iconSize:20
                                               imageSize:CGSizeMake(30, 30)] forState:UIControlStateNormal];
    
    [self.galleryButton setImage:[ARTIcons imageWithIcon:aruto_icon_gallery
                                              iconColor:[UIColor lightGrayColor]
                                               iconSize:20
                                              imageSize:CGSizeMake(30, 30)] forState:UIControlStateNormal];
    
    [self.specialEditionButton setImage:[ARTIcons imageWithIcon:aruto_icon_house
                                                      iconColor:[UIColor lightGrayColor]
                                                       iconSize:20
                                                      imageSize:CGSizeMake(30, 30)] forState:UIControlStateNormal];
    
    [self.prefectureArea setImage:[ARTIcons imageWithIcon:aruto_icon_position
                                                      iconColor:[UIColor lightGrayColor]
                                                       iconSize:20
                                                      imageSize:CGSizeMake(30, 30)] forState:UIControlStateNormal];
    
    // active
    [senderBtn setImage:[ARTIcons imageWithIcon:iconType
                                                      iconColor:[UIColor darkGrayColor]
                                                       iconSize:20
                                                      imageSize:CGSizeMake(30, 30)] forState:UIControlStateNormal];
}


- (void)initSetting
{
    self.targetScrollView = nil;
    [self initTabPosition];
}

- (void)initTabPosition
{
    self.verticalSpaceConstraint.constant = 0;
    [self.contentsView setNeedsUpdateConstraints];

    self.isShowAnimating = YES;
    [UIView animateWithDuration:0.35 animations: ^{
         [self layoutIfNeeded];
     } completion: ^(BOOL finished) {
         self.isShowAnimating = NO;
     }];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UIScrollView Delegate

- (void)hideAnimationWithScrollView:(UIScrollView *)scrollView
{
    if (!self.targetScrollView || self.targetScrollView != scrollView) {
        return;
    }

    CGFloat offset = scrollView.contentOffset.y;
    if (offset <= 0) {
        return;
    }

    if (self.isShowAnimating) { return; }

    if (self.verticalSpaceConstraint.constant < 50) {
        self.verticalSpaceConstraint.constant += 5;
        if (self.verticalSpaceConstraint.constant > 50) {
            self.verticalSpaceConstraint.constant = 50;
        }
        [self.contentsView setNeedsUpdateConstraints];
    }
}

- (void)showAnimationWithScrollView:(UIScrollView *)scrollView
{
    if (!self.targetScrollView || self.targetScrollView != scrollView) {
        return;
    }

    [self initTabPosition];
}

@end
