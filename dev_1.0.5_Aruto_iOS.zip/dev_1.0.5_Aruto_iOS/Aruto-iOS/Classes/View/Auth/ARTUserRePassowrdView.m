//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTUserRePassowrdView.h"

#import "ARTUserUO.h"

@interface ARTUserRePassowrdView ()

@property (nonatomic, weak) IBOutlet UITextField *emailField;
@property (nonatomic, weak) IBOutlet UIButton    *cancelButton;
@property (nonatomic, weak) IBOutlet UIButton    *sendButton;

@end

@implementation ARTUserRePassowrdView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    self.sendButton.exclusiveTouch   = YES;
    self.cancelButton.exclusiveTouch = YES;

    self.emailField.adjustsFontSizeToFitWidth = YES;
    self.emailField.inputAccessoryView        = [ARTUtils keyboardToolbarWithTarget:self
                                                                           selector:@selector(art_closeKeyboad)
                                                                              width:self.width];
}

- (IBAction)tapCancelButton:(UIButton *)sender
{
    art_SafeBlockCall(self.completionBlock);
}

- (IBAction)tapSendButton:(UIButton *)sender
{
    NSString *errMsg = nil;
    
    if (self.emailField.text.length == 0) {
        errMsg = @"メールアドレスを入力して下さい";
    }
    if (!errMsg && ![ARTUtils checkRegex:2 string:self.emailField.text]) {
        errMsg = @"メールアドレスが正しくないようです";
    }
    if (errMsg) {
        [ARNAlert showNoActionAlertWithTitle:errMsg
                                     message:nil
                                 buttonTitle:nil];
        return;
    }

    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeClear];

    __weak typeof(self) weakSelf = self;

    [ARTUserUO uoReissueEmailWithTarget:self
                                  email:self.emailField.text
                        completionBlock: ^(id resultObject) {
         [SVProgressHUD dismiss];
         if (!weakSelf) { return; }

         if ([resultObject isKindOfClass:[NSError class]]) {
             NSError *error = (NSError *)resultObject;
             [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                          message:error.localizedFailureReason
                                      buttonTitle:nil];
         } else {
             [ARNAlert showNoActionAlertWithTitle:nil
                                          message:@"パスワード再設定のメールを送信しました"
                                      buttonTitle:nil];
             art_SafeBlockCall(weakSelf.completionBlock);
         }
     }];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UITextField Delegate

// キーボードのreturnキーを押したときの処理
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self art_closeKeyboad];
    return YES;
}

@end
