//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTUserAuthViewCell : UICollectionViewCell

@property (nonatomic, copy) void (^closeButtonBlock)();

@property (nonatomic, copy) void (^userAgreementBlock)(ARTVoidBlock aceept, ARTVoidBlock cancel);

@property (nonatomic, copy) void (^rePasswordBlock)();

- (void)settingLogin;
- (void)settingSignIn;

@end
