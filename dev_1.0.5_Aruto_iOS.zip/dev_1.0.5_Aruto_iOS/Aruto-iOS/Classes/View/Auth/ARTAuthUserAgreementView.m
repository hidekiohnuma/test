//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTAuthUserAgreementView.h"

@interface ARTAuthUserAgreementView ()

@property (nonatomic, weak) IBOutlet UIView     *headerView;
@property (nonatomic, weak) IBOutlet UITextView *textView;

@property (nonatomic, copy) void (^cancelButtonBlock)();
@property (nonatomic, copy) void (^acceptButtonBlock)();

@end

@implementation ARTAuthUserAgreementView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    self.textView.text = ARTUserAgreement;
}

- (void)setAcceptBlock:(void (^)())acceptBlock cancelBlock:(void (^)())cancelBlock
{
    self.acceptButtonBlock = acceptBlock;
    self.cancelButtonBlock = cancelBlock;
}

- (IBAction)tapCancelButton:(UIButton *)sender
{
    art_SafeBlockCall(self.cancelButtonBlock);
}

- (IBAction)tapAcceptButton:(UIButton *)sender
{
    art_SafeBlockCall(self.acceptButtonBlock);
}

@end
