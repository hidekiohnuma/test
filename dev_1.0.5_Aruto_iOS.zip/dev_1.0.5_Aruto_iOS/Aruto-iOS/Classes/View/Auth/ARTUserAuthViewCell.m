//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTUserAuthViewCell.h"

@interface ARTUserAuthViewCell ()

@property (nonatomic, weak) IBOutlet UILabel     *titleLabel;
@property (nonatomic, weak) IBOutlet UILabel     *mailLabel;
@property (nonatomic, weak) IBOutlet UIButton    *fbButton;
@property (nonatomic, weak) IBOutlet UIButton    *twitterButton;
@property (nonatomic, weak) IBOutlet UIButton    *mailButton;
@property (nonatomic, weak) IBOutlet UIButton    *closeButton;
@property (nonatomic, weak) IBOutlet UIButton    *forgetPasswordButton;
@property (nonatomic, weak) IBOutlet UITextField *emailField;
@property (nonatomic, weak) IBOutlet UITextField *passwordField;

@property (nonatomic, assign) BOOL isLogin;

@property (nonatomic, weak) UITextField *activeField;

@end

@implementation ARTUserAuthViewCell

- (void)dealloc
{
    LOG_METHOD;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    self.fbButton.exclusiveTouch      = YES;
    self.twitterButton.exclusiveTouch = YES;
    self.closeButton.exclusiveTouch   = YES;

    self.fbButton.layer.cornerRadius      = self.fbButton.height * 0.5;
    self.twitterButton.layer.cornerRadius = self.twitterButton.height * 0.5;
    self.mailButton.layer.cornerRadius    = self.mailButton.height * 0.5;
    self.closeButton.layer.cornerRadius   = self.closeButton.height * 0.5;

    self.closeButton.layer.borderWidth = 1;
    self.closeButton.layer.borderColor = [UIColor lightGrayColor].CGColor;

    [self.fbButton setImage:[IonIcons imageWithIcon:ion_social_facebook
                                          iconColor:[UIColor whiteColor]
                                           iconSize:25
                                          imageSize:CGSizeMake(25, 25)] forState:UIControlStateNormal];

    [self.twitterButton setImage:[IonIcons imageWithIcon:ion_social_twitter
                                               iconColor:[UIColor whiteColor]
                                                iconSize:25
                                               imageSize:CGSizeMake(25, 25)] forState:UIControlStateNormal];

    self.emailField.adjustsFontSizeToFitWidth = YES;
    self.emailField.inputAccessoryView        = [ARTUtils keyboardToolbarWithTarget:self selector:@selector(art_closeKeyboad) width:self.width];

    self.passwordField.adjustsFontSizeToFitWidth = YES;
    self.passwordField.inputAccessoryView        = [ARTUtils keyboardToolbarWithTarget:self selector:@selector(art_closeKeyboad) width:self.width];

    NSNotificationCenter *nc = [NSNotificationCenter defaultCenter];

    __weak typeof(self) weakSelf = self;

    [nc addObserverForName:UIKeyboardWillShowNotification
                    object:nil
                     queue:[NSOperationQueue mainQueue]
                usingBlock: ^(NSNotification *note) {
         // キーボードの表示完了時の場所と大きさを取得。
         CGRect keyboardFrameEnd = [[note.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue];
         float screenHeight = [[UIScreen mainScreen] bounds].size.height;

         float fieldPosition = 100 + weakSelf.activeField.bottom;
         float keyboardHeight = screenHeight - keyboardFrameEnd.size.height - 50;

         if (fieldPosition > keyboardHeight) {
             // テキストフィールドがキーボードで隠れるようなら
             // 選択中のテキストフィールドの直ぐ下にキーボードの上端が付くように、スクロールビューの位置を上げる
             [UIView animateWithDuration:0.3
                              animations: ^{
                  weakSelf.frame = CGRectMake(0, 0 - (fieldPosition - keyboardHeight),
                      weakSelf.width,
                      weakSelf.height);
              }];
         }
     }];

    [nc addObserverForName:UIKeyboardWillHideNotification
                    object:nil
                     queue:[NSOperationQueue mainQueue]
                usingBlock: ^(NSNotification *note) {
         [UIView animateWithDuration:0.3
                          animations: ^{
              weakSelf.activeField = nil;
              weakSelf.frame = weakSelf.bounds;
          }];
     }];
}

- (void)startAuth
{
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeClear];
}

- (void)finishAuth
{
    [SVProgressHUD dismiss];
}

- (void)settingLogin
{
    self.isLogin         = YES;
    self.titleLabel.text = @"ログイン";
    self.mailLabel.text  = @"メールアドレスでログイン";
    [self.fbButton setTitle:@"Login With Facebook" forState:UIControlStateNormal];
    [self.twitterButton setTitle:@"Login With Twitter" forState:UIControlStateNormal];
    [self.mailButton setTitle:@"ログイン" forState:UIControlStateNormal];
    self.forgetPasswordButton.hidden = NO;
}

- (void)settingSignIn
{
    self.isLogin         = NO;
    self.titleLabel.text = @"ユーザー登録";
    self.mailLabel.text  = @"メールアドレスでユーザー登録";
    [self.fbButton setTitle:@"Sign in With Facebook" forState:UIControlStateNormal];
    [self.twitterButton setTitle:@"Sign in With Twitter" forState:UIControlStateNormal];
    [self.mailButton setTitle:@"登録" forState:UIControlStateNormal];
    self.forgetPasswordButton.hidden = YES;
}

- (ARTSuccessBlock)completionBlock
{
    __weak typeof(self) weakSelf = self;

    return ^(id resultObject) {
               if ([resultObject isKindOfClass:[NSError class]]) {
                   NSError *error = (NSError *)resultObject;
                   [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                                message:error.localizedFailureReason
                                            buttonTitle:nil];
               } else {
                   [[NSNotificationCenter defaultCenter] postNotificationName:ARTNofiricationLogined object:nil userInfo:nil];
                   [[ARTViewContainer shared] hideUserAuthModalView];
               }
               [weakSelf finishAuth];
    };
}

- (IBAction)tapCloseButton:(UIButton *)sender
{
    art_SafeBlockCall(self.closeButtonBlock);
}

- (IBAction)tapFbButton:(UIButton *)sender
{
    if (self.isLogin) {
        [self startAuth];
        [[ARTUserManager shared] loginUserByFacebockWithCompletionBlock:[self completionBlock]];
    } else {
        __weak typeof(self) weakSelf = self;

        art_SafeBlockCall(self.userAgreementBlock, ^{
                [weakSelf startAuth];
                [[ARTUserManager shared] createUserByFacebockWithCompletionBlock:[weakSelf completionBlock]];
            }, nil);
    }
}

- (IBAction)tapTwitterButton:(UIButton *)sender
{
    if (self.isLogin) {
        [self startAuth];
        [[ARTUserManager shared] loginUserByTwitterWithCompletionBlock:[self completionBlock]];
    } else {
        __weak typeof(self) weakSelf = self;

        art_SafeBlockCall(self.userAgreementBlock, ^{
                [weakSelf startAuth];
                [[ARTUserManager shared] createUserByTwitterWithCompletionBlock:[weakSelf completionBlock]];
            }, nil);
    }
}

- (IBAction)tapMailButton:(UIButton *)sender
{
    NSString *errMsg = nil;
    
    if (self.emailField.text.length == 0) {
        errMsg = @"メールアドレスを入力して下さい";
    }
    if (!errMsg && self.passwordField.text.length == 0) {
        errMsg = @"パスワードを入力して下さい";
    }
    if (!errMsg && ![ARTUtils checkRegex:2 string:self.emailField.text]) {
        errMsg = @"メールアドレスが正しくないようです";
    }
    if (!errMsg && ![ARTUtils checkRegex:1 string:self.passwordField.text]) {
        errMsg = @"パスワードに使用出来ない文字が含まれています";
    }
    if (errMsg) {
        [ARNAlert showNoActionAlertWithTitle:errMsg
                                     message:nil
                                 buttonTitle:nil];
        return;
    }

    if (self.isLogin) {
        [self startAuth];
        [[ARTUserManager shared] loginUserWithEmail:self.emailField.text
                                           password:self.passwordField.text
                                    completionBlock:[self completionBlock]];
    } else {
        __weak typeof(self) weakSelf = self;

        art_SafeBlockCall(self.userAgreementBlock, ^{
                [weakSelf startAuth];
                [[ARTUserManager shared] createUserWithEmail:weakSelf.emailField.text
                                                    password:weakSelf.passwordField.text
                                             completionBlock:[weakSelf completionBlock]];
            }, nil);
    }
}

- (IBAction)tapForgetPasswordButton:(UIButton *)sender
{
    [self art_closeKeyboad];
    art_SafeBlockCall(self.rePasswordBlock);
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UITextField Delegate

// キーボードのreturnキーを押したときの処理
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [self art_closeKeyboad];
    return YES;
}

// テキストフィールドへフォーカスされた時に起動
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    self.activeField = textField;
}

@end
