//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTUserAuthView : ARTBaseContentsView

- (void)setHeaderTitle:(NSString *)headerTitle;

- (void)setRightCancelButtonWithblock:(void (^)())block;

@end
