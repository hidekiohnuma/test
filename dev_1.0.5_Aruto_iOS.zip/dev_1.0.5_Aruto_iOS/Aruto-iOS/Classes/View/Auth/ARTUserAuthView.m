//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTUserAuthView.h"

#import "ARTUserAuthViewCell.h"
#import "ARTAuthUserAgreementView.h"
#import "ARTUserRePassowrdView.h"

@interface ARTUserAuthView ()

@property (nonatomic, weak) IBOutlet UIView           *headerView;
@property (nonatomic, weak) IBOutlet UILabel          *titleLabel;
@property (nonatomic, weak) IBOutlet UIButton         *rightButton;
@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;

@property (nonatomic, strong) ARTAuthUserAgreementView *userAgreementView;
@property (nonatomic, strong) ARTUserRePassowrdView    *rePasswordView;

@property (nonatomic, assign) BOOL      isFullscreen;
@property (nonatomic, assign) NSInteger selectIndexPathRow;

@property (nonatomic, copy) void (^rightButtonBlock)();

@end

@implementation ARTUserAuthView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTUserAuthViewCell class]) bundle:nil]
          forCellWithReuseIdentifier:NSStringFromClass([ARTUserAuthViewCell class])];

    self.userAgreementView = [ARTAuthUserAgreementView art_createViewByNib];
    [self addSubview:self.userAgreementView];
    self.userAgreementView.frame = self.bounds;
    self.userAgreementView.alpha = 0;

    [self reloadCollectionLayout];
}

- (void)setHeaderTitle:(NSString *)headerTitle
{
    self.titleLabel.text = headerTitle;
}

- (void)setRightCancelButtonWithblock:(void (^)())block
{
    if (!block) {
        self.rightButton.hidden = YES;
        return;
    }

    [self.rightButton setTitle:@"Cancel" forState:UIControlStateNormal];
    [self.rightButton setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    self.rightButtonBlock = block;
}

- (IBAction)tapRightButton:(id)sender
{
    art_SafeBlockCall(self.rightButtonBlock);
}

- (UICollectionViewFlowLayout *)viewLayout
{
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];

    if (_isFullscreen) {
        layout.sectionInset = UIEdgeInsetsZero;
    } else {
        layout.sectionInset = UIEdgeInsetsMake(20, 0, 20, 0);
    }
    layout.minimumInteritemSpacing = 0.0f;
    if (_isFullscreen) {
        layout.minimumLineSpacing = 0.0f;
    } else {
        layout.minimumLineSpacing = 10.0f;
    }
    layout.headerReferenceSize = CGSizeZero;
    layout.footerReferenceSize = CGSizeZero;

    return layout;
}

- (void)reloadCollectionLayout
{
    [self.collectionView setCollectionViewLayout:[self viewLayout] animated:YES];
}

- (void)showRePasswordView
{
    if (!self.rePasswordView) {
        self.rePasswordView = [ARTUserRePassowrdView art_createViewByNib];
        [self addSubview:self.rePasswordView];
        [self bringSubviewToFront:self.rePasswordView];
        self.rePasswordView.frame = self.bounds;
        self.rePasswordView.alpha = 0;

        __weak typeof(self) weakSelf = self;

        self.rePasswordView.completionBlock = ^{
            [UIView animateWithDuration:0.2 animations: ^{
                 weakSelf.rePasswordView.alpha = 0.0;
             } completion: ^(BOOL finished) {
                 [weakSelf.rePasswordView removeFromSuperview];
                 weakSelf.rePasswordView = nil;
             }];
        };
    }

    [UIView animateWithDuration:0.2 animations: ^{
         self.rePasswordView.alpha = 1.0;
     }];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView DataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return 2;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    ARTUserAuthViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTUserAuthViewCell class])
                                                                          forIndexPath:indexPath];

    if (indexPath.row == 0) {
        [cell settingLogin];
    } else {
        [cell settingSignIn];
    }

    __weak typeof(self) weakSelf = self;

    cell.closeButtonBlock = ^{
        weakSelf.isFullscreen = NO;
        [weakSelf reloadCollectionLayout];
    };

    [cell setUserAgreementBlock: ^(ARTVoidBlock accept, ARTVoidBlock cancel) {
         [weakSelf.userAgreementView setAcceptBlock: ^{
              [UIView animateWithDuration:0.2 animations: ^{ weakSelf.userAgreementView.alpha = 0; }];
              art_SafeBlockCall(accept);
          } cancelBlock: ^{
              [UIView animateWithDuration:0.2 animations: ^{ weakSelf.userAgreementView.alpha = 0; }];
              art_SafeBlockCall(cancel);
          }];
         [UIView animateWithDuration:0.2 animations: ^{ weakSelf.userAgreementView.alpha = 1; }];
     }];

    cell.rePasswordBlock = ^{
        [weakSelf showRePasswordView];
    };

    return cell;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionViewFlowLayout Delegate

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (_isFullscreen) {
        if (indexPath.row == self.selectIndexPathRow) {
            return CGSizeMake(self.collectionView.width, self.collectionView.height);
        } else {
            return CGSizeMake(self.width, 0);
        }
    } else {
        return CGSizeMake(self.collectionView.width, 44);
    }
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView Delegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    self.selectIndexPathRow = indexPath.row;
    self.isFullscreen       = YES;

    [self reloadCollectionLayout];
}

@end
