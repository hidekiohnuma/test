//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTMyPageView.h"
#import "ARTMyPageViewCell.h"
#import "IonIcons.h"
#import "ARTIcons.h"

@interface ARTMyPageView ()

@property (nonatomic, weak) IBOutlet UIWebView        *webView;
@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;
@property (nonatomic, weak) IBOutlet UIActivityIndicatorView *indicatorView;

@end

@implementation ARTMyPageView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    [self cleateNeedLoginView];
    if (![[ARTUserManager shared] isLogined]) {
        [self dispNeedLoginView];
    }

    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTMyPageViewCell class]) bundle:nil]
          forCellWithReuseIdentifier:NSStringFromClass([ARTMyPageViewCell class])];

    if (!self.webView.isLoading) {
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"https://www.aruto.me/app/campaign"]];
        [request setHTTPMethod:@"GET"];
        request.timeoutInterval = 20;
        [_webView loadRequest:request];
    }
}

- (IBAction)tapBanner:(UIButton *)sender
{
    /*
    //機能をOFF 
    [[ARTViewContainer shared] showModalViewWithController:[ARTViewControllerFactory bannerViewController]
                                                  animated:YES animationBlock: ^{
     } completionBlock: ^(UINavigationController *resultNavController) {
     }];
    */
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView DataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    //return 2;
    //return 3;
    return 4;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    ARTMyPageViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTMyPageViewCell class])
                                                                        forIndexPath:indexPath];

    if (indexPath.row == 0) {
        cell.titleLabel.text     = @"あとで見るリスト";
        //cell.leftImageView.image = [UIImage imageNamed:@"tab_list"];
        cell.leftImageView.image = [ARTIcons imageWithIcon:aruto_icon_cliped
                                                 iconColor:[UIColor darkGrayColor]
                                                  iconSize:15
                                                 imageSize:CGSizeMake(40, 40)];
    } else if (indexPath.row == 1) {
        cell.titleLabel.text     = @"応募中のお店";
        cell.leftImageView.image = [ARTIcons imageWithIcon:aruto_icon_chat
                                                 iconColor:[UIColor darkGrayColor]
                                                  iconSize:15
                                                 imageSize:CGSizeMake(40, 40)];
    } else if(indexPath.row == 2){
        cell.titleLabel.text    = @"設定";
        //cell.leftImageView.image = [UIImage imageNamed:@"tab_list"];
        cell.leftImageView.image = [ARTIcons imageWithIcon:aruto_icon_settings
                                                 iconColor:[UIColor darkGrayColor]
                                                  iconSize:15
                                                 imageSize:CGSizeMake(40, 40)];
    } else if(indexPath.row == 3){
        cell.titleLabel.text    = @"Arutoについて";
        //cell.leftImageView.image = [UIImage imageNamed:@"tab_list"];
        cell.leftImageView.image = [ARTIcons imageWithIcon:aruto_icon_info
                                                 iconColor:[UIColor darkGrayColor]
                                                  iconSize:15
                                                 imageSize:CGSizeMake(40, 40)];
    }

    return cell;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView Delegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
    [ARTUtils selectActionForView:cell];

    if (indexPath.row == 0) {
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory favoriteViewControllerWithNeedBack:YES]];
    } else if (indexPath.row == 1) {
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory entryListViewControllerWithNeedBack:YES]];
    } else if (indexPath.row == 2) {
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory settingViewControllerWithNeedBack:YES]];
    } else if (indexPath.row == 3) {
        //[[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory settingViewControllerWithNeedBack:YES]];
        [[ARTViewContainer shared] showModalViewWithController:[ARTViewControllerFactory bannerViewController]
                                                      animated:YES animationBlock: ^{
                                                      } completionBlock: ^(UINavigationController *resultNavController) {
                                                      }];
    }
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - UIWebView Delegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    LOG(@"%@", request.URL.absoluteString);

    NSString *urlString = request.URL.absoluteString;

    if ([urlString rangeOfString:@""].location != NSNotFound) {
        // フック
        return NO;
    }
    return YES;
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [self.indicatorView startAnimating];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [self.indicatorView stopAnimating];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    LOG(@"%@", error.debugDescription);

    [self.indicatorView stopAnimating];
}

@end
