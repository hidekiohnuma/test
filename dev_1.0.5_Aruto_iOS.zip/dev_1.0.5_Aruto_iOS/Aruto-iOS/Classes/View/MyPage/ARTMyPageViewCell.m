//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTMyPageViewCell.h"

@interface ARTMyPageViewCell ()

@property (nonatomic, weak) IBOutlet UIImageView *rightImageView;

@end

@implementation ARTMyPageViewCell

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    //self.layer.cornerRadius = 5;
    //self.layer.backgroundColor = [UIColor grayColor].CGColor;

    self.titleLabel.adjustsFontSizeToFitWidth = YES;

    self.rightImageView.image = [IonIcons imageWithIcon:ion_ios_arrow_forward
                                              iconColor:art_UIColorWithRGBA(243,152,0,1)// 120, 190, 255, 1
                                               iconSize:20
                                              imageSize:CGSizeMake(30, 30)];
}

@end
