//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTWelocomePage2View.h"

@implementation ARTWelocomePage2View

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
}

@end
