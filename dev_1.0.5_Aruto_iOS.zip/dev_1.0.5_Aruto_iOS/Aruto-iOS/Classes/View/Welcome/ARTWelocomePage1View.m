//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTWelocomePage1View.h"

@implementation ARTWelocomePage1View

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
}

@end
