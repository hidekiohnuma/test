//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTWelcomeView.h"
#import "ARTWelocomePage1View.h"
#import "ARTWelocomePage2View.h"

@interface ARTWelcomeView ()

@property (nonatomic, weak) IBOutlet UIScrollView  *scrollView;
@property (nonatomic, weak) IBOutlet UIPageControl *pageControl;
@property (nonatomic, weak) IBOutlet UIButton      *startButton;

@end

@implementation ARTWelcomeView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    self.startButton.exclusiveTouch = YES;
    self.startButton.exclusiveTouch = YES;

    ARTWelocomePage1View *page1View = [ARTWelocomePage1View art_createViewByNib];
    page1View.left = 0;
    [self.scrollView addSubview:page1View];

    ARTWelocomePage2View *page2View = [ARTWelocomePage2View art_createViewByNib];
    page2View.left = self.width;
    [self.scrollView addSubview:page2View];

    self.scrollView.contentSize = CGSizeMake(self.width * 2, self.scrollView.height);
}

- (IBAction)tapStartButton:(UIButton *)sender
{
    ARTUserDefaults.shared.isFinishWelcomeView = YES;

    [[ARTViewContainer shared] setTopController:[ARTViewControllerFactory searchRootController]
                                     needToggle:NO];
    [[ARTViewContainer shared] closeModalViewWithAnimationBlock:nil completionBlock:nil];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UIScrollView Delegate

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    self.pageControl.currentPage = ((self.scrollView.contentOffset.x + self.scrollView.width) / self.scrollView.width - 1);
}

@end
