//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTDetailHeaderView : UICollectionReusableView

- (void)setImageWithURLArray:(NSArray *)urlArray;

@end
