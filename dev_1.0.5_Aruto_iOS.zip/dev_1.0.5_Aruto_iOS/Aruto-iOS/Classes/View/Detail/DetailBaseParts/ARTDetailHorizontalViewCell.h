//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

#import "ARTDetailHorizontalCellView.h"

@interface ARTDetailHorizontalViewCell : UICollectionViewCell

@property (nonatomic, strong) ARTDetailHorizontalCellView *cellView;

@end
