//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTDetailBaseCellView : UIView

@property (nonatomic, weak) IBOutlet UIView  *lineView;
@property (nonatomic, weak) IBOutlet UILabel *titleLabel;
@property (nonatomic, weak) IBOutlet UILabel *detailLabel;

- (void)setTitle:(NSString *)title detail:(NSString *)detail isFirst:(BOOL)isFirst isLast:(BOOL)isLast;

@end
