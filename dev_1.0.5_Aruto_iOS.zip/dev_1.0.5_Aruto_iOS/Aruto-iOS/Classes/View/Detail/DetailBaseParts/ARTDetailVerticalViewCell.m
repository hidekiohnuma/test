//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTDetailVerticalViewCell.h"

@implementation ARTDetailVerticalViewCell

- (void)dealloc
{
    LOG_METHOD;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.clipsToBounds = YES;
        
        [self setTranslatesAutoresizingMaskIntoConstraints:NO];
        
        self.cellView = [ARTDetailVerticalCellView art_createViewByNib];
        [self.contentView addSubview:self.cellView];
        [self.contentView art_pinAllEdgesOfSubview:self.cellView];
    }
    return self;
}

@end
