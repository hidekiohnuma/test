//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTDetailSectionHeaderView.h"

@interface ARTDetailSectionHeaderView ()

@property (nonatomic, weak) IBOutlet UILabel *titleLabel;

@end

@implementation ARTDetailSectionHeaderView

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)setTitle:(NSString *)title
{
    self.titleLabel.text = title;
}

@end
