//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTDetailBaseCellView.h"

@interface ARTDetailBaseCellView ()

@property (nonatomic, assign) BOOL isFirst;
@property (nonatomic, assign) BOOL isLast;

@end

@implementation ARTDetailBaseCellView

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    [self setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    self.titleLabel.adjustsFontSizeToFitWidth = YES;
}

- (void)setTitle:(NSString *)title detail:(NSString *)detail isFirst:(BOOL)isFirst isLast:(BOOL)isLast
{
    self.titleLabel.text  = title;
    self.detailLabel.text = detail;
    self.isFirst          = isFirst;
    self.isLast           = isLast;
    
    if (isFirst) {
        UIBezierPath *maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds
                                                       byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight cornerRadii:CGSizeMake(5, 5)];
        CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
        maskLayer.frame                  = self.bounds;
        maskLayer.path                   = maskPath.CGPath;
        self.layer.mask = maskLayer;
    }
    
    if (isLast) {
        self.lineView.hidden = YES;
    } else {
        self.lineView.hidden = NO;
    }
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect
{
    // todo : もうちょいましな実装できないか...
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = self.bounds;
    UIBezierPath *maskPath;
    
    if (self.isFirst && self.isLast) {
        maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds
                                         byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight | UIRectCornerBottomLeft | UIRectCornerBottomRight
                                               cornerRadii:CGSizeMake(7, 7)];
    } else if (self.isFirst) {
        maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds
                                         byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight
                                               cornerRadii:CGSizeMake(7, 7)];
    } else if (self.isLast) {
        maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds
                                         byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight
                                               cornerRadii:CGSizeMake(7, 7)];
    } else {
        maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds
                                         byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight | UIRectCornerBottomLeft | UIRectCornerBottomRight
                                               cornerRadii:CGSizeMake(0, 0)];
    }
    
    maskLayer.path  = maskPath.CGPath;
    self.layer.mask = maskLayer;
}

@end
