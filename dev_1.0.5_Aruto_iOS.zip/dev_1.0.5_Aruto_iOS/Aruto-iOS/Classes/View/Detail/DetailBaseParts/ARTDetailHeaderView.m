//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTDetailHeaderView.h"

@interface ARTDetailHeaderView ()

@property (nonatomic, weak) IBOutlet UIScrollView  *scrollView;
@property (nonatomic, weak) IBOutlet UIPageControl *pageControl;

@property (nonatomic, assign) BOOL            alreadyUO;
@property (nonatomic, strong) NSMutableArray *imageViewArray;

@end

@implementation ARTDetailHeaderView

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame  = self.bounds;
    gradient.colors = @[(id)[art_UIColorWithRGBA(245, 240, 230, 1.0) CGColor],
                        (id)[art_UIColorWithRGBA(245, 180, 140, 1.0) CGColor]];
    [self.layer insertSublayer:gradient atIndex:0];
    self.backgroundColor = art_UIColorWithRGBA(245, 180, 140, 1.0);
}

- (void)setImageWithURLArray:(NSArray *)urlArray
{
    if (!urlArray || urlArray.count == 0) { return; }
    if (self.alreadyUO) { return; }

    self.alreadyUO = YES;

    BOOL isOnlyOne = (urlArray.count == 1);
    self.pageControl.hidden = isOnlyOne;
    self.pageControl.numberOfPages = urlArray.count;
    self.scrollView.scrollEnabled = !isOnlyOne;
    self.imageViewArray           = [NSMutableArray array];
    for (int i = 0; i < urlArray.count; ++i) {
        BOOL isFirst = (i == 0);
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:self.bounds];
        imageView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        imageView.contentMode      = UIViewContentModeScaleAspectFill;
        imageView.alpha            = 0;
        imageView.left             = self.width * i;
        imageView.clipsToBounds    = YES;
        [self.scrollView addSubview:imageView];
        [self.scrollView sendSubviewToBack:imageView];
        [self.imageViewArray addObject:imageView];
        [imageView art_setImageWithURL:[NSURL URLWithString:[urlArray objectAtIndex:i]]
                      placeholderImage:nil
                               noImage:nil
                                 alpha:1
                            parentView:nil
                         needAnimation:isFirst];
    }
    
    self.scrollView.contentSize = CGSizeMake(self.width * urlArray.count, self.height);
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UIScrollView Delegate

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    self.pageControl.currentPage = ((self.scrollView.contentOffset.x + self.scrollView.width) / self.scrollView.width - 1);
    UIImageView *imageView = [self.imageViewArray objectAtIndex:self.pageControl.currentPage];
    [self.scrollView bringSubviewToFront:imageView];
}

@end
