//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTJobPointViewCell.h"

@interface ARTJobPointViewCell ()

@end

@implementation ARTJobPointViewCell

- (void)dealloc
{
    LOG_METHOD;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.clipsToBounds = YES;
        
        [self setTranslatesAutoresizingMaskIntoConstraints:NO];
        
        self.cellView = [ARTJobPointCellView art_createViewByNib];
        [self.contentView addSubview:self.cellView];
        [self.contentView art_pinAllEdgesOfSubview:self.cellView];
    }
    return self;
}

@end
