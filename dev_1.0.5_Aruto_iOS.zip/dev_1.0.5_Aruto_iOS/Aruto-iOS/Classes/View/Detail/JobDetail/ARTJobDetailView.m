//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTJobDetailView.h"

#import "ARTDetailSectionHeaderView.h"
#import "ARTLoadingFooterView.h"

#import "ARTDetailHorizontalViewCell.h"
#import "ARTJobDetailViewCell.h"
#import "ARTStoreJobViewCell.h"
#import "ARTJobPointViewCell.h"

#import "ARTJobUO.h"

@interface ARTJobDetailView ()

@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;
@property (nonatomic, weak) IBOutlet UIButton         *entryButton;

@property (nonatomic, assign) BOOL    isLoading;
@property (nonatomic, copy) NSNumber *jobId;
@property (nonatomic, strong) Job    *jobData;


@property (nonatomic, strong) ARTDetailHorizontalCellView *protoHorizontalView;
@property (nonatomic, strong) ARTJobDetailCellView        *protoDetailCellView;
@property (nonatomic, strong) ARTJobPointCellView         *protoPointView;

@end

@implementation ARTJobDetailView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    self.collectionView.contentInset = UIEdgeInsetsMake(0, 0, 44, 0);
    
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTDetailSectionHeaderView class]) bundle:nil]
          forSupplementaryViewOfKind:UICollectionElementKindSectionHeader
                 withReuseIdentifier:NSStringFromClass([ARTDetailSectionHeaderView class])];
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTLoadingFooterView class]) bundle:nil]
          forSupplementaryViewOfKind:UICollectionElementKindSectionFooter
                 withReuseIdentifier:NSStringFromClass([ARTLoadingFooterView class])];
    
    [self.collectionView registerClass:[ARTDetailHorizontalViewCell class]
            forCellWithReuseIdentifier:NSStringFromClass([ARTDetailHorizontalViewCell class])];
    
    [self.collectionView registerClass:[ARTJobDetailViewCell class]
            forCellWithReuseIdentifier:NSStringFromClass([ARTJobDetailViewCell class])];
    
    [self.collectionView registerClass:[ARTJobPointViewCell class]
            forCellWithReuseIdentifier:NSStringFromClass([ARTJobPointViewCell class])];
    
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTStoreJobViewCell class]) bundle:nil]
          forCellWithReuseIdentifier:NSStringFromClass([ARTStoreJobViewCell class])];
    
    self.entryButton.exclusiveTouch = YES;
}

- (void)entryButtonIsShow:(BOOL)isShow
{
    if (isShow) {
        self.entryButton.hidden          = NO;
        self.collectionView.contentInset = UIEdgeInsetsMake(0, 0, 44, 0);
    } else {
        self.entryButton.hidden          = YES;
        self.collectionView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    }
}

- (void)setJobId:(NSNumber *)jobId
{
    _jobId = jobId;
    
    if ([[ARTUOCacheManager shared] containsJobId:_jobId]) {
        [self reloadData];
        if (!self.jobData) {
            [self startUO];
        }
    } else {
        [self startUO];
    }
}

- (void)startUO
{
    self.isLoading           = YES;
    self.entryButton.enabled = NO;
    
    __weak typeof(self) weakSelf = self;
    
    [ARTJobUO uoGetJobWithTarget:self
                           jobId:self.jobId.copy
                 completionBlock: ^(id resultObject) {
                     if (!weakSelf) { return; }
                     weakSelf.isLoading = NO;
                     
                     if ([resultObject isKindOfClass:[NSError class]]) {
                         NSError *error = (NSError *)resultObject;
                         [ARTUtils showPopControllerAlertWithTitle:error.localizedDescription
                                                           message:error.localizedFailureReason];
                     } else {
                         weakSelf.entryButton.enabled = YES;
                         [weakSelf reloadData];
                     }
                 }];
}

- (void)reloadData
{
    self.jobData = [Job art_jobWithJobId:_jobId localContext:nil];
    
    Shop *shopData = [Shop art_shopWithShopId:self.jobData.shopId localContext:nil];
    [self.parentController setHeaderImageForURL:[NSURL URLWithString:shopData.image1URL]];
    
    if (!self.jobData) {
        [ARTUtils showPopControllerAlertWithTitle:@"エラー"
                                          message:@"該当の求人情報を取得出来ませんでした"];
    } else {
        [[ARTUOCacheManager shared] addJobId:self.jobId.copy];
        [self.collectionView reloadData];
    }
}

- (IBAction)tapEntryButton:(UIButton *)sender
{
    [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory entryViewControllerWithShopId:self.jobData.shopId]];
}

- (ARTLoadingViewState)loadingViewState
{
    if (self.jobData && !self.isLoading) {
        return ARTLoadingViewStateFinishLoading;
    }
    return ARTLoadingViewStateLoading;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView DataSource

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 3;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (!self.jobData) { return 0; }
    
    if (section == 0) {
        return 1;
    } else if (section == 1) {
        return 6;
    } else if (section == 2) {
        return 1;
    }
    
    return 0;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        ARTJobDetailViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTJobDetailViewCell class])
                                                                               forIndexPath:indexPath];
        [cell.cellView setTitle:self.jobData.workDescription];
        
        return cell;
    } else if (indexPath.section == 1) {
        ARTDetailHorizontalViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTDetailHorizontalViewCell class])
                                                                                      forIndexPath:indexPath];
        [self configureCellView:cell.cellView indexPath:indexPath];
        
        return cell;
    } else if (indexPath.section == 2) {
        ARTJobPointViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTJobPointViewCell class])
                                                                              forIndexPath:indexPath];
        
        [cell.cellView setSellingPoints:[JobJobOtherPoint art_allEntiteisByJobId:self.jobId]];
        
        return cell;
    }
    return nil;
}

- (void)configureCellView:(ARTDetailBaseCellView *)cellView indexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0) {
        NSString *salaryString = @"";
        if (self.jobData.salary && self.jobData.salary.length > 0) {
            salaryString = [NSString stringWithFormat:@"時給 : %d円\n\n%@", self.jobData.salaryHour.intValue, self.jobData.salary];
        } else {
            salaryString = [NSString stringWithFormat:@"時給 : %d円", self.jobData.salaryHour.intValue];
        }
        if (self.jobData.bonus && self.jobData.bonus.length > 0) {
            salaryString = [salaryString stringByAppendingFormat:@"\n\nボーナス : %@", self.jobData.bonus];
        }
        [cellView setTitle:@"給与"
                    detail:salaryString
                   isFirst:YES isLast:NO];
    } else if (indexPath.row == 1) {
        [cellView setTitle:@"勤務期間"
                    detail:self.jobData.workPeriod
                   isFirst:NO isLast:NO];
    } else if (indexPath.row == 2) {
        NSString *workDayString = @"";
        if (self.jobData.workDay && self.jobData.workDay.length > 0) {
            workDayString = [NSString stringWithFormat:@"%@\n\n%@",
                             [WorkDayType art_nameForId:self.jobData.workDayTypeId],
                             self.jobData.workDay];
        } else {
            workDayString = [WorkDayType art_nameForId:self.jobData.workDayTypeId];
        }
        [cellView setTitle:@"勤務日"
                    detail:workDayString
                   isFirst:NO isLast:NO];
    } else if (indexPath.row == 3) {
        NSString *workHourString = @"";
        if (self.jobData.workHour && self.jobData.workHour.length > 0) {
            workHourString = [NSString stringWithFormat:@"%@\n\n%@",
                              [NSString stringWithFormat:@"%@ 〜 %@", self.jobData.workHourFrom, self.jobData.workHourTo],
                              self.jobData.workHour];
        } else {
            workHourString = [NSString stringWithFormat:@"%@ 〜 %@", self.jobData.workHourFrom, self.jobData.workHourTo];
        }
        [cellView setTitle:@"勤務時間"
                    detail:workHourString
                   isFirst:NO isLast:NO];
    } else if (indexPath.row == 4) {
        [cellView setTitle:@"採用予定"
                    detail:[NSString stringWithFormat:@"%d 名", self.jobData.hireNumber.intValue]
                   isFirst:NO isLast:NO];
    } else if (indexPath.row == 5) {
        [cellView setTitle:@"掲載期間"
                    detail:[NSString stringWithFormat:@"%@ \n\n 〜 \n\n %@",
                            [self.jobData.displayBegin art_stringWithFormatJapaneseYYYYMD_Weakday],
                            [self.jobData.displayEnd art_stringWithFormatJapaneseYYYYMD_Weakday]]
                   isFirst:NO isLast:YES];
    }
}

// ヘッダー・フッター設定
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView
           viewForSupplementaryElementOfKind:(NSString *)kind
                                 atIndexPath:(NSIndexPath *)indexPath
{
    if ([kind isEqualToString:UICollectionElementKindSectionHeader]) {
        ARTDetailSectionHeaderView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind
                                                                                    withReuseIdentifier:NSStringFromClass([ARTDetailSectionHeaderView class])
                                                                                           forIndexPath:indexPath];
        if (indexPath.section == 0) {
            [headerView setTitle:@"お仕事内容"];
        } else if (indexPath.section == 1) {
            [headerView setTitle:@"勤務条件"];
        } else if (indexPath.section == 2) {
            [headerView setTitle:@"こだわり"];
        }
        
        return headerView;
    }
    if ([kind isEqualToString:UICollectionElementKindSectionFooter]) {
        ARTLoadingFooterView *footerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind
                                                                              withReuseIdentifier:NSStringFromClass([ARTLoadingFooterView class])
                                                                                     forIndexPath:indexPath];
        
        [footerView setViewState:[self loadingViewState] completion:nil];
        return footerView;
    }
    return nil;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionViewFlowLayout Delegate

// ヘッダーサイズ
- (CGSize)           collectionView:(UICollectionView *)collectionView
                             layout:(UICollectionViewLayout *)collectionViewLayout
    referenceSizeForHeaderInSection:(NSInteger)section
{
    if (!self.jobData) { return CGSizeZero; }
    
    return CGSizeMake(self.width, 40);
}

- (CGSize)  collectionView:(UICollectionView *)collectionView
                    layout:(UICollectionViewLayout *)collectionViewLayout
    sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        if (!_protoDetailCellView) {
            _protoDetailCellView = [ARTJobDetailCellView art_createViewByNib];
        }
        
        [_protoDetailCellView setTitle:self.jobData.workDescription];
        
        CGSize size = [_protoDetailCellView systemLayoutSizeFittingSize:UILayoutFittingCompressedSize];
        //LOG(@"size : %@", NSStringFromCGSize(size));
        return CGSizeMake(300, size.height);
    } else if (indexPath.section == 1) {
        if (!_protoHorizontalView) {
            _protoHorizontalView = [ARTDetailHorizontalCellView art_createViewByNib];
        }
        
        [self configureCellView:_protoHorizontalView indexPath:indexPath];
        
        CGSize size = [_protoHorizontalView systemLayoutSizeFittingSize:UILayoutFittingCompressedSize];
        //LOG(@"size : %@", NSStringFromCGSize(size));
        return CGSizeMake(300, size.height);
    } else if (indexPath.section == 2) {
        if (!_protoPointView) {
            _protoPointView = [ARTJobPointCellView art_createViewByNib];
        }
        CGRect rect = [_protoPointView setSellingPoints:[JobJobOtherPoint art_allEntiteisByJobId:self.jobId]];
        
        LOG(@"size : %@", NSStringFromCGRect(rect));
        return CGSizeMake(self.width, rect.size.height);
    }
    
    return CGSizeZero;
}

// フッターサイズ
- (CGSize)           collectionView:(UICollectionView *)collectionView
                             layout:(UICollectionViewLayout *)collectionViewLayout
    referenceSizeForFooterInSection:(NSInteger)section
{
    if (section == 0) {
        if ([self loadingViewState] == ARTLoadingViewStateLoading ||
            [self loadingViewState] == ARTLoadingViewStateNothing) {
            return CGSizeMake(self.width, 50);
        }
    }
    return CGSizeZero;
}

@end
