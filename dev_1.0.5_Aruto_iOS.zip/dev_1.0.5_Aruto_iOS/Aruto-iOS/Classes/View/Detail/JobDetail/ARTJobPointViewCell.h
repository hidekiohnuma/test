//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

#import "ARTJobPointCellView.h"

@interface ARTJobPointViewCell : UICollectionViewCell

@property (nonatomic, strong) ARTJobPointCellView *cellView;

@end
