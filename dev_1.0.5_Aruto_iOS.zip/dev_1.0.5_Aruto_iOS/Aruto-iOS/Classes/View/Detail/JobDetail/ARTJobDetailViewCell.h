//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

#import "ARTJobDetailCellView.h"

@interface ARTJobDetailViewCell : UICollectionViewCell

@property (nonatomic, strong) ARTJobDetailCellView *cellView;

@end
