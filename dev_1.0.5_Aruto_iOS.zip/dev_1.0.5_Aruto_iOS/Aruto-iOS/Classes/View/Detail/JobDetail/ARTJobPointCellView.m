//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTJobPointCellView.h"

#import "ARTTagList.h"

@interface ARTJobPointCellView ()

@property (nonatomic, strong) ARTTagList *tagList;

@end

@implementation ARTJobPointCellView

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    [self setTranslatesAutoresizingMaskIntoConstraints:NO];
}

- (CGRect)setSellingPoints:(NSArray *)pointArray
{
    LOG(@"before : %f", self.tagList.height);
    LOG(@"before : %@", NSStringFromCGRect(self.frame));
    
    if (!_tagList) {
        self.tagList = [[ARTTagList alloc] initWithFrame:CGRectMake(10, 0, self.width - 15, 0)];
        [self.tagList setAutomaticResize:YES];
        [self addSubview:self.tagList];
        
        self.tagList.viewOnly = YES;
        [self.tagList setCornerRadius:10.0f];
        [self.tagList setBorderColor:ART_BaseColor_Orange.CGColor];
        [self.tagList setBorderWidth:1.0f];
        [self.tagList setTagBackgroundColor:[UIColor clearColor]];
        [self.tagList setTextColor:art_UIColorWithRGBA(200, 100, 0, 1)];
    }
    
    NSMutableArray *array = [NSMutableArray array];
    
    for (int i = 0; i < pointArray.count; ++i) {
        JobJobOtherPoint *entity    = pointArray[i];
        NSString         *pointName = [JobOtherPoint art_nameForId:entity.jobOtherPointId];
        if (pointName && pointName.length > 0) {
            [array addObject:pointName];
        }
    }
    if (array.count == 0) {
        [array addObject:@"該当なし"];
    }
    
    [self.tagList setTags:array];
    self.height = self.tagList.height;
    LOG(@"after : %f", self.tagList.height);
    LOG(@"after : %@", NSStringFromCGRect(self.frame));
    
    return self.frame;
}

@end
