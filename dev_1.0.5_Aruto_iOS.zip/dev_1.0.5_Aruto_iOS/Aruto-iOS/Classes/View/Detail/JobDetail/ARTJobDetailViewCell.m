//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTJobDetailViewCell.h"

@implementation ARTJobDetailViewCell

- (void)dealloc
{
    LOG_METHOD;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.clipsToBounds = YES;
        
        [self setTranslatesAutoresizingMaskIntoConstraints:NO];
        
        self.cellView = [ARTJobDetailCellView art_createViewByNib];
        [self.contentView addSubview:self.cellView];
        [self.contentView art_pinAllEdgesOfSubview:self.cellView];
    }
    return self;
}

@end
