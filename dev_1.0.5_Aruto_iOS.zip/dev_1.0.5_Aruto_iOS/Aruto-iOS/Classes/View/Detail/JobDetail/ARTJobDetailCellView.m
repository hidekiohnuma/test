//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTJobDetailCellView.h"

@interface ARTJobDetailCellView ()

@property (nonatomic, weak) IBOutlet UILabel *titleLabel;

@end

@implementation ARTJobDetailCellView

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    self.clipsToBounds = YES;
    
    [self setTranslatesAutoresizingMaskIntoConstraints:NO];
}

- (void)setTitle:(NSString *)title
{
    self.titleLabel.text = title;
    
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect
{
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = self.bounds;
    UIBezierPath *maskPath;
    
    maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds
                                     byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight | UIRectCornerBottomLeft | UIRectCornerBottomRight
                                           cornerRadii:CGSizeMake(7, 7)];
    
    maskLayer.path  = maskPath.CGPath;
    self.layer.mask = maskLayer;
}

@end
