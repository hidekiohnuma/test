//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTDetailStaffInfoViewCell : UICollectionViewCell

- (void)setStaffData:(Staff *)entity;
- (void)setShopData:(Shop *)entity;

@end
