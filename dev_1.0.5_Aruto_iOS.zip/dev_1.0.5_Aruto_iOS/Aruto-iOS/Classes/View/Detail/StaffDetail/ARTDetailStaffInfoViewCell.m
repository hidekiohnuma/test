//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTDetailStaffInfoViewCell.h"

@interface ARTDetailStaffInfoViewCell ()

@property (nonatomic, weak) IBOutlet UILabel     *nameLabel;
@property (nonatomic, weak) IBOutlet UILabel     *sexLabel;
@property (nonatomic, weak) IBOutlet UILabel     *ageLabel;
@property (nonatomic, weak) IBOutlet UILabel     *storeLabel;
@property (nonatomic, weak) IBOutlet UILabel     *staffImageLabel;
@property (nonatomic, weak) IBOutlet UIImageView *imageView;

@end

@implementation ARTDetailStaffInfoViewCell

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    self.nameLabel.adjustsFontSizeToFitWidth = YES;
    self.ageLabel.adjustsFontSizeToFitWidth  = YES;

    self.imageView.layer.cornerRadius = self.imageView.width * 0.5;

    self.imageView.layer.borderColor = art_UIColorWithRGBA(255, 212, 100, 0.7).CGColor;
    self.imageView.layer.borderWidth = 3;
}

- (void)setStaffData:(Staff *)entity
{
    if (!entity) { return; }

    self.nameLabel.text = entity.name.copy;

    if (entity.sexId.integerValue == 1) {
        self.sexLabel.text = @"男性";
    } else {
        self.sexLabel.text = @"女性";
    }
    if (entity.birthday) {
        self.ageLabel.text = [Generation art_generationForAge:@([entity.birthday art_ageForDate])];
    } else {
        self.ageLabel.text = nil;
    }
    
    if (entity.privateImageURL) {
        self.imageView.hidden = NO;
        self.staffImageLabel.hidden = NO;
        [self.imageView art_setImageWithURL:[NSURL URLWithString:entity.privateImageURL]
                           placeholderImage:[UIImage imageNamed:@"no_image_private"]
                                    noImage:[UIImage imageNamed:@"no_image_private"]
                                      alpha:1
                                 parentView:nil
                              needAnimation:YES];
    } else {
        self.imageView.hidden = YES;
        self.staffImageLabel.hidden = YES;
    }
}

- (void)setShopData:(Shop *)entity
{
    if (!entity) { return; }

    self.storeLabel.text = [Shop art_shopNameForShop:entity];
}

@end
