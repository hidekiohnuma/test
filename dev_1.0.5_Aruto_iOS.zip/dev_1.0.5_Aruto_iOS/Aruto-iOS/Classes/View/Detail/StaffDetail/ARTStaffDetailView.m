//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTStaffDetailView.h"

#import <ARNHeaderStretchFlowLayout.h>

#import "ARTDetailHeaderView.h"
#import "ARTDetailSectionHeaderView.h"
#import "ARTLoadingFooterView.h"

#import "ARTDetailHorizontalViewCell.h"
#import "ARTDetailVerticalViewCell.h"

#import "ARTDetailStaffInfoViewCell.h"

#import "ARTStaffUO.h"

@interface ARTStaffDetailView ()

@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;
@property (nonatomic, weak) IBOutlet UIButton         *storeDetailButton;
@property (nonatomic, weak) IBOutlet UIButton         *favoriteButton;

@property (nonatomic, assign) BOOL            isLoading;
@property (nonatomic, copy) NSNumber         *staffId;
@property (nonatomic, strong) Staff          *staffData;
@property (nonatomic, strong) NSMutableArray *workQAArray;
@property (nonatomic, strong) NSMutableArray *schoolArray;
@property (nonatomic, strong) NSMutableArray *privateQAArray;
@property (nonatomic, strong) NSMutableArray *favoriteQAArray;
@property (nonatomic, strong) NSMutableArray *otherQAArray;

@property (nonatomic, strong) ARTDetailHorizontalCellView *protoHorizontalView;
@property (nonatomic, strong) ARTDetailVerticalCellView *protoVerticalView;

@end

@implementation ARTStaffDetailView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    self.collectionView.contentInset = UIEdgeInsetsMake(0, 0, 44, 0);
    
    ARNHeaderStretchFlowLayout *viewLayout = ARNHeaderStretchFlowLayout.new;
    [viewLayout setSectionInset:UIEdgeInsetsMake(0.0, 0.0, 10.0, 0.0)];
    [viewLayout setItemSize:CGSizeMake(self.width, 60)];
    [viewLayout setHeaderReferenceSize:CGSizeMake(self.width, 240)];
    viewLayout.minimumLineSpacing      = 0;
    viewLayout.minimumInteritemSpacing = 0;
    [self.collectionView setCollectionViewLayout:viewLayout];
    
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTDetailHeaderView class]) bundle:nil]
          forSupplementaryViewOfKind:UICollectionElementKindSectionHeader
                 withReuseIdentifier:NSStringFromClass([ARTDetailHeaderView class])];
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTDetailSectionHeaderView class]) bundle:nil]
          forSupplementaryViewOfKind:UICollectionElementKindSectionHeader
                 withReuseIdentifier:NSStringFromClass([ARTDetailSectionHeaderView class])];
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTLoadingFooterView class]) bundle:nil]
          forSupplementaryViewOfKind:UICollectionElementKindSectionFooter
                 withReuseIdentifier:NSStringFromClass([ARTLoadingFooterView class])];
    
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTDetailStaffInfoViewCell class]) bundle:nil]
          forCellWithReuseIdentifier:NSStringFromClass([ARTDetailStaffInfoViewCell class])];
    
    [self.collectionView registerClass:[ARTDetailHorizontalViewCell class]
            forCellWithReuseIdentifier:NSStringFromClass([ARTDetailHorizontalViewCell class])];
    
    [self.collectionView registerClass:[ARTDetailVerticalViewCell class]
            forCellWithReuseIdentifier:NSStringFromClass([ARTDetailVerticalViewCell class])];
    
    self.storeDetailButton.exclusiveTouch = YES;
    self.favoriteButton.exclusiveTouch    = YES;
    
    __weak typeof(self) weakSelf = self;
    
    [ARTUtils addNotisForName:ARTNofiricationFavoriteStaffChenged
                        block:^(NSNotification *note) {
                            NSNumber *staffId = note.object;
                            if (!staffId) { return; }
                            if (weakSelf.staffId.integerValue == staffId.integerValue) {
                                [weakSelf updateButton];
                            }
                        }];
}

- (void)setStaffId:(NSNumber *)staffId
{
    _staffId = staffId;
    
    if ([[ARTUOCacheManager shared] containsStaffId:_staffId]) {
        [self reloadData];
        if (!self.staffData) {
            [self startUO];
        }
    } else {
        [self startUO];
    }
}

- (void)reloadData
{
    if (!self.staffId) { return; }
    
    self.staffData = [Staff art_staffWithStaffId:self.staffId localContext:nil];
    
    [ARTStaffUO uoPostAccessCountWithTarget:self staffId:_staffId];
    [self.parentController setHeaderImageForURL:[NSURL URLWithString:self.staffData.workImageURL]];
    
    self.workQAArray     = [NSMutableArray array];
    self.privateQAArray  = [NSMutableArray array];
    self.favoriteQAArray = [NSMutableArray array];
    self.otherQAArray    = [NSMutableArray array];
    [self setQAArray:self.workQAArray qaDict:self.staffData.workAnswers];
    [self setQAArray:self.privateQAArray qaDict:self.staffData.privateAnswers];
    [self setQAArray:self.favoriteQAArray qaDict:self.staffData.favoriteAnswers];
    [self setQAArray:self.otherQAArray qaDict:self.staffData.otherAnswers];
    
    self.schoolArray     = [NSMutableArray array];
    if (self.staffData.collegeId) {
        [self.schoolArray addObject:@{@"大学" : [School art_nameForId:self.staffData.collegeId]}];
    }
    if (self.staffData.highschoolId) {
        [self.schoolArray addObject:@{@"高校" : [School art_nameForId:self.staffData.highschoolId]}];
    }
    if (self.staffData.hometownPrefectureId) {
        [self.schoolArray addObject:@{@"出身地" : [Prefecture art_nameForId:self.staffData.hometownPrefectureId]}];
    }
    
    [self updateButton];
    
    if (!self.staffData) {
        [ARTUtils showPopControllerAlertWithTitle:@"エラー"
                                          message:@"該当のスタッフ情報を取得出来ませんでした"];
    } else {
        [[ARTUOCacheManager shared] addStaffId:self.staffId.copy];
        [self.collectionView reloadData];
    }
}

- (void)updateButton
{
    if ([FavoriteStaff art_isFavoriteForStaffId:self.staffId]) {
        [self.favoriteButton art_setTitleForAddFavorite:NO];
    } else {
        [self.favoriteButton art_setTitleForAddFavorite:YES];
    }
}

- (void)setQAArray:(NSMutableArray *)array qaDict:(NSDictionary *)qaDict
{
    for (id key in[qaDict keyEnumerator]) {
        [array addObject:[NSDictionary dictionaryWithObject:[qaDict valueForKey:key] forKey:key]];
    }
}

- (void)startUO
{
    self.isLoading                 = YES;
    self.favoriteButton.enabled    = NO;
    self.storeDetailButton.enabled = NO;
    
    __weak typeof(self) weakSelf = self;
    
    [ARTStaffUO uoGetStaffWithTarget:self
                             staffId:self.staffId.copy
                     completionBlock: ^(id resultObject) {
                         if (!weakSelf) { return; }
                         weakSelf.isLoading = NO;
                         weakSelf.favoriteButton.enabled = YES;
                         weakSelf.storeDetailButton.enabled = YES;
                         
                         if ([resultObject isKindOfClass:[NSError class]]) {
                             NSError *error = (NSError *)resultObject;
                             [ARTUtils showPopControllerAlertWithTitle:error.localizedDescription
                                                               message:error.localizedFailureReason];
                         } else {
                             [weakSelf reloadData];
                         }
                     }];
}

- (IBAction)tapStoreDetailButton:(UIButton *)sender
{
    [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory storeDetailViewControllerWithShopId:self.staffData.shopId]];
}

- (IBAction)tapFavoriteButton:(UIButton *)sender
{
    if (![self.favoriteButton art_canChangeFavorite]) { return; }
    
    if ([FavoriteStaff art_isFavoriteForStaffId:self.staffId]) {
        [self.favoriteButton art_removeFavoriteForStaffId:self.staffId];
    } else {
        [self.favoriteButton art_addFavoriteForStaffId:self.staffId];
    }
}

- (BOOL)isLastAtIndexPath:(NSIndexPath *)indexPath;
{
    NSInteger rowCount = [self.collectionView numberOfItemsInSection:indexPath.section];
    if (indexPath.row == (rowCount - 1)) {
        return YES;
    }
    return NO;
}

- (ARTLoadingViewState)loadingViewState
{
    if (self.staffData && !self.isLoading) {
        return ARTLoadingViewStateFinishLoading;
    }
    return ARTLoadingViewStateLoading;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView DataSource

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 6;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (!self.staffData) { return 0; }
    
    if (section == 0) {
        return 1;
    } else if (section == 1) {
        return self.workQAArray.count;
    } else if (section == 2) {
        return self.schoolArray.count;
    } else if (section == 3) {
        return self.favoriteQAArray.count;
    } else if (section == 4) {
        return self.privateQAArray.count;
    } else if (section == 5) {
        return self.otherQAArray.count;
    }
    return 0;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        ARTDetailStaffInfoViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTDetailStaffInfoViewCell class])
                                                                                     forIndexPath:indexPath];
        
        [cell setStaffData:self.staffData];
        
        Shop *shopData = [Shop art_shopWithShopId:self.staffData.shopId localContext:nil];
        [cell setShopData:shopData];
        
        return cell;
    } else if (indexPath.section == 2 ||
               indexPath.section == 4) {
        ARTDetailHorizontalViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTDetailHorizontalViewCell class])
                                                                                      forIndexPath:indexPath];
        [self configureCellView:cell.cellView indexPath:indexPath];
        
        return cell;
    } else {
        ARTDetailVerticalViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTDetailVerticalViewCell class])
                                                                                    forIndexPath:indexPath];
        [self configureCellView:cell.cellView indexPath:indexPath];
        
        return cell;
    }
}

- (void)configureCellView:(ARTDetailBaseCellView *)cellView indexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 1) {
        NSDictionary *dict = [self.workQAArray objectAtIndex:indexPath.row];
        for (id key in[dict keyEnumerator]) {
            [cellView setTitle:[StaffOtherQuestion art_questionTitleForName:key]
                        detail:[dict valueForKey:key]
                       isFirst:(indexPath.row == 0) isLast:[self isLastAtIndexPath:indexPath]];
        }
    } else if (indexPath.section == 2) {
        NSDictionary *dict = [self.schoolArray objectAtIndex:indexPath.row];
        for (id key in[dict keyEnumerator]) {
            [cellView setTitle:dict.allKeys[0]
                        detail:[dict valueForKey:key]
                       isFirst:(indexPath.row == 0) isLast:[self isLastAtIndexPath:indexPath]];
        }
    } else if (indexPath.section == 3) {
        NSDictionary *dict = [self.favoriteQAArray objectAtIndex:indexPath.row];
        for (id key in[dict keyEnumerator]) {
            [cellView setTitle:[StaffOtherQuestion art_questionTitleForName:key]
                        detail:[dict valueForKey:key]
                       isFirst:(indexPath.row == 0) isLast:[self isLastAtIndexPath:indexPath]];
        }
    } else if (indexPath.section == 4) {
        NSDictionary *dict = [self.privateQAArray objectAtIndex:indexPath.row];
        for (id key in[dict keyEnumerator]) {
            [cellView setTitle:[StaffOtherQuestion art_questionTitleForName:key]
                        detail:[dict valueForKey:key]
                       isFirst:(indexPath.row == 0) isLast:[self isLastAtIndexPath:indexPath]];
        }
    } else if (indexPath.section == 5) {
        NSDictionary *dict = [self.otherQAArray objectAtIndex:indexPath.row];
        for (id key in[dict keyEnumerator]) {
            [cellView setTitle:[StaffOtherQuestion art_questionTitleForName:key]
                        detail:[dict valueForKey:key]
                       isFirst:(indexPath.row == 0) isLast:[self isLastAtIndexPath:indexPath]];
        }
    }
}

// ヘッダー・フッター設定
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView
           viewForSupplementaryElementOfKind:(NSString *)kind
                                 atIndexPath:(NSIndexPath *)indexPath
{
    if ([kind isEqualToString:UICollectionElementKindSectionHeader]) {
        if (indexPath.section == 0) {
            ARTDetailHeaderView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind
                                                                                 withReuseIdentifier:NSStringFromClass([ARTDetailHeaderView class])
                                                                                        forIndexPath:indexPath];
            if (self.staffData.workImageURL) {
                [headerView setImageWithURLArray:@[self.staffData.workImageURL]];
            }
            
            return headerView;
        } else {
            ARTDetailSectionHeaderView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind
                                                                                        withReuseIdentifier:NSStringFromClass([ARTDetailSectionHeaderView class])
                                                                                               forIndexPath:indexPath];
            if (indexPath.section == 1) {
                [headerView setTitle:@"仕事について"];
            } else if (indexPath.section == 2) {
                [headerView setTitle:@"学校・出身地"];
            } else if (indexPath.section == 3) {
                [headerView setTitle:@"趣味、好きなこと"];
            } else if (indexPath.section == 4) {
                [headerView setTitle:@"プライベート"];
            } else if (indexPath.section == 5) {
                [headerView setTitle:@"アピールポイント、求める仲間"];
            }
            
            return headerView;
        }
    }
    if ([kind isEqualToString:UICollectionElementKindSectionFooter]) {
        ARTLoadingFooterView *footerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind
                                                                              withReuseIdentifier:NSStringFromClass([ARTLoadingFooterView class])
                                                                                     forIndexPath:indexPath];
        
        [footerView setViewState:[self loadingViewState] completion:nil];
        
        return footerView;
    }
    return nil;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionViewFlowLayout Delegate

// ヘッダーサイズ
- (CGSize)           collectionView:(UICollectionView *)collectionView
                             layout:(UICollectionViewLayout *)collectionViewLayout
    referenceSizeForHeaderInSection:(NSInteger)section
{
    if (!self.staffData) { return CGSizeZero; }
    
    if (section == 0) {
        return CGSizeMake(self.width, 240);
    } else {
        if (![collectionView numberOfItemsInSection:section]) {
            return CGSizeZero;
        }
        return CGSizeMake(self.width, 40);
    }
}

- (CGSize)  collectionView:(UICollectionView *)collectionView
                    layout:(UICollectionViewLayout *)collectionViewLayout
    sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return CGSizeMake(self.width, 110);
    } else if (indexPath.section == 2 ||
               indexPath.section == 4) {
        if (!_protoHorizontalView) {
            _protoHorizontalView = [ARTDetailHorizontalCellView art_createViewByNib];
        }
        [self configureCellView:_protoHorizontalView indexPath:indexPath];
        CGSize size = [_protoHorizontalView systemLayoutSizeFittingSize:UILayoutFittingCompressedSize];
        return CGSizeMake(300, size.height);
    } else {
        if (!_protoVerticalView) {
            _protoVerticalView = [ARTDetailVerticalCellView art_createViewByNib];
        }
        [self configureCellView:_protoVerticalView indexPath:indexPath];
        CGSize size = [_protoVerticalView systemLayoutSizeFittingSize:UILayoutFittingCompressedSize];
        return CGSizeMake(300, size.height);
    }
}

// フッターサイズ
- (CGSize)           collectionView:(UICollectionView *)collectionView
                             layout:(UICollectionViewLayout *)collectionViewLayout
    referenceSizeForFooterInSection:(NSInteger)section
{
    if (section == 0) {
        if ([self loadingViewState] == ARTLoadingViewStateLoading ||
            [self loadingViewState] == ARTLoadingViewStateNothing) {
            return CGSizeMake(self.width, 50);
        }
    }
    return CGSizeZero;
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    if (![collectionView numberOfItemsInSection:section]) {
        return UIEdgeInsetsMake(0.0, 0.0, 0.0, 0.0);
    }
    return UIEdgeInsetsMake(0.0, 0.0, 10.0, 0.0);
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UIScrollView Delegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [(ARTBaseViewController *)self.parentController scrollHeadeForscrollView : scrollView];
    //LOG(@"%@", NSStringFromCGPoint(scrollView.contentOffset));
}

@end
