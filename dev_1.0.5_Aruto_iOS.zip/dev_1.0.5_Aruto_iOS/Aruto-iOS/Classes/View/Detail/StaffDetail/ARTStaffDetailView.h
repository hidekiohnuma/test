//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTStaffDetailView : ARTBaseContentsView

- (void)setStaffId:(NSNumber *)staffId;

@end
