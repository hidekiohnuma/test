//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTStoreDetailMemberViewCell.h"

@interface ARTStoreDetailMemberViewCell ()

@property (nonatomic, weak) IBOutlet UIImageView *imageView;

@end

@implementation ARTStoreDetailMemberViewCell

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    self.contentView.layer.cornerRadius = self.width * 0.5;
    
    self.imageView.layer.cornerRadius = self.imageView.width * 0.5;
    self.imageView.layer.borderColor  = art_UIColorWithRGBA(255, 212, 100, 0.7).CGColor;
    self.imageView.layer.borderWidth  = 3;
}

- (void)setImageURL:(NSURL *)imageURL
{
    [self.imageView art_setImageWithURL:imageURL
                       placeholderImage:[UIImage imageNamed:@"no_image_private"]
                                noImage:[UIImage imageNamed:@"no_image_private"]
                                  alpha:1
                             parentView:nil
                          needAnimation:YES];
}

@end
