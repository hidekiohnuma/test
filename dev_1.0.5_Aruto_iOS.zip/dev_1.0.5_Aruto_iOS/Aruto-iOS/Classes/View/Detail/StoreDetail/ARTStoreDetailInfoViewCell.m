//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTStoreDetailInfoViewCell.h"

@interface ARTStoreDetailInfoViewCell ()

@property (nonatomic, weak) IBOutlet UIButton *infoButton;
@property (nonatomic, weak) IBOutlet UIButton *otherButton;
@property (nonatomic, weak) IBOutlet UILabel  *textLabel;

@property (nonatomic, copy) NSString *infoString;
@property (nonatomic, copy) NSString *otherString;

@end

@implementation ARTStoreDetailInfoViewCell

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    self.infoButton.exclusiveTouch = YES;
    [self.infoButton setBackgroundImage:[ARTUtils imageWithColor:art_UIColorWithRGBA(229, 187, 49, 1)] forState:UIControlStateNormal];
    [self.infoButton setBackgroundImage:[ARTUtils imageWithColor:[UIColor whiteColor]] forState:UIControlStateHighlighted];
    [self.infoButton setBackgroundImage:[ARTUtils imageWithColor:[UIColor whiteColor]] forState:UIControlStateSelected];
    self.infoButton.layer.borderWidth = 0.5;
    self.infoButton.layer.borderColor = [UIColor whiteColor].CGColor;

    self.otherButton.exclusiveTouch = YES;
    [self.otherButton setBackgroundImage:[ARTUtils imageWithColor:art_UIColorWithRGBA(229, 187, 49, 1)] forState:UIControlStateNormal];
    [self.otherButton setBackgroundImage:[ARTUtils imageWithColor:[UIColor whiteColor]] forState:UIControlStateHighlighted];
    [self.otherButton setBackgroundImage:[ARTUtils imageWithColor:[UIColor whiteColor]] forState:UIControlStateSelected];
    self.otherButton.layer.borderWidth = 0.5;
    self.otherButton.layer.borderColor = [UIColor whiteColor].CGColor;
}

- (void)setInfo:(NSString *)info other:(NSString *)other
{
    self.infoString  = info;
    self.otherString = other;
}

- (void)dispIsInfo:(BOOL)isInfoDisp
{
    if (isInfoDisp) {
        [self dispInfo];
    } else {
        [self dispOther];
    }
}

- (void)dispInfo
{
    self.infoButton.selected  = YES;
    self.otherButton.selected = NO;

    self.textLabel.text = self.infoString;
    [self.textLabel sizeToFit];
}

- (void)dispOther
{
    self.infoButton.selected  = NO;
    self.otherButton.selected = YES;

    self.textLabel.text = self.otherString;
    [self.textLabel sizeToFit];
}

- (IBAction)tapInfoButton:(UIButton *)sender
{
    [ARTPopping scaleAnimationWithView:self.infoButton];
    [self dispInfo];
    art_SafeBlockCall(self.buttonTapBlock, YES);
}

- (IBAction)tapOtherButton:(UIButton *)sender
{
    [ARTPopping scaleAnimationWithView:self.otherButton];
    [self dispOther];
    art_SafeBlockCall(self.buttonTapBlock, NO);
}

@end
