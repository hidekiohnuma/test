//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTStoreDetailStaffGroupViewCell.h"
#import "ARTStoreDetailMemberViewCell.h"

@interface ARTStoreDetailStaffGroupViewCell ()

@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;

@property (nonatomic, strong) NSArray *staffRowData;

@end

@implementation ARTStoreDetailStaffGroupViewCell

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTStoreDetailMemberViewCell class]) bundle:nil]
          forCellWithReuseIdentifier:NSStringFromClass([ARTStoreDetailMemberViewCell class])];
}

- (void)setMemberForShopId:(NSNumber *)shopId
{
    if (!shopId) { return; }

    self.staffRowData = [Staff art_staffListForShopId:shopId];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView DataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.staffRowData.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    ARTStoreDetailMemberViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTStoreDetailMemberViewCell class])
                                                                           forIndexPath:indexPath];
    
    Staff *entity = self.staffRowData[indexPath.row];
    [cell setImageURL:[NSURL URLWithString:entity.thumbnailURL2]];
    
    return cell;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView Delegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
    [ARTPopping poppinAnimationWithView:cell];

    Staff *staffData = self.staffRowData[indexPath.row];
    [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory staffDetailViewControllerWithStaffId:staffData.identifier]];
}

@end
