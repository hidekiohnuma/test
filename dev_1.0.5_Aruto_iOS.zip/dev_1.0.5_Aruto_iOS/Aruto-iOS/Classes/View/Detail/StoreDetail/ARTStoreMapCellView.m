//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTStoreMapCellView.h"
#import "ARTStoreAnnotation.h"

@import MapKit;
@import CoreLocation;

@interface ARTStoreMapCellView ()

@property (nonatomic, weak) IBOutlet MKMapView *mapView;
@property (nonatomic, weak) IBOutlet UIButton *closeButton;

@end

@implementation ARTStoreMapCellView

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    [self setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    self.closeButton.hidden = YES;
    
    self.closeButton.exclusiveTouch = YES;
    self.closeButton.layer.cornerRadius = self.closeButton.width * 0.5;
    [self.closeButton setImage:[IonIcons imageWithIcon:ion_close_round
                                             iconColor:ART_BaseColor_Orange
                                              iconSize:30
                                             imageSize:CGSizeMake(30, 30)]
                      forState:UIControlStateNormal];
    
    self.layer.borderColor = art_UIColorWithRGBA(255, 212, 100, 0.7).CGColor;
    self.layer.borderWidth = 3;
}

- (void)setFullScreenMode:(BOOL)isFullScreen
{
    if (isFullScreen) {
        self.closeButton.hidden = NO;
        self.layer.cornerRadius = 0;
    } else {
        self.closeButton.hidden = YES;
        self.layer.cornerRadius = 5.5;
    }
}

- (void)setLocationAtAddressString:(NSString *)addressString
{
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    
    __weak typeof(self) weakSelf = self;
    [geocoder geocodeAddressString:addressString
                 completionHandler:^(NSArray* placemarks, NSError* error) {
                     for (CLPlacemark* placemark in placemarks) {
                         
                         [weakSelf.mapView setCenterCoordinate:placemark.location.coordinate animated:NO];
                         
                         MKCoordinateRegion region = weakSelf.mapView.region;
                         region.span.latitudeDelta = 0.001;
                         region.span.longitudeDelta = 0.001;
                         [weakSelf.mapView setRegion:region animated:NO];
                         
                         ARTStoreAnnotation *pin = [[ARTStoreAnnotation alloc] initWithCoordinate:placemark.location.coordinate];
                         [weakSelf.mapView addAnnotation:pin];
                         
                         break;
                     }
                 }];
}

- (IBAction)tapDetailButton:(UIButton *)sender
{
    [self setFullScreenMode:NO];
    art_SafeBlockCall(self.buttonTapBlock);
}

@end
