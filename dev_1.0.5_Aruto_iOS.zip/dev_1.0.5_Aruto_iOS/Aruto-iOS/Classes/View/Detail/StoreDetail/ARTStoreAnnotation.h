//
//  ARTStoreAnnotation.h
//  Aruto-iOS
//
//  Created by Yos on 2014/10/17.
//  Copyright (c) 2014年 Aruto Corp. All rights reserved.
//

#import <Foundation/Foundation.h>

@import MapKit;

@interface ARTStoreAnnotation : NSObject <MKAnnotation>

@property (nonatomic, readonly) CLLocationCoordinate2D coordinate;
@property (nonatomic, copy) NSString* subtitle;
@property (nonatomic, copy) NSString* title;

- (instancetype)initWithCoordinate:(CLLocationCoordinate2D)coordinate;

@end
