//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTStoreMapViewCell.h"

@implementation ARTStoreMapViewCell

- (void)dealloc
{
    LOG_METHOD;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self)
    {
        self.clipsToBounds = YES;
        
        [self setTranslatesAutoresizingMaskIntoConstraints:NO];
        
        self.cellView = [ARTStoreMapCellView art_createViewByNib];
        [self.contentView addSubview:self.cellView];
        [self.contentView art_pinAllEdgesOfSubview:self.cellView];
    }
    return self;
}

@end
