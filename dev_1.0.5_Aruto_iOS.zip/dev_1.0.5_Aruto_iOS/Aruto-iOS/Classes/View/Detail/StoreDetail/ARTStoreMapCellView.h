//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

@interface ARTStoreMapCellView : UIView

@property (nonatomic, copy) void (^buttonTapBlock)();

- (void)setFullScreenMode:(BOOL)isFullScreen;

- (void)setLocationAtAddressString:(NSString *)addressString;

@end
