//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTStoreDetailView.h"

#import <ARNHeaderStretchFlowLayout.h>

#import "ARTDetailHeaderView.h"
#import "ARTDetailSectionHeaderView.h"

#import "ARTDetailHorizontalViewCell.h"
#import "ARTDetailVerticalViewCell.h"
#import "ARTStoreJobViewCell.h"
#import "ARTStoreMapViewCell.h"
#import "ARTLoadingFooterView.h"

#import "ARTStoreDetailStaffGroupViewCell.h"
#import "ARTStoreDetailInfoViewCell.h"

#import "ARTShopUO.h"

@interface ARTStoreDetailView ()

@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;
@property (nonatomic, weak) IBOutlet UIButton         *entryButton;
@property (nonatomic, weak) IBOutlet UIButton         *favoriteButton;

@property (nonatomic, assign) BOOL     isLoading;
@property (nonatomic, copy) NSNumber  *shopId;
@property (nonatomic, strong) Shop    *shopData;
@property (nonatomic, strong) NSArray *jobArray;
@property (nonatomic, assign) BOOL     isMapFullScreen;

@property (nonatomic, strong) ARTDetailVerticalCellView *protoVerticalView;

@end

@implementation ARTStoreDetailView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    self.collectionView.contentInset = UIEdgeInsetsMake(0, 0, 44, 0);
    
    [self reloadFlowLayout];
    
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTDetailHeaderView class]) bundle:nil]
          forSupplementaryViewOfKind:UICollectionElementKindSectionHeader
                 withReuseIdentifier:NSStringFromClass([ARTDetailHeaderView class])];
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTDetailSectionHeaderView class]) bundle:nil]
          forSupplementaryViewOfKind:UICollectionElementKindSectionHeader
                 withReuseIdentifier:NSStringFromClass([ARTDetailSectionHeaderView class])];
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTLoadingFooterView class]) bundle:nil]
          forSupplementaryViewOfKind:UICollectionElementKindSectionFooter
                 withReuseIdentifier:NSStringFromClass([ARTLoadingFooterView class])];
    
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTStoreDetailStaffGroupViewCell class]) bundle:nil]
          forCellWithReuseIdentifier:NSStringFromClass([ARTStoreDetailStaffGroupViewCell class])];
    
    [self.collectionView registerClass:[ARTDetailHorizontalViewCell class]
            forCellWithReuseIdentifier:NSStringFromClass([ARTDetailHorizontalViewCell class])];
    
    [self.collectionView registerClass:[ARTDetailVerticalViewCell class]
            forCellWithReuseIdentifier:NSStringFromClass([ARTDetailVerticalViewCell class])];
    
    [self.collectionView registerClass:[ARTStoreJobViewCell class]
            forCellWithReuseIdentifier:NSStringFromClass([ARTStoreJobViewCell class])];
    
    [self.collectionView registerClass:[ARTStoreMapViewCell class]
            forCellWithReuseIdentifier:NSStringFromClass([ARTStoreMapViewCell class])];
    
    self.entryButton.exclusiveTouch    = YES;
    self.favoriteButton.exclusiveTouch = YES;
    
    __weak typeof(self) weakSelf = self;
    [ARTUtils addNotisForName:ARTNofiricationFavoriteShopChenged
                        block:^(NSNotification *note) {
                            NSNumber *shopId = note.object;
                            if (!shopId) { return; }
                            if (weakSelf.shopId.integerValue == shopId.integerValue) {
                                [weakSelf updateButton];
                            }
                        }];
}

- (void)reloadFlowLayout
{
    ARNHeaderStretchFlowLayout *viewLayout = ARNHeaderStretchFlowLayout.new;
    [viewLayout setSectionInset:UIEdgeInsetsMake(0.0, 0.0, 10.0, 0.0)];
    [viewLayout setItemSize:CGSizeMake(self.width, 70)];
    [viewLayout setHeaderReferenceSize:CGSizeMake(self.width, 240)];
    viewLayout.minimumLineSpacing      = 0;
    viewLayout.minimumInteritemSpacing = 0;
    __weak typeof(self) weakSelf = self;
    [self.collectionView setCollectionViewLayout:viewLayout animated:YES completion:^(BOOL finished) {
        [weakSelf.collectionView reloadSections:[NSIndexSet indexSetWithIndex:5]];
        if (weakSelf.isMapFullScreen) {
            weakSelf.collectionView.scrollEnabled = NO;
        } else {
            weakSelf.collectionView.scrollEnabled = YES;
        }
    }];;
}

- (void)setShopId:(NSNumber *)shopId
{
    _shopId = shopId;
    
    if ([[ARTUOCacheManager shared] containsShopId:_shopId]) {
        [self reloadData];
        if (!self.shopData) {
            [self startUO];
        }
    } else {
        [self startUO];
    }
}

- (void)reloadData
{
    if (!self.shopId) { return; }
    
    self.shopData = [Shop art_shopWithShopId:self.shopId localContext:nil];
    [self.parentController setHeaderImageForURL:[NSURL URLWithString:self.shopData.image1URL]];
    
    self.jobArray = [Job art_jobListForShopId:self.shopData.identifier];
    
    [self updateButton];
    
    if (!self.shopData) {
        [ARTUtils showPopControllerAlertWithTitle:@"エラー"
                                          message:@"該当の店舗情報を取得出来ませんでした"];
    } else {
        [[ARTUOCacheManager shared] addShopId:self.shopId.copy];
        [self.collectionView reloadData];
    }
}

- (void)updateButton
{
    if ([FavoriteShop art_isFavoriteForShopId:self.shopId]) {
        [self.favoriteButton art_setTitleForAddFavorite:NO];
    } else {
        [self.favoriteButton art_setTitleForAddFavorite:YES];
    }
}

- (void)startUO
{
    self.isLoading              = YES;
    self.favoriteButton.enabled = NO;
    self.entryButton.enabled    = NO;
    
    __weak typeof(self) weakSelf = self;
    
    [ARTShopUO uoGetShopWithTarget:self
                            shopId:self.shopId.copy
                   completionBlock: ^(id resultObject) {
                       if (!weakSelf) { return; }
                       weakSelf.isLoading = NO;
                       weakSelf.favoriteButton.enabled = YES;
                       weakSelf.entryButton.enabled = YES;
                       
                       if ([resultObject isKindOfClass:[NSError class]]) {
                           NSError *error = (NSError *)resultObject;
                           [ARTUtils showPopControllerAlertWithTitle:error.localizedDescription
                                                             message:error.localizedFailureReason];
                       } else {
                           [weakSelf reloadData];
                       }
                   }];
}

- (IBAction)tapEntryButton:(UIButton *)sender
{
    [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory entryViewControllerWithShopId:self.shopId]];
}

- (IBAction)tapFavoriteButton:(UIButton *)sender
{
    if (![self.favoriteButton art_canChangeFavorite]) { return; }
    
    if ([FavoriteShop art_isFavoriteForShopId:self.shopId]) {
        [self.favoriteButton art_removeFavoriteForShopId:self.shopId];
    } else {
        [self.favoriteButton art_addFavoriteForShopId:self.shopId];
    }
}

- (ARTLoadingViewState)loadingViewState
{
    if (self.shopData && !self.isLoading) {
        return ARTLoadingViewStateFinishLoading;
    }
    return ARTLoadingViewStateLoading;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView DataSource

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 6;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (!self.shopData) { return 0; }
    
    if (section == 0) {
        return 0;
    } else if (section == 1) {
        return 1;
    } else if (section == 2) {
        return 4;
    } else if (section == 3) {
        return self.jobArray.count;
    } else if (section == 4) {
        return 4;
    } else if (section == 5) {
        return 1;
    }
    
    return 0;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 1) {
        ARTStoreDetailStaffGroupViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTStoreDetailStaffGroupViewCell class])
                                                                                           forIndexPath:indexPath];
        [cell setMemberForShopId:self.shopId];
        
        return cell;
    } else if (indexPath.section == 3) {
        ARTStoreJobViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTStoreJobViewCell class])
                                                                              forIndexPath:indexPath];
        Job *entity = [self.jobArray objectAtIndex:indexPath.row];
#ifdef DEBUG
        [cell.cellView setTitle:[NSString stringWithFormat:@"%@ %@", [JobType art_nameForId:entity.jobTypeId], entity.identifier]
                        isFirst:(indexPath.row == 0)
                         isLast:(indexPath.row == (self.jobArray.count - 1))];
#else
        [cell.cellView setTitle:[JobType art_nameForId:entity.jobTypeId]
                        isFirst:(indexPath.row == 0)
                         isLast:(indexPath.row == (self.jobArray.count - 1))];
#endif
      
        cell.cellView.buttonTapBlock = ^{
            [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory jobDetailViewControllerWithJobId:entity.identifier showEntryButton:YES]];
        };
        
        return cell;
    } else if (indexPath.section == 2 || indexPath.section == 4) {
        ARTDetailVerticalViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTDetailVerticalViewCell class])
                                                                                    forIndexPath:indexPath];
        
        [self configureCellView:cell.cellView indexPath:indexPath];
        
        return cell;
    } else if (indexPath.section == 5) {
        ARTStoreMapViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTStoreMapViewCell class])
                                                                              forIndexPath:indexPath];
        
        if (self.shopData.address3) {
            [cell.cellView setLocationAtAddressString:[NSString stringWithFormat:@"%@ %@ %@", self.shopData.address1, self.shopData.address2, self.shopData.address3]];
        } else {
            [cell.cellView setLocationAtAddressString:[NSString stringWithFormat:@"%@ %@", self.shopData.address1, self.shopData.address2]];
        }
        [cell.cellView setFullScreenMode:self.isMapFullScreen];
        
        __weak typeof(self) weakSelf = self;
        cell.cellView.buttonTapBlock = ^{
            weakSelf.isMapFullScreen = NO;
            [weakSelf reloadFlowLayout];
        };
        
        return cell;
    }
    
    return nil;
}

- (void)configureCellView:(ARTDetailBaseCellView *)cellView indexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            [cellView setTitle:@"お店の特徴"
                        detail:self.shopData.shopFeature
                       isFirst:YES isLast:NO];
        } else if (indexPath.row == 1) {
            [cellView setTitle:@"平均年齢"
                        detail:[NSString stringWithFormat:@"%@", self.shopData.ageAverage]
                       isFirst:NO isLast:NO];
        } else if (indexPath.row == 2) {
            [cellView setTitle:@"男女比"
                        detail:self.shopData.gendarRatio
                       isFirst:NO isLast:NO];
        } else if (indexPath.row == 3) {
            [cellView setTitle:@"店長・リーダーの声"
                        detail:self.shopData.leaderComment
                       isFirst:NO isLast:YES];
        }
    } else if (indexPath.section == 4) {
        if (indexPath.row == 0) {
            if (self.shopData.address3) {
                [cellView setTitle:@"住所"
                            detail:[NSString stringWithFormat:@"%@ %@ %@", self.shopData.address1, self.shopData.address2, self.shopData.address3]
                           isFirst:YES isLast:NO];
            } else {
                [cellView setTitle:@"住所"
                            detail:[NSString stringWithFormat:@"%@ %@", self.shopData.address1, self.shopData.address2]
                           isFirst:YES isLast:NO];
            }
        } else if (indexPath.row == 1) {
            [cellView setTitle:@"アクセス"
                        detail:self.shopData.access
                       isFirst:NO isLast:NO];
        } else if (indexPath.row == 2) {
            [cellView setTitle:@"営業時間"
                        detail:self.shopData.businessHour
                       isFirst:NO isLast:NO];
        } else if (indexPath.row == 3) {
            [cellView setTitle:@"会社名"
                        detail:[Company art_nameForId:self.shopData.companyId]
                       isFirst:NO isLast:YES];
        }
    }
}

// ヘッダー・フッター設定
- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView
           viewForSupplementaryElementOfKind:(NSString *)kind
                                 atIndexPath:(NSIndexPath *)indexPath
{
    if ([kind isEqualToString:UICollectionElementKindSectionHeader]) {
        if (indexPath.section == 0) {
            ARTDetailHeaderView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind
                                                                                 withReuseIdentifier:NSStringFromClass([ARTDetailHeaderView class])
                                                                                        forIndexPath:indexPath];
            NSMutableArray *urlMArray = [NSMutableArray array];
            
            if (self.shopData.image1URL && self.shopData.image1URL.length > 0) {
                [urlMArray addObject:self.shopData.image1URL.copy];
            }
            if (self.shopData.image2URL && self.shopData.image2URL.length > 0) {
                [urlMArray addObject:self.shopData.image2URL.copy];
            }
            if (self.shopData.image3URL && self.shopData.image3URL.length > 0) {
                [urlMArray addObject:self.shopData.image3URL.copy];
            }
            
            [headerView setImageWithURLArray:(NSArray *)urlMArray];
            
            return headerView;
        } else {
            ARTDetailSectionHeaderView *headerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind
                                                                                        withReuseIdentifier:NSStringFromClass([ARTDetailSectionHeaderView class])
                                                                                               forIndexPath:indexPath];
            if (indexPath.section == 1) {
                [headerView setTitle:@"ここで働いている人"];
            } else if (indexPath.section == 2) {
                [headerView setTitle:@"お店の人の特徴"];
            } else if (indexPath.section == 3) {
                [headerView setTitle:@"現在の募集求人"];
            } else if (indexPath.section == 4) {
                [headerView setTitle:@"お店について"];
            } else if (indexPath.section == 5) {
                [headerView setTitle:@"お店の場所"];
            }
            
            return headerView;
        }
    }
    if ([kind isEqualToString:UICollectionElementKindSectionFooter]) {
        ARTLoadingFooterView *footerView = [collectionView dequeueReusableSupplementaryViewOfKind:kind
                                                                              withReuseIdentifier:NSStringFromClass([ARTLoadingFooterView class])
                                                                                     forIndexPath:indexPath];
        
        [footerView setViewState:[self loadingViewState] completion:nil];
        return footerView;
    }
    return nil;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionViewFlowLayout Delegate

// ヘッダーサイズ
- (CGSize)           collectionView:(UICollectionView *)collectionView
                             layout:(UICollectionViewLayout *)collectionViewLayout
    referenceSizeForHeaderInSection:(NSInteger)section
{
    if (!self.shopData) { return CGSizeZero; }
    
    if (section == 0) {
        return CGSizeMake(self.width, 240);
    } else {
        return CGSizeMake(self.width, 40);
    }
}

- (CGSize)  collectionView:(UICollectionView *)collectionView
                    layout:(UICollectionViewLayout *)collectionViewLayout
    sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 1) {
        return CGSizeMake(self.width, 80);
    } else if (indexPath.section == 2 ||
               indexPath.section == 4) {
        if (!_protoVerticalView) {
            _protoVerticalView = [ARTDetailVerticalCellView art_createViewByNib];
        }
        
        [self configureCellView:_protoVerticalView indexPath:indexPath];
        
        CGSize size = [_protoVerticalView systemLayoutSizeFittingSize:UILayoutFittingCompressedSize];
        //LOG(@"size : %@", NSStringFromCGSize(size));
        return CGSizeMake(300, size.height);
    } else if (indexPath.section == 3) {
        return CGSizeMake(300, 44);
    } else if (indexPath.section == 5) {
        if (self.isMapFullScreen) {
            return self.collectionView.bounds.size;
        }
        return CGSizeMake(300, 150);
    }
    return CGSizeZero;
}

// フッターサイズ
- (CGSize)           collectionView:(UICollectionView *)collectionView
                             layout:(UICollectionViewLayout *)collectionViewLayout
    referenceSizeForFooterInSection:(NSInteger)section
{
    if (section == 0) {
        if ([self loadingViewState] == ARTLoadingViewStateLoading ||
            [self loadingViewState] == ARTLoadingViewStateNothing) {
            return CGSizeMake(self.width, 50);
        }
    }
    return CGSizeZero;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView Delegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 3) {
        UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
        [ARTUtils selectActionForView:cell];
        
        Job *entity = [self.jobArray objectAtIndex:indexPath.row];
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory jobDetailViewControllerWithJobId:entity.identifier showEntryButton:YES]];
    } else if (indexPath.section == 5) {
        if (!self.isMapFullScreen) {
            self.isMapFullScreen = !self.isMapFullScreen;
            [self reloadFlowLayout];
        }
    }
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UIScrollView Delegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    [(ARTBaseViewController *)self.parentController scrollHeadeForscrollView : scrollView];
    //LOG(@"%@", NSStringFromCGPoint(scrollView.contentOffset));
}

@end
