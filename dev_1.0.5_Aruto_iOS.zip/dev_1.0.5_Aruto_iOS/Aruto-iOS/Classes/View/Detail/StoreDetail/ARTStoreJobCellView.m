//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTStoreJobCellView.h"

@interface ARTStoreJobCellView ()

@property (nonatomic, weak) IBOutlet UILabel   *titleLabel;
@property (nonatomic, weak) IBOutlet UIView    *lineView;
@property (nonatomic, weak) IBOutlet UIButton  *detailButton;

@property (nonatomic, assign) BOOL isFirst;
@property (nonatomic, assign) BOOL isLast;

@end

@implementation ARTStoreJobCellView

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    [self setTranslatesAutoresizingMaskIntoConstraints:NO];
    
    self.titleLabel.adjustsFontSizeToFitWidth = YES;
    
    self.detailButton.layer.cornerRadius = 5.5;
}

- (void)setTitle:(NSString *)title isFirst:(BOOL)isFirst isLast:(BOOL)isLast
{
    self.titleLabel.text = title;
    self.isFirst         = isFirst;
    self.isLast          = isLast;
    
    if (isFirst) {
    }
    if (isLast) {
        self.lineView.hidden = YES;
    } else {
        self.lineView.hidden = NO;
    }
    [self setNeedsDisplay];
}

- (void)drawRect:(CGRect)rect
{
    // todo : もうちょいましな実装できないか...
    CAShapeLayer *maskLayer = [[CAShapeLayer alloc] init];
    maskLayer.frame = self.bounds;
    UIBezierPath *maskPath;
    
    if (self.isFirst && self.isLast) {
        maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds
                                         byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight | UIRectCornerBottomLeft | UIRectCornerBottomRight
                                               cornerRadii:CGSizeMake(7, 7)];
    } else if (self.isFirst) {
        maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds
                                         byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight
                                               cornerRadii:CGSizeMake(7, 7)];
    } else if (self.isLast) {
        maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds
                                         byRoundingCorners:UIRectCornerBottomLeft | UIRectCornerBottomRight
                                               cornerRadii:CGSizeMake(7, 7)];
    } else {
        maskPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds
                                         byRoundingCorners:UIRectCornerTopLeft | UIRectCornerTopRight | UIRectCornerBottomLeft | UIRectCornerBottomRight
                                               cornerRadii:CGSizeMake(0, 0)];
    }
    
    maskLayer.path  = maskPath.CGPath;
    self.layer.mask = maskLayer;
}

- (IBAction)tapDetailButton:(UIButton *)sender
{
    art_SafeBlockCall(self.buttonTapBlock);
}

@end
