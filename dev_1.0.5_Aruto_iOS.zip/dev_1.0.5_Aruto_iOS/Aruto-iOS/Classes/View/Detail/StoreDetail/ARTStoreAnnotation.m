//
//  ARTStoreAnnotation.m
//  Aruto-iOS
//
//  Created by Yos on 2014/10/17.
//  Copyright (c) 2014年 Aruto Corp. All rights reserved.
//

#import "ARTStoreAnnotation.h"

@implementation ARTStoreAnnotation

- (instancetype)initWithCoordinate:(CLLocationCoordinate2D)coordinate
{
    _coordinate = coordinate;
    
    return self;
}

@end
