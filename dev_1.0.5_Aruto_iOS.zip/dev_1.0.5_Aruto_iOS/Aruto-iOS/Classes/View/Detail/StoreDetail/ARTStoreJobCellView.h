//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTStoreJobCellView : UIView

@property (nonatomic, copy) void (^buttonTapBlock)();

- (void)setTitle:(NSString *)title isFirst:(BOOL)isFirst isLast:(BOOL)isLast;

@end
