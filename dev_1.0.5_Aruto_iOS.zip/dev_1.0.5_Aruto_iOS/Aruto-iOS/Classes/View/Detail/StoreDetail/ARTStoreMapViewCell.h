//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

#import "ARTStoreMapCellView.h"

@interface ARTStoreMapViewCell : UICollectionViewCell

@property (nonatomic, strong) ARTStoreMapCellView *cellView;

@end
