//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSearchStaffOptionTypeView.h"

@implementation ARTSearchStaffOptionTypeView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)view;
            button.exclusiveTouch = YES;
        }
    }
}

- (IBAction)tapAgeButton:(UIButton *)sender
{
    [ARTUtils selectActionForView:sender];
    [[ARTSearchManager shared] allClear];
    [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupAge];
}

- (IBAction)tapGenderButton:(UIButton *)sender
{
    [ARTUtils selectActionForView:sender];
    [[ARTSearchManager shared] allClear];
    [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupSex];
}

- (IBAction)tapBirthPlaceButton:(UIButton *)sender
{
    [ARTUtils selectActionForView:sender];
    [[ARTSearchManager shared] allClear];
    [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupBirthPlace];
}

- (IBAction)tapHobbyButton:(UIButton *)sender
{
    [ARTUtils selectActionForView:sender];
    [[ARTSearchManager shared] allClear];
    [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupHobby];
}

- (IBAction)tapSchoolButton:(UIButton *)sender
{
    [ARTUtils selectActionForView:sender];
    [[ARTSearchManager shared] allClear];
    [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupSchool];
}

- (IBAction)tapFutureGoalButton:(UIButton *)sender
{
    [ARTUtils selectActionForView:sender];
    [[ARTSearchManager shared] allClear];
    [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupFutureGoal];
}

@end
