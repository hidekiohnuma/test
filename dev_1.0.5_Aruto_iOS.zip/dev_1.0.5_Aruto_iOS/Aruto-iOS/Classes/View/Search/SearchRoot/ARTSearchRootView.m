//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSearchRootView.h"

#import "ARTSearchStaffOptionTypeView.h"
#import "ARTSearchStoreOptionTypeView.h"

@interface ARTSearchRootView ()

@property (nonatomic, weak) IBOutlet UIView      *orView;
@property (nonatomic, weak) IBOutlet UIView      *optionView;
@property (nonatomic, weak) IBOutlet UIView      *disableView;
@property (nonatomic, weak) IBOutlet UIButton    *staffOptionButton;
@property (nonatomic, weak) IBOutlet UIButton    *storeOptionButton;
@property (nonatomic, weak) IBOutlet UISearchBar *searchBar;

@property (nonatomic, strong) ARTSearchStaffOptionTypeView *staffOptionView;
@property (nonatomic, strong) ARTSearchStoreOptionTypeView *storeOptionView;

@end

@implementation ARTSearchRootView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    [ARTUtils setBaseButtonStyle:self.staffOptionButton];

    [ARTUtils setBaseButtonStyle:self.storeOptionButton];

    self.orView.layer.cornerRadius = self.orView.width * 0.5;
    self.orView.layer.borderWidth  = 4;
    self.orView.layer.borderColor  = art_UIColorWithRGBA(255, 255, 255, 0.5).CGColor;

    self.staffOptionView = [ARTSearchStaffOptionTypeView art_createViewByNib];
    [self.optionView addSubview:self.staffOptionView];

    self.storeOptionView = [ARTSearchStoreOptionTypeView art_createViewByNib];
    [self.optionView addSubview:self.storeOptionView];

    [self tapStaffOptionButton:nil];

    self.searchBar.inputAccessoryView = [ARTUtils keyboardToolbarWithTarget:self selector:@selector(closeSearch:) width:self.width];

    ARTSearchManager.shared.isStaffSearch = YES;
}

- (IBAction)tapStaffOptionButton:(UIButton *)sender
{
    [ARTPopping scaleAnimationWithView:self.staffOptionButton];
    self.staffOptionButton.selected       = YES;
    self.storeOptionButton.selected       = NO;
    self.staffOptionView.hidden           = NO;
    self.storeOptionView.hidden           = YES;
    ARTSearchManager.shared.isStaffSearch = YES;
}

- (IBAction)tapStoreOptionButton:(UIButton *)sender
{
    [ARTPopping scaleAnimationWithView:self.storeOptionButton];
    self.staffOptionButton.selected       = NO;
    self.storeOptionButton.selected       = YES;
    self.staffOptionView.hidden           = YES;
    self.storeOptionView.hidden           = NO;
    ARTSearchManager.shared.isStaffSearch = NO;
}

- (void)closeSearch:(UISearchBar *)searchBar
{
    [UIView animateWithDuration:0.2 animations: ^{
         self.disableView.alpha = 0.0;
     }];
    [self endEditing:YES];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UISearchBar Delegate

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    [UIView animateWithDuration:0.2 animations: ^{
         self.disableView.alpha = 0.5;
     }];

    return YES;
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    [self closeSearch:searchBar];
    searchBar.text = nil;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [self closeSearch:searchBar];
    [[ARTSearchManager shared] setSearchWord:searchBar.text];

    [[ARTSearchManager shared] startSearchForFirst:NO];
}

@end
