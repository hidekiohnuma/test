//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSearchStoreOptionTypeView.h"

@implementation ARTSearchStoreOptionTypeView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    for (UIView *view in self.subviews) {
        if ([view isKindOfClass:[UIButton class]]) {
            UIButton *button = (UIButton *)view;
            button.exclusiveTouch     = YES;
            button.layer.cornerRadius = button.width * 0.5;
        }
    }
}

- (IBAction)tapPlaceButton:(UIButton *)sender
{
    [ARTUtils selectActionForView:sender];
    [[ARTSearchManager shared] allClear];
    [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupWorkPlace];
}

- (IBAction)tapTrainButton:(UIButton *)sender
{
    [ARTUtils selectActionForView:sender];
    [[ARTSearchManager shared] allClear];
    [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupTrain];
}

- (IBAction)tapHourlyWageButton:(UIButton *)sender
{
    [ARTUtils selectActionForView:sender];
    [[ARTSearchManager shared] allClear];
    [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupSalaryHour];
}

- (IBAction)tapJobCategoryButton:(UIButton *)sender
{
    [ARTUtils selectActionForView:sender];
    [[ARTSearchManager shared] allClear];
    [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupJobType];
}

- (IBAction)tapOptionButton:(UIButton *)sender
{
    [ARTUtils selectActionForView:sender];
    [[ARTSearchManager shared] allClear];
    [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupJobOtherOption];
}

@end
