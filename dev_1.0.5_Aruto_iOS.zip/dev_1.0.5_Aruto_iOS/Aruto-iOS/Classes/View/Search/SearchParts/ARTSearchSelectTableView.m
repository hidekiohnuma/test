//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSearchSelectTableView.h"

@interface ARTSearchSelectTableView ()

@property (nonatomic, weak) IBOutlet UITableView *tableView;

@property (nonatomic, assign) ARTSearchType targetSerchType;

@property (nonatomic, strong) NSArray *rowDatas;

@property (nonatomic, copy) NSIndexPath *selectIndexPath;

@end

@implementation ARTSearchSelectTableView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    self.rowDatas = [NSArray array];

    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:NSStringFromClass([self class])];

    __weak typeof(self) weakSelf = self;
    
    [ARTUtils addNotisForName:ARTNofiricationSearchItemChenged
                        block:^(NSNotification *note) {
                            [weakSelf reloadData];
                        }];
}

- (void)didMoveToSuperview
{
    LOG_METHOD;
    
    
    //[self reloadData];
    
    /*
    __weak typeof(self) weakSelf = self;
    
    [ARTUtils addNotisForName:ARTNofiricationSearchItemChenged
                        block:^(NSNotification *note) {
                            [weakSelf reloadData];
                        }];
    */
    
    //[[NSNotificationCenter defaultCenter] postNotificationName:ARTNofiricationSearchItemChenged object:nil];
    
    /*
    //メインスレッドだと待ちが出るので別スレッドで実装
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        // Background operations
        [[NSNotificationCenter defaultCenter] postNotificationName:ARTNofiricationSearchItemChenged object:nil];
     
        //dispatch_async(dispatch_get_main_queue(), ^{
            // Main Thread
        //});
     
    });
    */
}

- (void)setSearchType:(ARTSearchType)setSearchType
{
    self.targetSerchType = setSearchType;

    if ([[ARTSearchManager shared] isDispButtonViewWithType:self.targetSerchType]) {
        self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 44, 0);
    } else {
        self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 0, 0);
    }

    [self reloadData];
}

- (void)reloadData
{
    self.rowDatas = [[ARTSearchManager shared] dataWithSearchType:self.targetSerchType];

    [self.tableView reloadData];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UITableView DataSource

// セクション数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

// セクションのセル数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.rowDatas.count;
}

// セルの表示内容
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class]) forIndexPath:indexPath];

    EntityBase *entity = self.rowDatas[indexPath.row];
    cell.textLabel.text = entity.name;

    if ([[ARTSearchManager shared] isNeedPushWithSearchType:self.targetSerchType]) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    } else {
        if ([[ARTSearchManager shared] isAlreadySetDataWithSearchType:self.targetSerchType
                                                                 data:[NSString stringWithFormat:@"%@", entity.identifier]]) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
            if (![[ARTSearchManager shared] isMultipleSelectWithSearchType:self.targetSerchType]) {
                if (!self.selectIndexPath) {
                    self.selectIndexPath = indexPath;
                }
            }
        } else {
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
    }

    return cell;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UITableView Delegate

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    EntityBase *entity = self.rowDatas[indexPath.row];

    if ([[ARTSearchManager shared] isNeedPushWithSearchType:self.targetSerchType]) {
        cell.backgroundColor = [UIColor clearColor];
        return;
    }
    if ([[ARTSearchManager shared] isAlreadySetDataWithSearchType:self.targetSerchType
                                                             data:[NSString stringWithFormat:@"%@", entity.identifier]]) {
        cell.backgroundColor = art_UIColorWithRGBA(255, 200, 120, 1);
    } else {
        cell.backgroundColor = [UIColor clearColor];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    EntityBase *entity = self.rowDatas[indexPath.row];

    if ([[ARTSearchManager shared] isNeedPushWithSearchType:self.targetSerchType]) {
        [[ARTSearchManager shared] addSelectedDataWithSearchType:self.targetSerchType
                                                            data:[NSString stringWithFormat:@"%@", entity.identifier]];

        [[ARTSearchManager shared] pushControllerWithSearchType:self.targetSerchType];
    } else {
        if ([[ARTSearchManager shared] isAlreadySetDataWithSearchType:self.targetSerchType
                                                                 data:[NSString stringWithFormat:@"%@", entity.identifier]]) {
            [[ARTSearchManager shared] removeSelectedDataWithSearchType:self.targetSerchType
                                                                   data:[NSString stringWithFormat:@"%@", entity.identifier]];
        } else {
            [[ARTSearchManager shared] addSelectedDataWithSearchType:self.targetSerchType
                                                                data:[NSString stringWithFormat:@"%@", entity.identifier]];
        }
        if (![[ARTSearchManager shared] isMultipleSelectWithSearchType:self.targetSerchType]) {
            if (self.selectIndexPath) {
                [tableView reloadRowsAtIndexPaths:@[self.selectIndexPath] withRowAnimation:UITableViewRowAnimationFade];
            }
        }
        self.selectIndexPath = indexPath;
        [tableView reloadRowsAtIndexPaths:@[self.selectIndexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
