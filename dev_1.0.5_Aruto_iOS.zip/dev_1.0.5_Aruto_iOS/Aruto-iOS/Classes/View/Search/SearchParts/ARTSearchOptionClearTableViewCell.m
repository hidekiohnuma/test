//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSearchOptionClearTableViewCell.h"

@interface ARTSearchOptionClearTableViewCell ()

@property (nonatomic, weak) IBOutlet UIButton *button;

@end

@implementation ARTSearchOptionClearTableViewCell

- (void)awakeFromNib
{
    self.button.exclusiveTouch = YES;
    self.button.layer.cornerRadius = 5.5;
}

- (IBAction)tapClearButton:(UIButton *)sender
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        // Background operations
        [ARTUtils selectActionForView:sender];
        art_SafeBlockCall(self.cellSelectBlock);
        /*
         dispatch_async(dispatch_get_main_queue(), ^{
         // Main Thread
         });
         */
    });
    
    //[ARTUtils selectActionForView:sender];
    //art_SafeBlockCall(self.cellSelectBlock);
}

@end
