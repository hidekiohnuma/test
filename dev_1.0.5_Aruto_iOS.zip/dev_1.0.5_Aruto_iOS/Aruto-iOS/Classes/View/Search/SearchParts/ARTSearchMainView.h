//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTSearchMainView : ARTBaseContentsView

@property (nonatomic, copy) void (^doneBlock)();

- (void)setSearchType:(ARTSearchType)searchType;

@end
