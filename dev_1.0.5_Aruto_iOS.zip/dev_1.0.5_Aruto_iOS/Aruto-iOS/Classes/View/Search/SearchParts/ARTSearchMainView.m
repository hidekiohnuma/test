//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSearchMainView.h"

#import "ARTSearchSelectTableView.h"
#import "ARTSearchSchoolView.h"
#import "ARTSearchTrainLineView.h"
#import "ARTSearchSelectStationTableView.h"
#import "ARTSearchSelectOptionTableView.h"

@interface ARTSearchMainView ()

@property (nonatomic, weak) IBOutlet UIView   *contentsView;
@property (nonatomic, weak) IBOutlet UIView   *buttonView;
@property (nonatomic, weak) IBOutlet UIButton *searchButton;

@property (nonatomic, strong) UIView *mainView;

@property (nonatomic, assign) ARTSearchType targetSerchType;

@end

@implementation ARTSearchMainView

- (void)deallocChild
{
    //[[NSNotificationCenter defaultCenter] postNotificationName:ARTNofiricationSearchItemChenged object:nil];
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    self.searchButton.exclusiveTouch = YES;
    
    NSLog(@"ARTSearchMainView awakeFromnib");
    
}

- (void)setSearchType:(ARTSearchType)searchType
{
    self.targetSerchType = searchType;

    if (searchType == ARTSearchTypeAge ||
        searchType == ARTSearchTypeBirthPlaceArea ||
        searchType == ARTSearchTypeBirthPlacePrefecture ||
        searchType == ARTSearchTypeWorkPlaceArea ||
        searchType == ARTSearchTypeWorkPlacePrefecture ||
        searchType == ARTSearchTypeWorkPlaceCity ||
        searchType == ARTSearchTypeJobTypeCategory ||
        searchType == ARTSearchTypeJobType ||
        searchType == ARTSearchTypeJobOtherOption ||
        searchType == ARTSearchTypeSex ||
        searchType == ARTSearchTypeWorkDayType ||
        searchType == ARTSearchTypeSalaryHourType ||
        searchType == ARTSearchTypeSalaryDayType ||
        searchType == ARTSearchTypeHobbyType ||
        searchType == ARTSearchTypeHobby ||
        searchType == ARTSearchTypeFutureGoal) {
        ARTSearchSelectTableView *view = [ARTSearchSelectTableView art_createViewByNib];
        [view setSearchType:searchType];
        [self setMainContentsView:view];
    } else if (searchType == ARTSearchTypeSchool) {
        ARTSearchSchoolView *view = [ARTSearchSchoolView art_createViewByNib];
        view.parentView = self;
        [self setMainContentsView:view];
    } else if (searchType == ARTSearchTypeTrainLine) {
        [self setMainContentsView:[ARTSearchTrainLineView art_createViewByNib]];
    } else if (searchType == ARTSearchTypeTrainStation) {
        ARTSearchSelectStationTableView *view = [ARTSearchSelectStationTableView art_createViewByNib];
        [view settting];
        [self setMainContentsView:view];
    } else if (searchType == ARTSearchTypeSelectOptionType) {
        [self setMainContentsView:[ARTSearchSelectOptionTableView art_createViewByNib]];
    }

    if ([[ARTSearchManager shared] isDispButtonViewWithType:searchType]) {
        self.buttonView.hidden = NO;
    } else {
        self.buttonView.hidden = YES;
    }

    if ([[ARTSearchManager shared] isModal] && searchType != ARTSearchTypeSelectOptionType) {
        [self.searchButton setTitle:@"決定" forState:UIControlStateNormal];
    } else {
        [self.searchButton setTitle:@"検索" forState:UIControlStateNormal];
    }
}

- (void)setMainContentsView:(UIView *)view
{
    self.mainView = view;
    [self.contentsView addSubview:self.mainView];
    self.mainView.frame = self.contentsView.bounds;
    [self.mainView setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.contentsView art_pinAllEdgesOfSubview:self.mainView];
}

- (IBAction)tapSearchButton:(UIButton *)sender
{
    art_SafeBlockCall(self.doneBlock);
    
    if ([[ARTSearchManager shared] isModal] && self.targetSerchType != ARTSearchTypeSelectOptionType) {
        [[NSNotificationCenter defaultCenter] postNotificationName:ARTNofiricationSearchItemChenged object:nil];
        [[ARTViewContainer shared] popRootActiveModalNavController];
    } else {
        if (![ARTSearchManager shared].isSearched) {
            [[ARTSearchManager shared] startSearchForFirst:YES];
        } else {
            [[ARTSearchManager shared] startSearchForFirst:NO];
        }
    }
}

@end
