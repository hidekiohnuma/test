//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSearchSelectOptionTableView.h"
#import "ARTSearchOptionTableViewCell.h"
#import "ARTSearchOptionClearTableViewCell.h"

@interface ARTSearchSelectOptionTableView ()

@property (nonatomic, weak) IBOutlet UITableView *tableView;

@property (nonatomic, strong) ARTSearchOptionTableViewCell *protoCell;

@end

@implementation ARTSearchSelectOptionTableView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTSearchOptionTableViewCell class]) bundle:nil]
         forCellReuseIdentifier:NSStringFromClass([ARTSearchOptionTableViewCell class])];
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTSearchOptionClearTableViewCell class]) bundle:nil]
         forCellReuseIdentifier:NSStringFromClass([ARTSearchOptionClearTableViewCell class])];
    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 50, 0);

    
    __weak typeof(self) weakSelf = self;
    
    [ARTUtils addNotisForName:ARTNofiricationSearchItemChenged
                        block:^(NSNotification *note) {
                            [weakSelf.tableView reloadData];
                        }];
}

- (void)didMoveToSuperview
{
    LOG_METHOD;
}
// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UITableView DataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 1;
    } else if (section == 1) {
        return 5;
    } else {
        return 6;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        ARTSearchOptionClearTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([ARTSearchOptionClearTableViewCell class])
                                                                             forIndexPath:indexPath];
        
        cell.cellSelectBlock = ^{
            [[ARTSearchManager shared] clearTempData];
            [[NSNotificationCenter defaultCenter] postNotificationName:ARTNofiricationSearchItemChenged object:nil];
        };
        
        return cell;
    } else {
        ARTSearchOptionTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([ARTSearchOptionTableViewCell class])
                                                                             forIndexPath:indexPath];
        
        [self configureCell:cell indexPath:indexPath];
        return cell;
    }
}

- (void)configureCell:(ARTSearchOptionTableViewCell *)cell indexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            cell.leftLabel.text = @"勤務地";
            [self setRightItemsForCell:cell managedClass:[City class] type:ARTSearchTypeWorkPlaceCity];
        } else if (indexPath.row == 1) {
            cell.leftLabel.text = @"路線";
            NSArray *array = [[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeTrainStation];
            if (array && array.count) {
                array = [array sortedArrayUsingSelector:@selector(compare:)];
                NSMutableString *appendString = [NSMutableString string];
                for (int i = 0; i < array.count; ++i) {
                    NSString *stationName = array[i];
                    if (i == 0) {
                        [appendString appendFormat:@"%@", stationName];
                    } else {
                        [appendString appendFormat:@"\n%@", stationName];
                    }
                }
                // todo : ホントはいらない
                if (array.count > 1) {
                    [appendString appendFormat:@"\n"];
                }
                cell.rightLabel.text = appendString;
            } else {
                cell.rightLabel.text = nil;
            }
        } else if (indexPath.row == 2) {
            cell.leftLabel.text = @"時給";
            NSArray *array = [[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeSalaryHourType];
            if (array && array.count) {
                NSString *identifier = array[0];
                cell.rightLabel.text = [SalaryHourType art_nameForId:@(identifier.intValue)];
            } else {
                cell.rightLabel.text = nil;
            }
        } else if (indexPath.row == 3) {
            cell.leftLabel.text = @"職種";
            [self setRightItemsForCell:cell managedClass:[JobType class] type:ARTSearchTypeJobType];
        } else if (indexPath.row == 4) {
            cell.leftLabel.text = @"こだわり";
            [self setRightItemsForCell:cell managedClass:[JobOtherPoint class] type:ARTSearchTypeJobOtherOption];
        }
    } else {
        if (indexPath.row == 0) {
            cell.leftLabel.text = @"年代";
            [self setRightItemsForCell:cell managedClass:[Generation class] type:ARTSearchTypeAge];
        } else if (indexPath.row == 1) {
            cell.leftLabel.text = @"性別";
            [self setRightItemsForCell:cell managedClass:[Sex class] type:ARTSearchTypeSex];
        } else if (indexPath.row == 2) {
            cell.leftLabel.text = @"出身地";
            [self setRightItemsForCell:cell managedClass:[Prefecture class] type:ARTSearchTypeBirthPlacePrefecture];
        } else if (indexPath.row == 3) {
            cell.leftLabel.text = @"趣味";
            [self setRightItemsForCell:cell managedClass:[Hobby class] type:ARTSearchTypeHobby];
        } else if (indexPath.row == 4) {
            cell.leftLabel.text = @"学校";
            NSArray *array = [[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeSchool];
            if (array && array.count) {
                NSString *identifier = array[0];
                cell.rightLabel.text = [School art_nameForId:@(identifier.intValue)];
            } else {
                cell.rightLabel.text = nil;
            }
        } else if (indexPath.row == 5) {
            cell.leftLabel.text = @"夢・目標";
            [self setRightItemsForCell:cell managedClass:[FutureGoal class] type:ARTSearchTypeFutureGoal];
        }
    }
}

- (void)setRightItemsForCell:(ARTSearchOptionTableViewCell *)cell managedClass:(Class)managedClass type:(ARTSearchType)type
{
    NSArray *array = [[ARTSearchManager shared] selectDataWithSearchType:type];
    if (array && array.count) {
        array = [array sortedArrayUsingSelector:@selector(compare:)];
        NSMutableString *appendString = [NSMutableString string];
        for (int i = 0; i < array.count; ++i) {
            NSString *selectId = array[i];
            if (i == 0) {
                [appendString appendFormat:@"%@", [managedClass art_nameForId:@(selectId.intValue)]];
            } else {
                [appendString appendFormat:@"\n%@", [managedClass art_nameForId:@(selectId.intValue)]];
            }
        }
        // todo : ホントはいらない
        if (array.count > 1) {
            [appendString appendFormat:@"\n"];
        }
        cell.rightLabel.text = appendString;
    } else {
        cell.rightLabel.text = nil;
    }
    
    __weak typeof(self) weakSelf = self;
    
    [ARTUtils addNotisForName:ARTNofiricationSearchItemChenged
                        block:^(NSNotification *note) {
                            [weakSelf.tableView reloadData];
                        }];
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell.backgroundColor = [UIColor clearColor];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    [[ARTSearchManager shared] clearMultipleSelect];

    if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupWorkPlace];
        } else if (indexPath.row == 1) {
            [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupTrain];
        } else if (indexPath.row == 2) {
            [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupSalaryHour];
        } else if (indexPath.row == 3) {
            [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupJobType];
        } else if (indexPath.row == 4) {
            [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupJobOtherOption];
        }
    } else if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupAge];
        } else if (indexPath.row == 1) {
            [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupSex];
        } else if (indexPath.row == 2) {
            [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupBirthPlace];
        } else if (indexPath.row == 3) {
            [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupHobby];
        } else if (indexPath.row == 4) {
            [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupSchool];
        } else if (indexPath.row == 5) {
            [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupFutureGoal];
        }
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0) {
        return 50.0f;
    }
    if (!self.protoCell) {
        self.protoCell = [ARTSearchOptionTableViewCell art_createViewByNib];
    }
    [self configureCell:self.protoCell indexPath:indexPath];

    CGSize size = [self.protoCell.contentView systemLayoutSizeFittingSize:UILayoutFittingCompressedSize];
    return size.height;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return 0.0f;
    }
    return 25.0f;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, 25)];
    //view.backgroundColor = art_UIColorWithRGBA(20, 20, 20, 0.8);
    view.backgroundColor = art_UIColorWithRGBA(240, 240, 240, 0.8);//(20, 20, 20, 0.8);

    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, view.width - 20, 25)];
    label.backgroundColor = [UIColor clearColor];
    //label.textColor       = [UIColor whiteColor];
    label.textColor       = [UIColor darkGrayColor];
    label.textAlignment   = NSTextAlignmentCenter;
    //label.font            = [UIFont fontWithName:@"HelveticaNeue-Light" size:15];
    label.font            = [UIFont fontWithName:@"HelveticaNeue-bold" size:12];
    [view addSubview:label];

    if (section == 1) {
        label.text = @"勤務条件";
    } else {
        label.text = @"働いている人";
    }

    return view;
}

@end
