//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSearchTrainLineView.h"

@interface ARTSearchTrainLineView () <UISearchBarDelegate>

@property (nonatomic, weak) IBOutlet UISearchBar *searchBar;
@property (nonatomic, weak) IBOutlet UITableView *tableView;

@property (nonatomic, copy) NSString  *searchString;
@property (nonatomic, strong) NSArray *rowData;
@property (nonatomic, strong) NSArray *defaultData;
@property (nonatomic, assign) BOOL isSearched;

@end


@implementation ARTSearchTrainLineView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:NSStringFromClass([self class])];

    self.searchBar.inputAccessoryView = [ARTUtils keyboardToolbarWithTarget:self selector:@selector(art_closeKeyboad) width:self.width];
    
    self.isSearched = NO;
    self.defaultData = [TrainLine art_defaultTrains];
    self.rowData = self.defaultData;
}

- (void)reloadData
{
    if (self.searchString && self.searchString.length > 0) {
        self.rowData = [TrainLine art_searchTrainLineNameText:self.searchString];
    } else {
        self.rowData = [NSArray array];
    }

    [self.tableView reloadData];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UITableView DataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.rowData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class]) forIndexPath:indexPath];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

    TrainLine *entity = self.rowData[indexPath.row];
    cell.textLabel.text = entity.lineName;

    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

    return cell;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UITableView Delegate

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell.backgroundColor = [UIColor clearColor];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:NO];

    [self art_closeKeyboad];

    TrainLine *entity = self.rowData[indexPath.row];
    [[ARTSearchManager shared] addSelectedDataWithSearchType:ARTSearchTypeTrainLine data:[NSString stringWithFormat:@"%@", entity.lineId]];

    [[ARTSearchManager shared] pushControllerWithSearchType:ARTSearchTypeTrainLine];
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (self.isSearched) {
        return 0.0f;
    }
    return 25.0f;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, 25)];
    //view.backgroundColor = ART_BaseColor_Orange;
    //view.backgroundColor = art_UIColorWithRGBA(250, 250, 250, 0.8);
    view.backgroundColor = [UIColor darkGrayColor];
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, view.width - 20, 25)];
    label.backgroundColor = [UIColor clearColor];
    label.textColor       = [UIColor whiteColor];
    label.textAlignment   = NSTextAlignmentCenter;
    label.font            = [UIFont fontWithName:@"HelveticaNeue-Light" size:12];
    [view addSubview:label];
    
    label.text = @"人気の路線";
    
    return view;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UISearchBar Delegate

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if (![self.searchString isEqualToString:searchText]) {
        self.searchString = searchText;
        self.isSearched = YES;
        [self reloadData];
    }
}

- (void)searchBarTextDidEndEditing:(UISearchBar *)searchBar
{
    if (!searchBar.text.length) {
        self.rowData = self.defaultData;
        self.isSearched = NO;
        [self.tableView reloadData];
    }
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [self art_closeKeyboad];
}

@end
