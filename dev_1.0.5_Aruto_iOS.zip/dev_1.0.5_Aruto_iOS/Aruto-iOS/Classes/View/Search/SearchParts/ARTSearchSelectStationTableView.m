//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSearchSelectStationTableView.h"

@interface ARTSearchSelectStationTableView ()

@property (nonatomic, weak) IBOutlet UITableView *tableView;

@property (nonatomic, strong) NSArray *rowDatas;

@end

@implementation ARTSearchSelectStationTableView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    self.rowDatas = [NSArray array];

    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:NSStringFromClass([self class])];
}

- (void)settting
{
    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 50, 0);

    [self reloadData];
}

- (void)reloadData
{
    self.rowDatas = [[ARTSearchManager shared] dataWithSearchType:ARTSearchTypeTrainStation];

    [self.tableView reloadData];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UITableView DataSource

// セクション数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

// セクションのセル数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.rowDatas.count;
}

// セルの表示内容
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class]) forIndexPath:indexPath];

    cell.selectionStyle = UITableViewCellSelectionStyleNone;

    TrainStation *entity = self.rowDatas[indexPath.row];
    cell.textLabel.text = entity.stationName;

    if ([[ARTSearchManager shared] isNeedPushWithSearchType:ARTSearchTypeTrainStation]) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    } else {
        if ([[ARTSearchManager shared] isAlreadySetDataWithSearchType:ARTSearchTypeTrainStation data:entity.stationName]) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        } else {
            cell.accessoryType = UITableViewCellAccessoryNone;
        }
    }

    return cell;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UITableView Delegate

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    TrainStation *entity = self.rowDatas[indexPath.row];
    
    if ([[ARTSearchManager shared] isNeedPushWithSearchType:ARTSearchTypeTrainStation]) {
        cell.backgroundColor = [UIColor clearColor];
    } else {
        if ([[ARTSearchManager shared] isAlreadySetDataWithSearchType:ARTSearchTypeTrainStation data:entity.stationName]) {
            cell.backgroundColor = art_UIColorWithRGBA(255, 200, 120, 1);
        } else {
            cell.backgroundColor = [UIColor clearColor];
        }
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    TrainStation *entity = self.rowDatas[indexPath.row];

    if ([[ARTSearchManager shared] isAlreadySetDataWithSearchType:ARTSearchTypeTrainStation data:entity.stationName]) {
        [[ARTSearchManager shared] removeSelectedDataWithSearchType:ARTSearchTypeTrainStation data:entity.stationName];
    } else {
        [[ARTSearchManager shared] addSelectedDataWithSearchType:ARTSearchTypeTrainStation data:entity.stationName];
    }
    [tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
