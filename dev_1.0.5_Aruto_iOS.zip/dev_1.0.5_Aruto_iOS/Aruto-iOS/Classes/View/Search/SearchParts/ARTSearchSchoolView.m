//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSearchSchoolView.h"

typedef NS_ENUM (NSUInteger, ARTSchoolButtonType) {
    ARTSchoolButtonTypeHighSchool,
    ARTSchoolButtonTypeUnivercity,
    ARTSchoolButtonTypeJuniorCollege
};

@interface ARTSearchSchoolView () <UISearchBarDelegate>

@property (nonatomic, weak) IBOutlet UIButton    *highSchoolButton;
@property (nonatomic, weak) IBOutlet UIButton    *univercityButton;
@property (nonatomic, weak) IBOutlet UIButton    *juniorCollegeButton;
@property (nonatomic, weak) IBOutlet UIView      *searchView;
@property (nonatomic, weak) IBOutlet UISearchBar *searchBar;
@property (nonatomic, weak) IBOutlet UITableView *tableView;
@property (nonatomic, weak) IBOutlet UITextField *selectSchoolNameField;

@property (nonatomic, copy) NSString             *searchString;
@property (nonatomic, copy) NSNumber             *selectId;
@property (nonatomic, copy) NSIndexPath          *selectIndexPath;
@property (nonatomic, assign) ARTSchoolButtonType currentType;
@property (nonatomic, strong) NSArray            *schoolData;

@end

@implementation ARTSearchSchoolView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    self.tableView.contentInset = UIEdgeInsetsMake(0, 0, 50, 0);

    [self buttonSetting:self.highSchoolButton];
    [self buttonSetting:self.univercityButton];
    [self buttonSetting:self.juniorCollegeButton];

    self.selectSchoolNameField.adjustsFontSizeToFitWidth = YES;

    self.searchView.layer.shadowOpacity = 0.3;
    self.searchView.layer.shadowColor   = [UIColor blackColor].CGColor;
    self.searchView.layer.shadowOffset  = CGSizeMake(0.0f, -1.0f);
    self.searchView.layer.shadowPath    = [UIBezierPath bezierPathWithRect:self.searchView.bounds].CGPath;

    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:NSStringFromClass([self class])];

    self.searchBar.inputAccessoryView = [ARTUtils keyboardToolbarWithTarget:self selector:@selector(art_closeKeyboad) width:self.width];
    
    self.selectId = [[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeSchool][0];
    if (self.selectId) {
        School *entity = [School art_onceEntitiyForId:self.selectId localContext:nil];
        if (entity) {
            self.selectSchoolNameField.text = [entity.name copy];
        }
    }

    self.univercityButton.selected = YES;
    self.currentType               = ARTSchoolButtonTypeUnivercity;
    [self reloadDataWithType:ARTSchoolButtonTypeUnivercity];
}

- (void)buttonSetting:(UIButton *)button
{
    [ARTUtils setBaseButtonStyleGray:button];
    button.layer.borderWidth = 1;
    //button.layer.borderColor = [UIColor lightGrayColor].CGColor;
    button.layer.borderColor = art_UIColorWithRGBA(220, 220, 220, 1).CGColor;
}

- (void)reloadDataWithType:(ARTSchoolButtonType)schoolType
{
    self.currentType = schoolType;

    if (self.searchString && self.searchString.length > 0) {
        if (schoolType == ARTSchoolButtonTypeHighSchool) {
            self.schoolData = [School art_searchHighSchoolBySchoolNameText:self.searchString];
        } else if (schoolType == ARTSchoolButtonTypeUnivercity) {
            self.schoolData = [School art_searchUnivercityBySchoolNameText:self.searchString];
        } else if (schoolType == ARTSchoolButtonTypeJuniorCollege) {
            self.schoolData = [School art_searchJuniorCollegeBySchoolNameText:self.searchString];
        }
    } else {
        self.schoolData = [NSArray array];
    }

    [self.tableView reloadData];
}

- (IBAction)tapClearButton:(UIButton *)sender
{
    self.selectId                   = nil;
    self.selectSchoolNameField.text = nil;
    self.selectIndexPath            = nil;
    
    __weak typeof(self) weakSelf = self;
    self.parentView.doneBlock = ^{
        if (weakSelf.selectId) {
            [[ARTSearchManager shared] addSelectedDataWithSearchType:ARTSearchTypeSchool data:[NSString stringWithFormat:@"%@", weakSelf.selectId]];
        } else {
            [[ARTSearchManager shared] removeSelectedDataWithSearchType:ARTSearchTypeSchool data:nil];
        }
    };

    [self.tableView reloadData];
}

- (IBAction)tapHighSchoolButton:(UIButton *)sender
{
    if ([self needChangeSchoolTypeWithButton:sender]) {
        [self reloadDataWithType:ARTSchoolButtonTypeHighSchool];
    }
}

- (IBAction)tapUnivercityButton:(UIButton *)sender
{
    if ([self needChangeSchoolTypeWithButton:sender]) {
        [self reloadDataWithType:ARTSchoolButtonTypeUnivercity];
    }
}

- (IBAction)tapJuniorCollegeButton:(UIButton *)sender
{
    if ([self needChangeSchoolTypeWithButton:sender]) {
        [self reloadDataWithType:ARTSchoolButtonTypeJuniorCollege];
    }
}

- (BOOL)needChangeSchoolTypeWithButton:(UIButton *)button
{
    [ARTPopping scaleAnimationWithView:button];
    if (button.selected) { return NO; }

    self.highSchoolButton.selected    = NO;
    self.univercityButton.selected    = NO;
    self.juniorCollegeButton.selected = NO;
    button.selected                   = YES;
    self.searchBar.text               = nil;
    self.searchString                 = nil;
    [self art_closeKeyboad];

    return YES;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UITableView DataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.schoolData.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:NSStringFromClass([self class]) forIndexPath:indexPath];
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;

    School *entity = self.schoolData[indexPath.row];
    cell.textLabel.text = entity.name;

    if (entity.identifier == self.selectId) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    } else {
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    return cell;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UITableView Delegate

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    cell.backgroundColor = [UIColor clearColor];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    School *entity = self.schoolData[indexPath.row];
    self.selectId                   = entity.identifier;
    self.selectSchoolNameField.text = [entity.name copy];

    [[ARTSearchManager shared] addSelectedDataWithSearchType:ARTSearchTypeSchool data:[NSString stringWithFormat:@"%@", self.selectId]];

    if (self.selectIndexPath && self.selectIndexPath.row != indexPath.row) {
        [self.tableView reloadRowsAtIndexPaths:@[self.selectIndexPath, indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else {
        [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }

    self.selectIndexPath = indexPath;
    [tableView deselectRowAtIndexPath:indexPath animated:NO];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UISearchBar Delegate

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    if (![self.searchString isEqualToString:searchText]) {
        self.searchString    = searchText;
        self.selectIndexPath = nil;
        [self reloadDataWithType:self.currentType];
    }
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [self art_closeKeyboad];
}

@end
