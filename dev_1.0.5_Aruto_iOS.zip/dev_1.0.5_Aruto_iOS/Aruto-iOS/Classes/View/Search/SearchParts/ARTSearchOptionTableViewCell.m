//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSearchOptionTableViewCell.h"

@implementation ARTSearchOptionTableViewCell

- (void)awakeFromNib
{
    // Initialization code
}

@end
