//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTRankingSelectView.h"

#import "ARTRankingSelectViewCell.h"
#import "ARTRankUO.h"

@interface ARTRankingSelectView ()

@end

@implementation ARTRankingSelectView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTRankingSelectViewCell class]) bundle:nil]
          forCellWithReuseIdentifier:NSStringFromClass([ARTRankingSelectViewCell class])];
    
    [self refreshisNeed:NO];
    [self setting];
}

- (void)setting
{
    if ([ARTUOCacheManager shared].isAlreadyRankUOTypeTop) {
        [self reloadData];
    } else {
        [self startUO];
    }
}

- (void)startUO
{
    if (self.isLoading) { return; }
    self.isLoading = YES;
    
    __weak typeof(self) weakSelf = self;
    
    [ARTRankUO uoGetRankTopListWithTarget:self
                          completionBlock: ^(id resultObject) {
                              if (!weakSelf) { return; }
                              weakSelf.isLoading = NO;
                              
                              if ([resultObject isKindOfClass:[NSError class]]) {
                                  NSError *error = (NSError *)resultObject;
                                  [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                                               message:error.localizedFailureReason
                                                           buttonTitle:nil];
                              }
                              [weakSelf reloadData];
                          }];
}

- (void)reloadData
{
    self.index = ART_UO_Index_Interval;
    [self.collectionView reloadData];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView DataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (!self.index) { return 0; }
    return 5;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    ARTRankingSelectViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTRankingSelectViewCell class])
                                                                               forIndexPath:indexPath];
    
    if (indexPath.row == 0) {
        Staff *entity = [Staff art_topStaffForListType:ARTRankListTypePickup];
        [cell setStaffData:entity rankType:ARTRankListTypePickup];
    } else if (indexPath.row == 1) {
        Staff *entity = [Staff art_topStaffForListType:ARTRankListTypeAccess];
        [cell setStaffData:entity rankType:ARTRankListTypeAccess];
    } else if (indexPath.row == 2) {
        Staff *entity = [Staff art_topStaffForListType:ARTRankListTypeAruto];
        [cell setStaffData:entity rankType:ARTRankListTypeAruto];
    } else if (indexPath.row == 3) {
        Staff *entity = [Staff art_topStaffForListType:ARTRankListTypeMale];
        [cell setStaffData:entity rankType:ARTRankListTypeMale];
    } else if (indexPath.row == 4) {
        Staff *entity = [Staff art_topStaffForListType:ARTRankListTypeFemale];
        [cell setStaffData:entity rankType:ARTRankListTypeFemale];
    }
    
    return cell;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionViewFlowLayout Delegate

- (CGSize)  collectionView:(UICollectionView *)collectionView
                    layout:(UICollectionViewLayout *)collectionViewLayout
    sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    //return CGSizeMake(300, 70);
    return CGSizeMake(320, 200);
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView Delegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
    [ARTUtils selectActionForView:cell];
    
    if (indexPath.row == 0) {
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory rankingListViewControllerWithType:ARTRankListTypePickup]];
    } else if (indexPath.row == 1) {
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory rankingListViewControllerWithType:ARTRankListTypeAccess]];
    } else if (indexPath.row == 2) {
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory rankingListViewControllerWithType:ARTRankListTypeAruto]];
    } else if (indexPath.row == 3) {
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory rankingListViewControllerWithType:ARTRankListTypeMale]];
    } else if (indexPath.row == 4) {
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory rankingListViewControllerWithType:ARTRankListTypeFemale]];
    }
}

@end
