//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTRankingSelectViewCell.h"

@interface ARTRankingSelectViewCell ()

@property (nonatomic, weak) IBOutlet UIView      *imageLayerView;
@property (nonatomic, weak) IBOutlet UIImageView *imageView;
@property (nonatomic, weak) IBOutlet UILabel     *titleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *ranking_icon;

@end

@implementation ARTRankingSelectViewCell

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    //self.layer.cornerRadius = 5;

    self.titleLabel.adjustsFontSizeToFitWidth = YES;

    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame  = self.imageLayerView.bounds;
    gradient.colors = @[(id)[art_UIColorWithRGBA(250, 240, 210, 1.0) CGColor],
                        (id)[art_UIColorWithRGBA(255, 210, 150, 1.0) CGColor]];
    [self.imageLayerView.layer insertSublayer:gradient atIndex:0];
}

- (void)setStaffData:(Staff *)entity rankType:(ARTRankListType)rankType
{
    if (rankType == ARTRankListTypePickup) {
        self.titleLabel.text = @"Pick Up Ranking";//@"ピックアップ";
        self.titleLabel.backgroundColor = [UIColor clearColor];
    } else if (rankType == ARTRankListTypeAccess) {
        self.titleLabel.text = @"Access Ranking";//@"アクセスランキング";
        self.titleLabel.backgroundColor = [UIColor clearColor];
    } else if (rankType == ARTRankListTypeAruto) {
        self.titleLabel.text = @"Aruto Recommend Ranking";//@"Aruto推薦ランキング";
        self.titleLabel.backgroundColor = [UIColor clearColor];
    } else if (rankType == ARTRankListTypeMale) {
        self.titleLabel.text = @"Boys Ranking";//@"人気男子ランキング";
        self.titleLabel.backgroundColor = [UIColor clearColor];
    } else if (rankType == ARTRankListTypeFemale) {
        self.titleLabel.text = @"Girls Ranking";//@"人気女子ランキング";
        self.titleLabel.backgroundColor = [UIColor clearColor];
    }

    //set icon
    [self.ranking_icon setImage:[ARTIcons imageWithIcon:aruto_icon_ranking
                                                    iconColor:[UIColor darkGrayColor]
                                                     iconSize:15
                                                    imageSize:CGSizeMake(30, 30)]];
    
    if (![ARTUOCacheManager shared].isAlreadyRankUOTypeTop) { return; }

    [self.imageView art_setImageWithURL:[NSURL URLWithString:entity.thumbnailURL]
                       placeholderImage:nil
                                noImage:[ARTUtils imageWithColor:art_UIColorWithRGBA(250, 240, 210, 1.0)]
                                  alpha:1
                             parentView:nil
                          needAnimation:YES];
}

@end
