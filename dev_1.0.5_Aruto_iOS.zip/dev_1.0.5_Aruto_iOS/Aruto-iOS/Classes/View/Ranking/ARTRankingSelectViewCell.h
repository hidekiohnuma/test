//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTRankingSelectViewCell : UICollectionViewCell

- (void)setStaffData:(Staff *)entity rankType:(ARTRankListType)rankType;

@end
