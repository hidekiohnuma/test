//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTBannerView.h"

@interface ARTBannerView ()

@property (nonatomic, weak) IBOutlet UIWebView *webView;

@end

@implementation ARTBannerView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    if (!self.webView.isLoading) {
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"https://www.aruto.me/app/content"]];
        [request setHTTPMethod:@"GET"];
        request.timeoutInterval = 20;
        [_webView loadRequest:request];
    }
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - UIWebView Delegate

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    LOG(@"%@", request.URL.absoluteString);

    NSString *urlString = request.URL.absoluteString;

    if ([urlString rangeOfString:@""].location != NSNotFound) {
        // フック
        return NO;
    }
    return YES;
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [self showIndicator];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [self hideIndicator];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    LOG(@"%@", error.debugDescription);

    [self hideIndicator];
}

@end
