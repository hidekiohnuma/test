//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTSettingViewCell : UICollectionViewCell

- (void)setTitle:(NSString *)title rightText:(NSString *)rightText;

@end
