//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSettingHelpView.h"

@interface ARTSettingHelpView ()

@property (nonatomic, weak) IBOutlet UIWebView *webView;

@end

@implementation ARTSettingHelpView

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    if (!self.webView.isLoading) {
        NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:@"http://www.aruto.me/app/help"]];
        [request setHTTPMethod:@"GET"];
        request.timeoutInterval = 20;
        [_webView loadRequest:request];
    }
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - UIWebView Delegate

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    [self showIndicator];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [self hideIndicator];
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    LOG(@"%@", error.debugDescription);

    [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                 message:error.localizedFailureReason
                             buttonTitle:nil];

    [self hideIndicator];
}

@end
