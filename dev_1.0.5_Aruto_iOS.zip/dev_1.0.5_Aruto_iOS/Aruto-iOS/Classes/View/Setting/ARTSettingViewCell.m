//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSettingViewCell.h"

@interface ARTSettingViewCell ()

@property (nonatomic, weak) IBOutlet UILabel     *titleLabel;
@property (nonatomic, weak) IBOutlet UILabel     *rightLabel;
@property (nonatomic, weak) IBOutlet UIImageView *rightImageView;

@end

@implementation ARTSettingViewCell


- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    //self.layer.cornerRadius = 5;
    //self.layer.backgroundColor = [UIColor lightGrayColor].CGColor;
    
    self.titleLabel.adjustsFontSizeToFitWidth = YES;
    self.rightLabel.adjustsFontSizeToFitWidth = YES;
    self.rightLabel.hidden                    = YES;

    self.rightImageView.image = [IonIcons imageWithIcon:ion_ios_arrow_forward
                                              iconColor:art_UIColorWithRGBA(243,152,0,1)// 120, 190, 255, 1
                                               iconSize:20
                                              imageSize:CGSizeMake(30, 30)];
}

- (void)setTitle:(NSString *)title rightText:(NSString *)rightText
{
    self.titleLabel.text = title;
    if (rightText) {
        self.rightLabel.hidden     = NO;
        self.rightLabel.text       = rightText;
        self.rightImageView.hidden = YES;
    } else {
        self.rightLabel.hidden     = YES;
        self.rightLabel.text       = rightText;
        self.rightImageView.hidden = NO;
    }
}

@end
