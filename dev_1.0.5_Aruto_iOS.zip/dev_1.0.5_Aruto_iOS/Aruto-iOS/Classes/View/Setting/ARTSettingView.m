//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSettingView.h"
#import "ARTSettingViewCell.h"

#import <ARNCustomURLHelper.h>

@interface ARTSettingView ()

@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;

@property (nonatomic, strong) ARNCustomURLHelper *urlHelper;

@end

@implementation ARTSettingView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    self.collectionView.contentInset = UIEdgeInsetsMake(0, 0, 50, 0);
    
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTSettingViewCell class]) bundle:nil]
          forCellWithReuseIdentifier:NSStringFromClass([ARTSettingViewCell class])];
    
    __weak typeof(self) weakSelf = self;
    
    [ARTUtils addNotisForName:ARTNofiricationLogined
                        block:^(NSNotification *note) {
                            [weakSelf.collectionView reloadData];
                        }];
    
    [ARTUtils addNotisForName:ARTNofiricationLogouted
                        block:^(NSNotification *note) {
                            [weakSelf.collectionView reloadData];
                        }];
    
    self.urlHelper = ARNCustomURLHelper.new;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView DataSource

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 4;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    if (section == 0) {
        return 1;
    }
    if (section <= 3) {
        return 2;
    }
    
    return 0;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    ARTSettingViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTSettingViewCell class])
                                                                         forIndexPath:indexPath];
    
    if (indexPath.section == 0) {
        [cell setTitle:ARTControllerNameSettingNotis rightText:nil];
    } else if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            [cell setTitle:ARTControllerNameSettingHelp rightText:nil];
        } else if (indexPath.row == 1) {
            [cell setTitle:ARTControllerNameSettingQuestion rightText:@" "];
        }
    } else if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            [cell setTitle:ARTControllerNameSettingUserAgreement rightText:nil];
        } else if (indexPath.row == 1) {
            [cell setTitle:ARTControllerNameSettingPrivacyPolicy rightText:nil];
        }
    } else if (indexPath.section == 3) {
        if (indexPath.row == 0) {
            if ([[ARTUserManager shared] isLogined]) {
                [cell setTitle:@"ログアウト" rightText:@" "];
            } else {
                [cell setTitle:@"ログイン" rightText:@" "];
            }
        } else if (indexPath.row == 1) {
            [cell setTitle:@"バージョン情報"
                 rightText:[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"]];
        }
    }
    
    return cell;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView Delegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (!(indexPath.section == 3 && indexPath.row == 1)) {
        UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
        [ARTUtils selectActionForView:cell];
    }
    
    __weak typeof(self) weakSelf = self;
    
    if (indexPath.section == 0) {
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory settingNotisViewController]];
    } else if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory settingHelpViewController]];
        } else if (indexPath.row == 1) {
            [self.urlHelper setModaiEmailNavigationBarTintColor:[UIColor whiteColor]];
            [self.urlHelper setModalMailNavigationBarTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor], NSFontAttributeName : [UIFont fontWithName:@"HiraKakuProN-W6" size:19]}];
            [self.urlHelper modalEMailForSubject:@"お問い合わせ"
                                            body:nil
                                         address:@"support@aruto.me"
                                           owner:self.parentController
                                    failureBlock:^{
                                        [ARNAlert showNoActionAlertWithTitle:nil
                                                                     message:@"メール送信が行えませんでした"
                                                                 buttonTitle:nil];
                                    }];
        }
    } else if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory settingUserAgreementViewController]];
        } else if (indexPath.row == 1) {
            [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory settingPrivacyPolicyViewController]];
        }
    } else if (indexPath.section == 3) {
        if (indexPath.row == 0) {
            if ([[ARTUserManager shared] isLogined]) {
                [ARNAlert showAlertWithTitle:nil
                                    message:@"ログアウトします。\nよろしいですか?"
                          cancelButtonTitle:@"キャンセル"
                                cancelBlock:^(id action) {}
                              okButtonTitle:@"OK"
                                    okBlock:^(id action) {
                                        [weakSelf showIndicator];
                                        // todo : 雑な実装....
                                        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                                            [NSThread sleepForTimeInterval:2];
                                            dispatch_async(dispatch_get_main_queue(), ^{
                                                [[ARTUserManager shared] logout];
                                                [weakSelf hideIndicator];
                                            });
                                        });
                                    }];
            } else {
                [[ARTViewContainer shared] showUserAuthModalView];
            }
        }
    }
}

@end
