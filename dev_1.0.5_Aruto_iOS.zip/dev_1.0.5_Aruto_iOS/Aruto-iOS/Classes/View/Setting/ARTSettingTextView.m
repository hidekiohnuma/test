//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSettingTextView.h"

@interface ARTSettingTextView ()

@property (nonatomic, weak) IBOutlet UITextView *textView;

@end

@implementation ARTSettingTextView

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame  = self.bounds;
    gradient.colors = @[(id)[art_UIColorWithRGBA(255, 255, 255, 1) CGColor],
                        (id)[art_UIColorWithRGBA(250, 230, 230, 1) CGColor]];
    [self.layer insertSublayer:gradient atIndex:0];
}

- (void)setText:(NSString *)text
{
    self.textView.text = text;
}

@end
