//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTNotisSettingView.h"

#import "ARTUserUO.h"

@interface ARTNotisSettingView ()

@property (nonatomic, weak) IBOutlet UIView   *cellView1;
@property (nonatomic, weak) IBOutlet UIView   *cellView2;
@property (nonatomic, weak) IBOutlet UISwitch *shopNotisSwitch;
@property (nonatomic, weak) IBOutlet UISwitch *arutoNotisSwitch;

@end

@implementation ARTNotisSettingView

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    __weak typeof(self) weakSelf = self;
    
    [ARTUtils addNotisForName:ARTNofiricationLogined
                        block:^(NSNotification *note) {
                            [weakSelf setting];
                        }];

    self.cellView1.layer.cornerRadius = 5;
    self.cellView2.layer.cornerRadius = 5;

    [self.shopNotisSwitch addTarget:self action:@selector(shopNotisChanged) forControlEvents:UIControlEventValueChanged];
    [self.arutoNotisSwitch addTarget:self action:@selector(arutoNotisChanged) forControlEvents:UIControlEventValueChanged];

    [self cleateNeedLoginView];
    if (![[ARTUserManager shared] isLogined]) {
        [self dispNeedLoginView];
        return;
    }
    [self setting];
}

- (void)setting
{
    User *entity = [User art_userForLocalContext:nil];
    if (entity) {
        self.shopNotisSwitch.on  = entity.notificationForYouflg.boolValue;
        self.arutoNotisSwitch.on = entity.notificationForAllflg.boolValue;
    }
}

- (void)shopNotisChanged
{
    [self showIndicator];

    __weak typeof(self) weakSelf = self;

    [ARTUserUO uoChangeNotificationWithTarget:self
                                  isShopNotis:YES
                                   canReceive:self.shopNotisSwitch.isOn
                              completionBlock: ^(id resultObject) {
         [weakSelf hideIndicator];
         if (!weakSelf) { return; }

         if ([resultObject isKindOfClass:[NSError class]]) {
             NSError *error = (NSError *)resultObject;
             [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                          message:error.localizedFailureReason
                                      buttonTitle:nil];
             weakSelf.shopNotisSwitch.on = !weakSelf.shopNotisSwitch.on;
         }
     }];
}

- (void)arutoNotisChanged
{
    [self showIndicator];

    __weak typeof(self) weakSelf = self;

    [ARTUserUO uoChangeNotificationWithTarget:self
                                  isShopNotis:NO
                                   canReceive:self.arutoNotisSwitch.isOn
                              completionBlock: ^(id resultObject) {
         [weakSelf hideIndicator];
         if (!weakSelf) { return; }

         if ([resultObject isKindOfClass:[NSError class]]) {
             NSError *error = (NSError *)resultObject;
             [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                          message:error.localizedFailureReason
                                      buttonTitle:nil];
             weakSelf.arutoNotisSwitch.on = !weakSelf.arutoNotisSwitch.on;
         }
     }];
}

@end
