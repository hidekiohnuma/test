//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTEntryListView.h"

#import "ARTEntryListViewCell.h"

#import "ARTEntryUO.h"

@interface ARTEntryListView ()

@end

@implementation ARTEntryListView

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTEntryListViewCell class]) bundle:nil]
          forCellWithReuseIdentifier:NSStringFromClass([ARTEntryListViewCell class])];
    
    self.nothingRowText = @"応募した求人はありません";
    
    [self startUO];
}

- (void)startUO
{
    if (self.isLoading) { return; }
    self.isLoading = YES;

    [ARTEntryUO uoGetEntryListWithTarget:self
                                  userId:[ARTUserManager shared].userId
                                   index:@(self.index)
                         completionBlock:[self uoCompletionBlock]];
}

- (NSArray *)rowDataArray
{
    return [Entry art_allNonDeleteEntiteis];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView DataSource

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    ARTEntryListViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTEntryListViewCell class])
                                                                           forIndexPath:indexPath];

    Entry *entity = self.rowData[indexPath.row];
    [cell setEntryData:entity];

    Job *jobData = [Job art_jobWithJobId:entity.jobId localContext:nil];
    cell.tapStoreButtonBlock = ^(id obj) {
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory jobDetailViewControllerWithJobId:jobData.identifier showEntryButton:NO]];
    };

    cell.tapMessageButtonBlock = ^(id obj) {
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory messageViewControllerWithEntryId:entity.identifier]];
    };

    return cell;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionViewFlowLayout Delegate

- (CGSize)  collectionView:(UICollectionView *)collectionView
                    layout:(UICollectionViewLayout *)collectionViewLayout
    sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    // need override
    return CGSizeMake(300, 180);
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView Delegate

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    Entry *entity  = self.rowData[indexPath.row];
    Job   *jobData = [Job art_jobWithJobId:entity.jobId localContext:nil];
    [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory storeDetailViewControllerWithShopId:jobData.shopId]];
}

@end
