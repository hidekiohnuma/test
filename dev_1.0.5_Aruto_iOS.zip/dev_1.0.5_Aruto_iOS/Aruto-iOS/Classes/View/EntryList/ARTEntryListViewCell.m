//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTEntryListViewCell.h"

@interface ARTEntryListViewCell ()

@property (nonatomic, weak) IBOutlet UIImageView *miniImageView;
@property (nonatomic, weak) IBOutlet UIImageView *imageView;
@property (nonatomic, weak) IBOutlet UILabel     *storeNameLabel;
@property (nonatomic, weak) IBOutlet UILabel     *jobLabel;
@property (nonatomic, weak) IBOutlet UILabel     *interviewDateLabel;
@property (nonatomic, weak) IBOutlet UIButton    *stateButton1;
@property (nonatomic, weak) IBOutlet UIButton    *stateButton2;
@property (nonatomic, weak) IBOutlet UIButton    *stateButton3;
@property (nonatomic, weak) IBOutlet UIButton    *stateButton4;
@property (nonatomic, weak) IBOutlet UIButton    *storeButton;
@property (nonatomic, weak) IBOutlet UIButton    *messageButton;

@end

@implementation ARTEntryListViewCell

- (void)dealloc
{
    LOG_METHOD;
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    self.layer.cornerRadius = 5;

    self.interviewDateLabel.adjustsFontSizeToFitWidth = YES;

    self.stateButton1.layer.cornerRadius = 5;
    self.stateButton2.layer.cornerRadius = 5;
    self.stateButton3.layer.cornerRadius = 5;
    self.stateButton4.layer.cornerRadius = 5;

    self.stateButton1.layer.borderColor = ART_BaseColor_Orange.CGColor;
    self.stateButton2.layer.borderColor = ART_BaseColor_Orange.CGColor;
    self.stateButton3.layer.borderColor = ART_BaseColor_Orange.CGColor;
    self.stateButton4.layer.borderColor = ART_BaseColor_Orange.CGColor;

    self.stateButton1.layer.borderWidth = 1;
    self.stateButton2.layer.borderWidth = 1;
    self.stateButton3.layer.borderWidth = 1;
    self.stateButton4.layer.borderWidth = 1;

    [self.stateButton1 setBackgroundImage:[ARTUtils imageWithColor:ART_BaseColor_Orange] forState:UIControlStateSelected];
    [self.stateButton2 setBackgroundImage:[ARTUtils imageWithColor:ART_BaseColor_Orange] forState:UIControlStateSelected];
    [self.stateButton3 setBackgroundImage:[ARTUtils imageWithColor:ART_BaseColor_Orange] forState:UIControlStateSelected];
    [self.stateButton4 setBackgroundImage:[ARTUtils imageWithColor:ART_BaseColor_Orange] forState:UIControlStateSelected];

    self.storeButton.exclusiveTouch   = YES;
    self.messageButton.exclusiveTouch = YES;

    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame  = self.bounds;
    gradient.colors = @[(id)[art_UIColorWithRGBA(250, 240, 210, 1.0) CGColor],
                        (id)[art_UIColorWithRGBA(250, 230, 180, 1.0) CGColor]];
    [self.layer insertSublayer:gradient atIndex:0];
}

- (void)setEntryData:(Entry *)entryData
{
    Job  *jobData  = [Job art_jobWithJobId:entryData.jobId localContext:nil];
    Shop *shopData = [Shop art_shopWithShopId:jobData.shopId localContext:nil];

    self.storeNameLabel.text = [Shop art_shopNameForShop:shopData];
    self.jobLabel.text       = [NSString stringWithFormat:@"応募求人 : %@", [JobType art_nameForId:jobData.jobTypeId]];

    self.stateButton1.selected = NO;
    self.stateButton2.selected = NO;
    self.stateButton3.selected = NO;
    self.stateButton4.selected = NO;

    if (entryData.entryStatusId.intValue == 1) {
        self.stateButton1.selected   = YES;
        self.interviewDateLabel.text = @"連絡待ち";
    } else if (entryData.entryStatusId.intValue == 2) {
        self.stateButton2.selected = YES;
        if (entryData.interviewDate) {
            self.interviewDateLabel.text = [NSString stringWithFormat:@"面接予定日 : %@", [entryData.interviewDate art_stringWithFormatJapaneseMD_HM]];
        } else {
            self.interviewDateLabel.text = @"面接日調整中";
        }
    } else if (entryData.entryStatusId.intValue == 3) {
        self.stateButton3.selected   = YES;
        self.interviewDateLabel.text = @"結果待ち";
    } else if (entryData.entryStatusId.intValue == 4) {
        self.stateButton4.selected   = YES;
        self.interviewDateLabel.text = @"採用";
    } else if (entryData.entryStatusId.intValue == 5) {
        self.stateButton4.selected   = YES;
        self.interviewDateLabel.text = @"不採用";
    }

    [self.imageView art_setImageWithURL:[NSURL URLWithString:shopData.thumbnailURL]
                       placeholderImage:nil
                                noImage:nil
                                  alpha:0.2
                             parentView:nil
                          needAnimation:NO];

    [self.miniImageView art_setImageWithURL:[NSURL URLWithString:shopData.thumbnailURL]
                           placeholderImage:nil
                                    noImage:nil
                                      alpha:1.0
                                 parentView:nil
                              needAnimation:YES];
}

- (IBAction)tapStoreButton:(UIButton *)sender
{
    [ARTUtils selectActionForView:sender];
    art_SafeBlockCall(self.tapStoreButtonBlock, nil);
}

- (IBAction)tapMessageButton:(UIButton *)sender
{
    [ARTUtils selectActionForView:sender];
    art_SafeBlockCall(self.tapMessageButtonBlock, nil);
}

@end
