//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTEntryListViewCell : UICollectionViewCell

@property (nonatomic, copy) void (^tapStoreButtonBlock)(id resultObj);
@property (nonatomic, copy) void (^tapMessageButtonBlock)(id resultObj);

- (void)setEntryData:(Entry *)entryData;

@end
