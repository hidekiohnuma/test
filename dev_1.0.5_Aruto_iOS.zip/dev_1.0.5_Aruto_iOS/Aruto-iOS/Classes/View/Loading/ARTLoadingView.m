//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTLoadingView.h"

static dispatch_source_t timer_;

@interface ARTLoadingView ()

@property (nonatomic, weak) IBOutlet UILabel *label;

@end

@implementation ARTLoadingView

- (void)dealloc
{
    LOG_METHOD;
    dispatch_suspend(timer_);
}

- (void)awakeFromNib
{
    [super awakeFromNib];

    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame  = self.bounds;
    gradient.colors = @[(id)[art_UIColorWithRGBA(250, 200, 130, 1) CGColor],
                        (id)[art_UIColorWithRGBA(240, 130, 50, 1) CGColor]];
    [self.layer insertSublayer:gradient atIndex:0];

    if (!timer_) {
        timer_ = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0, art_main_queue);
    }

    dispatch_source_set_timer(timer_, dispatch_time(DISPATCH_TIME_NOW, 0), 2.0 * NSEC_PER_SEC, 0);

    __weak typeof(self) weakSelf = self;

    dispatch_source_set_event_handler(timer_, ^{
            [weakSelf poppingLabel];
        });

    dispatch_resume(timer_);
}

- (void)poppingLabel
{
    [ARTPopping scaleAnimationWithView:self.label];
}

@end
