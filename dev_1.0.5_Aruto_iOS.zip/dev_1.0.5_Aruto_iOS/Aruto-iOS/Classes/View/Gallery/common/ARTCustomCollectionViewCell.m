//  Copyright (c) 2015年 Aruto Corp. All rights reserved.

#import "ARTCustomCollectionViewCell.h"

@implementation ARTCustomCollectionViewCell
@synthesize galleryImage = _galleryImage;

- (id)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
    }
    return self;
}

- (void)awakeFromNib
{
    self.selectedBackgroundView = [[UIView alloc] initWithFrame:self.bounds];
//    self.selectedBackgroundView.backgroundColor = [UIColor colorWithRed: (255.0)/255.0 green: (165.0)/255.0 blue: (0.0)/255.0 alpha: 1.0];
}

@end
