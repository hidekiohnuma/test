//  Copyright (c) 2015年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTCustomCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UIImageView *galleryImage;
@property (weak, nonatomic) IBOutlet UIButton *galleryButton;

@end
