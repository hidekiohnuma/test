//  Copyright (c) 2015年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTGalleryView : ARTBaseContentsView<UICollectionViewDataSource, UICollectionViewDelegate>

@property NSArray* items;
@property (strong, nonatomic) IBOutlet UIScrollView *scroll;

@end