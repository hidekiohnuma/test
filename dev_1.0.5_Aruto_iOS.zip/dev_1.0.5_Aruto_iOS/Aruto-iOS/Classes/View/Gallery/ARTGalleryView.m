//  Copyright (c) 2015年 Aruto Corp. All rights reserved.

#import "ARTGalleryView.h"
#import "ARTCustomCollectionViewCell.h"

@interface ARTGalleryView (){
    NSString* selectedItem;
}

@property (nonatomic, weak) IBOutlet UICollectionView *collectionView;

@end

@implementation ARTGalleryView
 
- (void)deallocChild
{
    LOG_METHOD;
}


- (void)awakeFromNib
{
    [super awakeFromNib];
    // scroll
    self.scroll.contentSize = CGSizeMake(320, 600);
    
    [self.collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([ARTCustomCollectionViewCell class]) bundle:nil]
          forCellWithReuseIdentifier:NSStringFromClass([ARTCustomCollectionViewCell class])];

    self.collectionView.delegate = self;
    self.collectionView.dataSource = self;
    
    // 空の配列を用意
    self.items = [NSArray array];
    
    // キャッシュ全削除
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
    
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    // add Id
    NSString *prefectureAreaSelectedId = [ud stringForKey:@"prefectureAreaSelectedId"];
    
    [self getJSON];
}
- (void)getJSON
{
    // getId
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSString *prefectureAreaSelectedId = [ud stringForKey:@"prefectureAreaSelectedId"];
    
    // url取得
//    NSURL *url = [NSURL URLWithString:[ARTBaseURL stringByAppendingString:@"gallery/list.json"]];
    NSURL *url = [NSURL URLWithString:[ARTBaseURL stringByAppendingFormat:@"gallery/list/?prefecture_area_id=%@",prefectureAreaSelectedId]];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *error) {
        
        NSDictionary *jsonDictionary = [NSJSONSerialization JSONObjectWithData:data options:0 error:nil];
        
        // アプリデータの配列をプロパティに保持
        self.items = [jsonDictionary objectForKey:@"Galleries"];

        [self.collectionView reloadData];
    }];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [self.items count];
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    ARTCustomCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:NSStringFromClass([ARTCustomCollectionViewCell class])
                                                                        forIndexPath:indexPath];

    NSDictionary *item = [self.items objectAtIndex:indexPath.row];
    
    dispatch_queue_t q_global = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_queue_t q_main = dispatch_get_main_queue();

    dispatch_async(q_global, ^{
        NSString *imageURL = [item objectForKey:@"image_url"];
        UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfURL: [NSURL URLWithString: imageURL]]];
        
        dispatch_async(q_main, ^{
            cell.galleryImage.image = image;
            [cell setNeedsLayout];
        });
    });
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    // 店舗詳細へ遷移
    NSDictionary *item = [self.items objectAtIndex:indexPath.row];
    selectedItem = [item objectForKey:@"shop_id"];
   
    NSString *shopId=[[NSString alloc] initWithFormat:@"%@",selectedItem];

    [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory storeDetailViewControllerWithShopId:shopId]];
}

@end
