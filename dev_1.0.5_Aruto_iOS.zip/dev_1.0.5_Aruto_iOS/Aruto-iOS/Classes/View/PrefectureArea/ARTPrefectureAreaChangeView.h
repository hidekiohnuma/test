//  Copyright (c) 2015年 Aruto Corp. All rights reserved.
#import <UIKit/UIKit.h>

@interface ARTPrefectureAreaChangeView : ARTBaseListView<UITableViewDelegate, UITableViewDataSource>

//テーブルの一覧にセットする配列
@property NSArray* items;

@property (weak, nonatomic) IBOutlet UITableView *tableView;


@end