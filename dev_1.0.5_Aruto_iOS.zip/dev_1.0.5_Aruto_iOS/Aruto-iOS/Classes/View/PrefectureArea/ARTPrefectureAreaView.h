//  Copyright (c) 2015年 Aruto Corp. All rights reserved.
#import <UIKit/UIKit.h>

//@interface ARTPrefectureAreaView : UIViewController
@interface ARTPrefectureAreaView : ARTBaseListView<UITableViewDelegate, UITableViewDataSource>

//テーブルの一覧にセットする配列
@property NSArray* items;
@property (strong, nonatomic) IBOutlet UIImageView *prefectureAreaImage;

@property (weak, nonatomic) IBOutlet UITableView *tableView;


@end