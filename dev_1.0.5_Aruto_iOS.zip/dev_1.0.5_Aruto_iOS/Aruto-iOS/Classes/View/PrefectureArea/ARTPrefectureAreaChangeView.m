//  Copyright (c) 2015年 Aruto Corp. All rights reserved.

#import "ARTPrefectureAreaChangeView.h"

@interface ARTPrefectureAreaChangeView (){
    
    IBOutlet UIButton *topButton;
    NSString* selectedItemId;
    NSString* selectedItem;
}

@end

@implementation ARTPrefectureAreaChangeView

- (void)awakeFromNib
{
    [super awakeFromNib];
    
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    
    // 空の配列を用意
    self.items = [NSArray array];
    
    [self getData];
    
    // headerView非表示
//    [self.parentController hiddenHeaderView];
    
    // 複数選択
    self.tableView.allowsMultipleSelection =  NO;
}

- (void)getData
{
    NSString *jsonFilePath = [[NSBundle mainBundle] pathForResource:@"PrefectureArea" ofType:@"json"];
    
    NSFileManager *fileManager = [NSFileManager defaultManager];
    if (![fileManager fileExistsAtPath:jsonFilePath]) // ファイルの存在チェック
    {
        return;
    }
    
    NSData *jsonData = [NSData dataWithContentsOfFile:jsonFilePath];
    
    NSError *error;
    NSDictionary *jsonObject = [NSJSONSerialization JSONObjectWithData:jsonData
                                                               options:NSJSONReadingAllowFragments
                                                                 error:&error];
    
    self.items = jsonObject;
    // TableView をリロード
    [self.tableView reloadData];
    
}

// セルの数を設定
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [self.items count];
}

// セルの高さ設定
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 36.0f;
}
// テーブルセルの内容を設定
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    NSDictionary *item = [self.items objectAtIndex:indexPath.row];
    // blog記事取得 title
    cell.textLabel.numberOfLines = 0;
    cell.textLabel.font = [UIFont fontWithName:@"AppleGothic" size:13];
    cell.textLabel.text = [item valueForKeyPath:@"name"];
    
    // add checkbox
    cell.accessoryType = UITableViewCellAccessoryNone;
    
    for (NSIndexPath *selectedindex in [tableView indexPathsForSelectedRows]) {
        // 選択済みかどうかチェック
        NSComparisonResult result = [selectedindex compare:indexPath];
        if (result == NSOrderedSame) {
            // 選択済みであればチェックマークを付ける
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
            break;
        }
    }
    
    return cell;
}

// tap action
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 選択されたセルを取得
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    // セルのアクセサリにチェックマークを指定
    cell.accessoryType = UITableViewCellAccessoryCheckmark;
    
    NSDictionary *item = [self.items objectAtIndex:indexPath.row];
    // 選択されたエリアを格納
    // id
    selectedItemId = [item valueForKeyPath:@"id"];
    // name
    selectedItem = [item valueForKeyPath:@"name"];
    
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud setObject:selectedItemId forKey:@"prefectureAreaSelectedId"];
    [ud setObject:selectedItem forKey:@"prefectureAreaId"];
    [ud synchronize];
    
    NSString *prefectureAreaSelectedId = [ud stringForKey:@"prefectureAreaSelectedId"];
    NSString *prefectureAreaId = [ud stringForKey:@"prefectureAreaId"];
    
    //ボタンイベント定義
    [topButton addTarget:self action:@selector(buttonTouchUpInsideEvent:)
        forControlEvents:UIControlEventTouchUpInside];
}

// セルの選択がはずれた時に呼び出される
- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 選択がはずれたセルを取得
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    // セルのアクセサリを解除する（チェックマークを外す）
    cell.accessoryType = UITableViewCellAccessoryNone;
    
    NSDictionary *item = [self.items objectAtIndex:indexPath.row];
    // 選択されたエリアを格納
    // id
    selectedItemId = [item valueForKeyPath:@"id"];
    // name
    selectedItem = [item valueForKeyPath:@"name"];
    // データ取得
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    [ud removeObjectForKey:@"prefectureAreaSelectedId"];
    [ud removeObjectForKey:@"prefectureAreaId"];
}

// button action
- (void)buttonTouchUpInsideEvent:(id)sender
{
    UIButton *topButton = (UIButton *)sender;
    
    // 特集画面へ遷移
    [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory specialEditionView]];
}

@end