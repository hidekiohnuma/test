//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

@interface ARTPopping : NSObject

+ (void)scaleAnimationWithView:(UIView *)view;
+ (void)scale2AnimationWithView:(UIView *)view;

+ (void)zoomAnimationWithView:(UIView *)view;

+ (void)poppinAnimationWithView:(UIView *)view;

+ (void)shakeAnimationWithView:(UIView *)view;

@end
