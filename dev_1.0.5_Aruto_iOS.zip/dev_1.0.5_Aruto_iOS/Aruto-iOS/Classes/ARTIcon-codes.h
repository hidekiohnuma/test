//
//  ARTIcon-codes.h
//  Aruto-iOS
//
//  Created by kunihara yoshihiro on 2015/01/30.
//  Copyright (c) 2015年 Aruto Corp. All rights reserved.
//

#ifndef Aruto_iOS_ARTIcon_codes_h
#define Aruto_iOS_ARTIcon_codes_h

//#define icon_social_facebook_outline @"\uf230"
#define aruto_icon_specialedition   @"a"
#define aruto_icon_gallery          @"d"
#define aruto_icon_settings         @"e"
#define aruto_icon_search           @"f"
#define aruto_icon_ranking          @"g"
#define aruto_icon_cliped           @"h"
#define aruto_icon_chat             @"l"
#define aruto_icon_mypage           @"m"
#define aruto_icon_position         @"n"
#define aruto_icon_house            @"o"
#define aruto_icon_info             @"p"


#endif
