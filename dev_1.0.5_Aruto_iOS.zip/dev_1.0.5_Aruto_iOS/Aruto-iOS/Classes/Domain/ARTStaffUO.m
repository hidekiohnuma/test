//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTStaffUO.h"

@implementation ARTStaffUO

+ (void)uoGetStaffWithTarget:(id)target
                     staffId:(NSNumber *)staffId
             completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!staffId) {
        art_SafeBlockCall(completionBlock, [ARTUtils errorFOrType:ARTErrorTypeUOParametorError]);
        return;
    }

    __weak typeof(self) weakSelf = self;

    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"staff.json"]
                httpFormat:@"GET"
                parameters:@{ @"staff_id": staffId }
              successBlock: ^(id resultObject) {
         NSDictionary *resultDict = (NSDictionary *)resultObject;

         dispatch_group_t disGroup = dispatch_group_create();
         NSError *error = nil;

         [weakSelf setSingleEntityForResultDict:resultDict[@"StaffData"]
                             managedObjectClass:[Staff class]
                                        keyName:@"Staff"
                                          group:disGroup groupError:&error];

         [weakSelf setSingleEntityForResultDict:resultDict[@"ShopData"]
                             managedObjectClass:[Shop class]
                                        keyName:@"Shop"
                                          group:disGroup groupError:&error];

         dispatch_group_wait(disGroup, DISPATCH_TIME_FOREVER);
         dispatch_async(dispatch_get_main_queue(), ^{
                 art_SafeBlockCall(completionBlock, error);
             });
     } failureBlock: ^(NSError *error) {
         art_SafeBlockCall(completionBlock, error);
     }];
}

+ (void)uoPostAccessCountWithTarget:(id)target
                            staffId:(NSNumber *)staffId
{
    if (!staffId) { return; }

    // カウントアップだけなので投げっぱなし
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"staff/update_access_count"]
                httpFormat:@"POST"
                parameters:@{ @"staff_id": staffId }
              successBlock:nil
              failureBlock:nil];
}

@end
