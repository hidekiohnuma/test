//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

@interface ARTUOCacheManager : NSObject

+ (instancetype)shared;

@property (nonatomic, assign) BOOL isAlreadyRankUOTypeTop;

- (void)clear;

- (void)setAlreadyRankUOForlistType:(ARTRankListType)listType;
- (BOOL)isAlreadyRankUOForlistType:(ARTRankListType)listType;

- (void)addStaffId:(NSNumber *)staffId;
- (void)addShopId:(NSNumber *)shopfId;
- (void)addJobId:(NSNumber *)jobId;

- (BOOL)containsStaffId:(NSNumber *)staffId;
- (BOOL)containsShopId:(NSNumber *)shopfId;
- (BOOL)containsJobId:(NSNumber *)jobId;

@end
