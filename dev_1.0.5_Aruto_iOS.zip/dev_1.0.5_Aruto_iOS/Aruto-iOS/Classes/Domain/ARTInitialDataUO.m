//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTInitialDataUO.h"

@implementation ARTInitialDataUO

+ (void)uoGetInitialDataWithTarget:(id)target
                        updateDate:(NSString *)updateDate
                      successBlock:(ARTSuccessBlock)successBlock
                      failureBlock:(ARTFailureBlock)failureBlock
{
    LOG_METHOD;
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"initialdata.json"]
                httpFormat:@"GET"
                parameters:@{ @"lastupdate": updateDate }
              successBlock: ^(id resultObject) {
         //LOG(@"successBlock :%@", resultObject);
         NSDictionary *resultDict = (NSDictionary *)resultObject;

         dispatch_group_t disGroup = dispatch_group_create();
         NSError *error = nil;

         // タイムスタンプ
         NSString *lastUpdate = resultDict[@"lastUpdate"];

         // 地域
         [self setEntityForResultArray:resultDict[@"Areas"]
                    managedObjectClass:[Area class]
                               keyName:@"Area"
                                 group:disGroup groupError:&error];

         // 県
         [self setEntityForResultArray:resultDict[@"Prefectures"]
                    managedObjectClass:[Prefecture class]
                               keyName:@"Prefecture"
                                 group:disGroup groupError:&error];

         // 仕事カテゴリ
         [self setEntityForResultArray:resultDict[@"JobTypeCategories"]
                    managedObjectClass:[JobTypeCategory class]
                               keyName:@"JobTypeCategory"
                                 group:disGroup groupError:&error];

         // 仕事タイプ
         [self setEntityForResultArray:resultDict[@"JobTypes"]
                    managedObjectClass:[JobType class]
                               keyName:@"JobType"
                                 group:disGroup groupError:&error];

         // 仕事わがまま条件
         [self setEntityForResultArray:resultDict[@"JobOtherPoints"]
                    managedObjectClass:[JobOtherPoint class]
                               keyName:@"JobOtherPoint"
                                 group:disGroup groupError:&error];

         // 性別
         [self setEntityForResultArray:resultDict[@"Sexes"]
                    managedObjectClass:[Sex class]
                               keyName:@"Sex"
                                 group:disGroup groupError:&error];

         // 時給
         [self setEntityForResultArray:resultDict[@"SalaryHourTypes"]
                    managedObjectClass:[SalaryHourType class]
                               keyName:@"SalaryHourType"
                                 group:disGroup groupError:&error];

         // 日給
         [self setEntityForResultArray:resultDict[@"SalaryDayTypes"]
                    managedObjectClass:[SalaryDayType class]
                               keyName:@"SalaryDayType"
                                 group:disGroup groupError:&error];

         // 稼働日
         [self setEntityForResultArray:resultDict[@"WorkDayTypes"]
                    managedObjectClass:[WorkDayType class]
                               keyName:@"WorkDayType"
                                 group:disGroup groupError:&error];

         // 学校タイプ
         [self setEntityForResultArray:resultDict[@"SchoolTypes"]
                    managedObjectClass:[SchoolType class]
                               keyName:@"SchoolType"
                                 group:disGroup groupError:&error];

         // 学校
         [self setEntityForResultArray:resultDict[@"Schools"]
                    managedObjectClass:[School class]
                               keyName:@"School"
                                 group:disGroup groupError:&error];

         // 趣味タイプ
         [self setEntityForResultArray:resultDict[@"HobbyTypes"]
                    managedObjectClass:[HobbyType class]
                               keyName:@"HobbyType"
                                 group:disGroup groupError:&error];

         // 趣味
         [self setEntityForResultArray:resultDict[@"Hobbys"]
                    managedObjectClass:[Hobby class]
                               keyName:@"Hobby"
                                 group:disGroup groupError:&error];

         // 世代
         [self setEntityForResultArray:resultDict[@"Generations"]
                    managedObjectClass:[Generation class]
                               keyName:@"Generation"
                                 group:disGroup groupError:&error];

         // 夢・目標
         [self setEntityForResultArray:resultDict[@"FutureGoals"]
                    managedObjectClass:[FutureGoal class]
                               keyName:@"FutureGoal"
                                 group:disGroup groupError:&error];

         // 質問
         [self setEntityForResultArray:resultDict[@"StaffOtherQuestions"]
                    managedObjectClass:[StaffOtherQuestion class]
                               keyName:@"StaffOtherQuestion"
                                 group:disGroup groupError:&error];

         // アクセス方法
         [self setEntityForResultArray:resultDict[@"AccessMethods"]
                    managedObjectClass:[AccessMethod class]
                               keyName:@"AccessMethod"
                                 group:disGroup groupError:&error];

         // 路線
         [self setEntityForResultArray:resultDict[@"TrainLines"]
                    managedObjectClass:[TrainLine class]
                               keyName:@"TrainLine"
                                 group:disGroup groupError:&error];

         // 駅名
         [self setEntityForResultArray:resultDict[@"TrainStations"]
                    managedObjectClass:[TrainStation class]
                               keyName:@"TrainStation"
                                 group:disGroup groupError:&error];

         dispatch_group_wait(disGroup, DISPATCH_TIME_FOREVER);
         if (error) {
             LOG(@"end dispatch failure");
             art_SafeBlockCall(failureBlock, error);
         } else {
             LOG(@"end dispatch success");
             art_SafeBlockCall(successBlock, lastUpdate);
         }
     } failureBlock: ^(NSError *error) {
         art_SafeBlockCall(failureBlock, error);
     }];
}

@end
