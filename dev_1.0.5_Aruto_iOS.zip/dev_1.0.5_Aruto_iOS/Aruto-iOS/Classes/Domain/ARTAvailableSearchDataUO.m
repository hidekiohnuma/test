//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTAvailableSearchDataUO.h"

@implementation ARTAvailableSearchDataUO

+ (void)uoGetAvailableDataWithTarget:(id)target
                     completionBlock:(ARTCompletionBlock)completionBlock
{
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"searchIndex.json"]
                httpFormat:@"GET"
                parameters:nil
              successBlock: ^(id resultObject) {
                  NSDictionary *resultDict = (NSDictionary *)resultObject;
                  NSDictionary *staffDict = resultDict[@"staff"];
                  NSDictionary *shopDict = resultDict[@"shop"];
                  
                  // スタッフ検索
                  [Area art_updateEntityDisplayFlagForEntityIds:staffDict[@"areas"]];
                  [Prefecture art_updateEntityDisplayFlagForEntityIds:staffDict[@"prefectures"]];
                  [Generation art_updateEntityDisplayFlagForEntityIds:staffDict[@"generations"]];
                  [HobbyType art_updateEntityDisplayFlagForEntityIds:staffDict[@"hobby_types"]];
                  [Hobby art_updateEntityDisplayFlagForEntityIds:staffDict[@"hobbies"]];
                  [FutureGoal art_updateEntityDisplayFlagForEntityIds:staffDict[@"future_goals"]];
                  
                  // 店舗検索
                  [Prefecture art_updateEntityDisplayFlagForEntityIds:shopDict[@"prefectures"]];
                  [City art_updateEntityDisplayFlagForEntityIds:shopDict[@"cities"]];
                  [JobTypeCategory art_updateEntityDisplayFlagForEntityIds:shopDict[@"job_type_categorie"]];
                  [JobType art_updateEntityDisplayFlagForEntityIds:shopDict[@"job_types"]];
                  [JobOtherPoint art_updateEntityDisplayFlagForEntityIds:shopDict[@"job_other_points"]];
                  [SalaryHourType art_updateEntityDisplayFlagForEntityIds:shopDict[@"salary_hour_types"]];
                  [School art_updateEntityDisplayFlagForEntityIds:shopDict[@"schools"]];
                  [TrainLine art_updateEntityDisplayFlagForEntityIds:shopDict[@"train_lines"]];
                  [TrainStation art_updateEntityDisplayFlagForEntityIds:shopDict[@"train_stations"]];
                  
                  // 今使ってない
                  //[SalaryDayType art_updateEntityDisplayFlagForEntityIds:resultDict[@"SalaryDayType"]];
                  //[WorkDayType art_updateEntityDisplayFlagForEntityIds:resultDict[@"WorkDayType"]];
                  
                  dispatch_async(dispatch_get_main_queue(), ^{
                      art_SafeBlockCall(completionBlock, nil);
                  });
              } failureBlock: ^(NSError *error) {
                  art_SafeBlockCall(completionBlock, error);
              }];
}

@end