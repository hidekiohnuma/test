//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

@interface ARTTaskManager : NSObject

+ (instancetype)shared;

- (void)startInitialDataTask;

- (void)addFavoriteWithStaffId:(NSNumber *)staffId completionBlock:(ARTCompletionBlock)completionBlock;
- (void)removeFavoriteWithStaffId:(NSNumber *)staffId completionBlock:(ARTCompletionBlock)completionBlock;

- (void)addFavoriteWithShopId:(NSNumber *)shopId completionBlock:(ARTCompletionBlock)completionBlock;
- (void)removeFavoriteWithShopId:(NSNumber *)shopId completionBlock:(ARTCompletionBlock)completionBlock;

- (void)updateDeviceTokenTaskWithDeviceTokenString:(NSString *)deviceTokenString retryCount:(int)retryCount;

@end
