//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

@interface ARTSearchDataUpdateTask : NSObject

- (void)startWithSuccessBlock:(ARTSuccessBlock)successBlock
                 failureBlock:(ARTFailureBlock)failureBlock;

@end
