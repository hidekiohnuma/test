//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSearchUO.h"

@implementation ARTSearchUO

+ (void)uoGetSearchListWithTarget:(id)target
                            index:(NSInteger)index
                  completionBlock:(ARTCompletionBlock)completionBlock
{
    NSMutableDictionary *params = [NSMutableDictionary dictionary];

    if (ARTSearchManager.shared.isStaffSearch) {
        [params setObject:@"1" forKey:@"search_type"];
    } else {
        [params setObject:@"2" forKey:@"search_type"];
    }

    [params setObject:@(index) forKey:@"index"];

    if ([[ARTSearchManager shared] searchWord]) {
        [params setObject:[ARTSearchManager shared].searchWord forKey:@"search_word"];
    }

    if ([[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeAge]) {
        [params setObject:[[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeAge] forKey:@"generation"];
    }

    if ([[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeSex]) {
        [params setObject:[[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeSex] forKey:@"sex"];
    }

    if ([[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeBirthPlacePrefecture]) {
        [params setObject:[[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeBirthPlacePrefecture] forKey:@"birth_place"];
    }

    if ([[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeWorkPlaceCity]) {
        [params setObject:[[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeWorkPlaceCity] forKey:@"work_place"];
    }

    if ([[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeJobType]) {
        [params setObject:[[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeJobType] forKey:@"job_type"];
    }

    if ([[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeJobOtherOption]) {
        [params setObject:[[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeJobOtherOption] forKey:@"job_other_point"];
    }

    if ([[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeHobby]) {
        [params setObject:[[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeHobby] forKey:@"hobby"];
    }

    if ([[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeFutureGoal]) {
        [params setObject:[[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeFutureGoal] forKey:@"future_goal"];
    }

    if ([[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeSalaryHourType]) {
        [params setObject:[[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeSalaryHourType] forKey:@"salary_hour"];
    }

    if ([[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeSchool]) {
        [params setObject:[[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeSchool] forKey:@"school"];
    }

    if ([[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeTrainStation]) {
        [params setObject:[[ARTSearchManager shared] selectDataWithSearchType:ARTSearchTypeTrainStation] forKey:@"train_station"];
    }

    __weak typeof(self) weakSelf = self;

    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"search.json"]
                httpFormat:@"POST"
                parameters:params
              successBlock: ^(id resultObject) {
         LOG(@"successBlock :%@", resultObject);
         NSDictionary *resultDict = (NSDictionary *)resultObject;

         dispatch_group_t disGroup = dispatch_group_create();
         NSError *error = nil;
         BOOL canNextCall = YES;

         if (resultObject[@"TotalCount"]) {
             ARTSearchManager.shared.totalCount = [(NSNumber *)resultObject[@"TotalCount"] integerValue];
         }

         NSArray *array;
         if (ARTSearchManager.shared.isStaffSearch) {
             array = resultDict[@"Staffs"];
         } else {
             array = resultDict[@"Shops"];
         }

         if (array && array.count > 0) {
             if (ARTSearchManager.shared.isStaffSearch) {
                 [weakSelf setStaffEntityForResultArray:resultDict[@"Staffs"]
                                                  group:disGroup groupError:&error];

                 [weakSelf setShopEntityForResultArray:resultDict[@"Shops"]
                                                 group:disGroup groupError:&error];
             } else {
                 [weakSelf setShopEntityForResultArray:resultDict[@"Shops"]
                                                 group:disGroup groupError:&error];

                 [weakSelf setEntityForResultArray:resultDict[@"Jobs"]
                                managedObjectClass:[Job class]
                                           keyName:@"Job"
                                             group:disGroup groupError:&error];
             }
         } else {
             canNextCall = NO;
         }

         dispatch_group_wait(disGroup, DISPATCH_TIME_FOREVER);
         dispatch_async(dispatch_get_main_queue(), ^{
                 if (error) {
                     art_SafeBlockCall(completionBlock, error);
                 } else {
                     art_SafeBlockCall(completionBlock, @(canNextCall));
                 }
             });
     } failureBlock: ^(NSError *error) {
         art_SafeBlockCall(completionBlock, error);
     }];
}

+ (void)setStaffEntityForResultArray:(NSArray *)array
                               group:(dispatch_group_t)group
                          groupError:(NSError **)groupError
{
    if (!array || !array.count) { return; }

    dispatch_group_enter(group);
    [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
         for (NSDictionary * entityDict in array) {
             [Staff art_updateOrInsertEntityForResultDict:entityDict[@"Staff"]
                                             localContext:localContext
                                         searchIdentifier:[ARTSearchManager shared].searchIndentifier];
         }
     } completion: ^{
         LOG(@"leave : Search Staff");
         dispatch_group_leave(group);
     }];
}

+ (void)setShopEntityForResultArray:(NSArray *)array
                              group:(dispatch_group_t)group
                         groupError:(NSError **)groupError
{
    if (!array || !array.count) { return; }

    dispatch_group_enter(group);
    [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
         for (NSDictionary * entityDict in array) {
             [Shop art_updateOrInsertEntityForResultDict:entityDict[@"Shop"]
                                            localContext:localContext
                                        searchIdentifier:[ARTSearchManager shared].searchIndentifier];

             if (entityDict[@"Company"]) {
                 [Company art_updateOrInsertEntityForResultDict:entityDict[@"Company"] localContext:localContext];
             }
             NSArray *jobArray = entityDict[@"Job"];
             for (NSDictionary * jobDict in jobArray) {
                 [Job art_updateOrInsertEntityForResultDict:jobDict localContext:localContext];
             }
         }
     } completion: ^{
         LOG(@"leave : Search Staff");
         dispatch_group_leave(group);
     }];
}

@end
