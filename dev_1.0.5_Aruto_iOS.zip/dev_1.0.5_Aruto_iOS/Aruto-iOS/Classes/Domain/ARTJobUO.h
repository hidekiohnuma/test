//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import "ARTBaseUO.h"

@interface ARTJobUO : ARTBaseUO

+ (void)uoGetJobWithTarget:(id)target
                     jobId:(NSNumber *)jobId
           completionBlock:(ARTCompletionBlock)completionBlock;

@end
