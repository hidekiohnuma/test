//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

typedef void (^ARTImageCacheSuccessBlock)(UIImage *image, NSString *imageURLString);
typedef void (^ARTImageCacheFailureBlock)(NSError *error);

@interface ARTImageUO : NSObject

+ (void)requestThumbnailWithTarget:(id)target
                          imageURL:(NSURL *)imageURL
                      successBlock:(ARTImageCacheSuccessBlock)successBlock
                      failureBlock:(ARTImageCacheFailureBlock)failureBlock;

@end
