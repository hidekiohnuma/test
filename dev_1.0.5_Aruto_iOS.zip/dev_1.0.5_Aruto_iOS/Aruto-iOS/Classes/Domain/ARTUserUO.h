//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import "ARTBaseUO.h"

@interface ARTUserUO : ARTBaseUO

// Create User
+ (void)uoCreateUserWithTarget:(id)target
                    facebookId:(NSString *)facebookId
               completionBlock:(ARTCompletionBlock)completionBlock;

+ (void)uoCreateUserWithTarget:(id)target
                     twitterId:(NSString *)twitterId
               completionBlock:(ARTCompletionBlock)completionBlock;

+ (void)uoCreateUserWithTarget:(id)target
                         email:(NSString *)email
                      password:(NSString *)password
               completionBlock:(ARTCompletionBlock)completionBlock;

// Login User
+ (void)uoLoginUserWithTarget:(id)target
                   facebookId:(NSString *)facebookId
              completionBlock:(ARTCompletionBlock)completionBlock;

+ (void)uoLoginUserWithTarget:(id)target
                    twitterId:(NSString *)twitterId
              completionBlock:(ARTCompletionBlock)completionBlock;

+ (void)uoLoginUserWithTarget:(id)target
                        email:(NSString *)email
                     password:(NSString *)password
              completionBlock:(ARTCompletionBlock)completionBlock;

// Update Device Token
+ (void)uoSendDeviceTokenWithTarget:(id)target
                       successBlock:(ARTSuccessBlock)successBlock
                       failureBlock:(ARTFailureBlock)failureBlock;

// Setting Notification
+ (void)uoChangeNotificationWithTarget:(id)target
                           isShopNotis:(BOOL)isShopNotis
                            canReceive:(BOOL)canReceive
                       completionBlock:(ARTCompletionBlock)completionBlock;

// Forget Password
+ (void)uoReissueEmailWithTarget:(id)target
                           email:(NSString *)email
                 completionBlock:(ARTCompletionBlock)completionBlock;

@end
