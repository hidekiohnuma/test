//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTMessageUO.h"

@implementation ARTMessageUO

+ (void)uoGetMessageListWithTarget:(id)target
                            userId:(NSNumber *)userId
                           entryId:(NSNumber *)entryId
                   completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!userId || !entryId) {
        art_SafeBlockCall(completionBlock, [ARTUtils errorFOrType:ARTErrorTypeUOParametorError]);
        return;
    }

    __weak typeof(self) weakSelf = self;

    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"message/list.json"]
                httpFormat:@"GET"
                parameters:@{ @"user_id": userId,
                              @"entry_id": entryId }
              successBlock: ^(id resultObject) {
         NSDictionary *resultDict = (NSDictionary *)resultObject;

         dispatch_group_t disGroup = dispatch_group_create();
         NSError *error = nil;

         [weakSelf setEntityForResultArray:resultDict[@"Messages"]
                        managedObjectClass:[EntryMessage class]
                                   keyName:@"ArutoMessage"
                                     group:disGroup groupError:&error];

         dispatch_group_wait(disGroup, DISPATCH_TIME_FOREVER);

         if (error) {
             LOG(@"end dispatch failure");
             dispatch_async(dispatch_get_main_queue(), ^{
                     art_SafeBlockCall(completionBlock, error);
                 });
         } else {
             LOG(@"end dispatch success");
             dispatch_async(dispatch_get_main_queue(), ^{
                     art_SafeBlockCall(completionBlock, nil);
                 });
         }
     } failureBlock: ^(NSError *error) {
         art_SafeBlockCall(completionBlock, error);
     }];
}

+ (void)uoPostMessageWithTarget:(id)target
                         userId:(NSNumber *)userId
                        entryId:(NSNumber *)entryId
                           text:(NSString *)text
                completionBlock:(ARTCompletionBlock)completionBlock
{
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"message/post.json"]
                httpFormat:@"POST"
                parameters:@{ @"user_id": userId,
                              @"entry_id": entryId,
                              @"text": text }
              successBlock: ^(id resultObject) {
         if (resultObject[@"error"]) {
             LOG(@"%@", resultObject[@"error"]);
             dispatch_async(dispatch_get_main_queue(), ^{
                     art_SafeBlockCall(completionBlock, [ARTUtils uoErrorForDict:resultObject[@"error"]]);
                 });
             return;
         }
         dispatch_async(dispatch_get_main_queue(), ^{
                 art_SafeBlockCall(completionBlock, nil);
             });
     } failureBlock: ^(NSError *error) {
         art_SafeBlockCall(completionBlock, error);
     }];
}

@end
