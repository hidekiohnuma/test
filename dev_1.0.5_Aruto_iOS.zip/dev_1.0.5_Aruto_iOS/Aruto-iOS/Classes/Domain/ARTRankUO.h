//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import "ARTBaseUO.h"

@interface ARTRankUO : ARTBaseUO

+ (void)uoGetRankListWithTarget:(id)target
                       listType:(ARTRankListType)listType
                completionBlock:(ARTCompletionBlock)completionBlock;

+ (void)uoGetRankTopListWithTarget:(id)target
                   completionBlock:(ARTCompletionBlock)completionBlock;

@end
