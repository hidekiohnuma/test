//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTImageCashe.h"

static NSString *const ARTImageCacheFolderName    = @"ARTImageCache";
static NSString *const ARTImageCacheNameThumbnail = @"ARTThumbnail";
static NSString *const ARTImageCacheNameStore     = @"ARTStore";

static NSCache *thumbnailCache_  = nil;
static NSCache *storeImageCache_ = nil;

@implementation ARTImageCashe

+ (NSCache *)thumbnailCache
{
    if (!thumbnailCache_) {
        thumbnailCache_            = [[NSCache alloc] init];
        thumbnailCache_.countLimit = 30;
    }
    return thumbnailCache_;
}

+ (NSCache *)storeImageCache
{
    if (!storeImageCache_) {
        storeImageCache_            = [[NSCache alloc] init];
        storeImageCache_.countLimit = 15;
    }
    return storeImageCache_;
}

+ (NSString *)cacheImageFolderPath
{
    return [ARTUtils checkAndCreateDirectoryAtPath:[ARNCachesDirectory stringByAppendingPathComponent:ARTImageCacheFolderName]];
}

+ (void)clearImageCache
{
    [self.thumbnailCache removeAllObjects];
    [self.storeImageCache removeAllObjects];

    [[NSFileManager defaultManager] removeItemAtPath:[self cacheImageFolderPath] error:nil];
}

+ (void)addThumbnailImageWithImage:(UIImage *)image imageURL:(NSURL *)imageURL
{
    if (!image || !imageURL) { return; }

    if (![self.thumbnailCache objectForKey:imageURL.absoluteString]) {
        [self.thumbnailCache setObject:image forKey:imageURL.absoluteString];
    }
    [self addLocalCacheWithImage:image imageURL:imageURL key:ARTImageCacheNameThumbnail];
}

+ (void)addStoreImageWithImage:(UIImage *)image imageURL:(NSURL *)imageURL
{
    if (!image || !imageURL) { return; }

    if (![self.storeImageCache objectForKey:imageURL.absoluteString]) {
        [self.storeImageCache setObject:image forKey:imageURL.absoluteString];
    }
    [self addLocalCacheWithImage:image imageURL:imageURL key:ARTImageCacheNameStore];
}

+ (void)addLocalCacheWithImage:(UIImage *)image imageURL:(NSURL *)imageURL key:(NSString *)key
{
    @synchronized(self)
    {
        NSString *filePath = [self filePathWIthImageURL:imageURL key:key];
        if (![[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
            NSData *data = [[NSData alloc] initWithData:UIImagePNGRepresentation(image)];
            [data writeToURL:[NSURL fileURLWithPath:filePath] atomically:NO];
        }
    }
}

+ (UIImage *)hasCacheThumbnailImageWIthURL:(NSURL *)imageURL
{
    if (!imageURL) { return nil; }

    UIImage *cachedImage = [self.thumbnailCache objectForKey:imageURL.absoluteString];
    if (cachedImage) {
        return cachedImage;
    } else {
        return [self hasLocalCacheImageWIthURL:imageURL key:ARTImageCacheNameThumbnail];
    }
}

+ (UIImage *)hasCacheStoreImageWIthURL:(NSURL *)imageURL
{
    if (!imageURL) { return nil; }

    UIImage *cachedImage = [self.storeImageCache objectForKey:imageURL.absoluteString];
    if (cachedImage) {
        return cachedImage;
    } else {
        return [self hasLocalCacheImageWIthURL:imageURL key:ARTImageCacheNameStore];
    }
}

+ (UIImage *)hasLocalCacheImageWIthURL:(NSURL *)imageURL key:(NSString *)key
{
    NSString *filePath = [self filePathWIthImageURL:imageURL key:key];
    if ([[NSFileManager defaultManager] fileExistsAtPath:filePath]) {
        NSData  *data  = [NSData dataWithContentsOfURL:[NSURL fileURLWithPath:filePath]];
        UIImage *image = [UIImage imageWithData:data];
        return image;
    }
    return nil;
}

+ (NSString *)filePathWIthImageURL:(NSURL *)imageURL key:(NSString *)key
{
    if (!imageURL || !key) { return nil; }

    NSString *fileDirectoryString = [[self cacheImageFolderPath] stringByAppendingPathComponent:key];
    if (![[NSFileManager defaultManager] fileExistsAtPath:fileDirectoryString]) {
        NSError *error   = nil;
        BOOL     created = [[NSFileManager defaultManager] createDirectoryAtPath:fileDirectoryString
                                                     withIntermediateDirectories:NO
                                                                      attributes:nil
                                                                           error:&error];
        if (!created) {
            LOG(@"filePathWIthImageURL error : %@", error.description);
            abort();
        }
    }
    return [fileDirectoryString stringByAppendingPathComponent:[self escapeString:imageURL.absoluteString]];
}

+ (NSString *)escapeString:(NSString *)aString
{
    return (__bridge_transfer NSString *)CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
        (CFStringRef)aString,
        NULL,
        (CFStringRef)@"-._~:/?#[]@!$&'()*+,;=",
        kCFStringEncodingUTF8);
}

@end
