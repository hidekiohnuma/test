//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTShopUO.h"

@implementation ARTShopUO

+ (void)uoGetShopWithTarget:(id)target
                     shopId:(NSNumber *)shopId
            completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!shopId) {
        art_SafeBlockCall(completionBlock, [ARTUtils errorFOrType:ARTErrorTypeUOParametorError]);
        return;
    }

    __weak typeof(self) weakSelf = self;

    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"shop.json"]
                httpFormat:@"GET"
                parameters:@{ @"shop_id": shopId }
              successBlock: ^(id resultObject) {
         NSDictionary *resultDict = (NSDictionary *)resultObject;

         dispatch_group_t disGroup = dispatch_group_create();
         NSError *error = nil;

         [weakSelf setSingleEntityForResultDict:resultDict[@"ShopData"]
                             managedObjectClass:[Shop class]
                                        keyName:@"Shop"
                                          group:disGroup groupError:&error];

         [weakSelf setSingleEntityForResultDict:resultDict[@"CompanyData"]
                             managedObjectClass:[Company class]
                                        keyName:@"Company"
                                          group:disGroup groupError:&error];

         [weakSelf setEntityForResultArray:resultDict[@"Staffs"]
                        managedObjectClass:[Staff class]
                                   keyName:@"Staff"
                                     group:disGroup groupError:&error];

         [weakSelf setEntityForResultArray:resultDict[@"Jobs"]
                        managedObjectClass:[Job class]
                                   keyName:@"Job"
                                     group:disGroup groupError:&error];

         dispatch_group_wait(disGroup, DISPATCH_TIME_FOREVER);
         dispatch_async(dispatch_get_main_queue(), ^{
                 art_SafeBlockCall(completionBlock, error);
             });
     } failureBlock: ^(NSError *error) {
         art_SafeBlockCall(completionBlock, error);
     }];
}

@end
