//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import "ARTBaseUO.h"

@interface ARTMessageUO : ARTBaseUO

+ (void)uoGetMessageListWithTarget:(id)target
                            userId:(NSNumber *)userId
                           entryId:(NSNumber *)entryId
                   completionBlock:(ARTCompletionBlock)completionBlock;

+ (void)uoPostMessageWithTarget:(id)target
                         userId:(NSNumber *)userId
                        entryId:(NSNumber *)entryId
                           text:(NSString *)text
                completionBlock:(ARTCompletionBlock)completionBlock;

@end
