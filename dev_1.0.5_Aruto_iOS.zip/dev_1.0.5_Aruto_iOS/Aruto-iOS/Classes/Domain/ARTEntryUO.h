//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import "ARTBaseUO.h"

@interface ARTEntryUO : ARTBaseUO

+ (void)uoGetEntryListWithTarget:(id)target
                          userId:(NSNumber *)userId
                           index:(NSNumber *)index
                 completionBlock:(ARTCompletionBlock)completionBlock;

+ (void)uoPostEntryListWithTarget:(id)target
                           userId:(NSNumber *)userId
                            jobId:(NSNumber *)jobId
                      contactType:(NSString *)contactType
                        firstName:(NSString *)firstName
                         lastName:(NSString *)lastName
                    firstNameKana:(NSString *)firstNameKana
                     lastNameKana:(NSString *)lastNameKana
                      phoneNumber:(NSString *)phoneNumber
                         birthday:(NSString *)birthday
                  completionBlock:(ARTCompletionBlock)completionBlock;

@end
