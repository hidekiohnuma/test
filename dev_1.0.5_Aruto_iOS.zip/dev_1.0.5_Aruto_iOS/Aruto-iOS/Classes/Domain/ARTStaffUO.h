//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import "ARTBaseUO.h"

@interface ARTStaffUO : ARTBaseUO

+ (void)uoGetStaffWithTarget:(id)target
                     staffId:(NSNumber *)staffId
             completionBlock:(ARTCompletionBlock)completionBlock;

+ (void)uoPostAccessCountWithTarget:(id)target
                            staffId:(NSNumber *)staffId;

@end
