//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import "ARTBaseUO.h"

@interface ARTFavoriteUO : ARTBaseUO

+ (void)uoGetFavoriteListWithTarget:(id)target
                            isStaff:(BOOL)isStaff
                             userId:(NSNumber *)userId
                              index:(NSNumber *)index
                    completionBlock:(ARTCompletionBlock)completionBlock;

+ (void)uoAddStaffFavoriteWithTarget:(id)target
                              userId:(NSNumber *)userId
                             staffId:(NSNumber *)staffId
                     completionBlock:(ARTCompletionBlock)completionBlock;

+ (void)uoDeleteStaffFavoriteWithTarget:(id)target
                                 userId:(NSNumber *)userId
                                staffId:(NSNumber *)staffId
                        completionBlock:(ARTCompletionBlock)completionBlock;

+ (void)uoAddShopFavoriteWithTarget:(id)target
                             userId:(NSNumber *)userId
                             shopId:(NSNumber *)shopId
                    completionBlock:(ARTCompletionBlock)completionBlock;

+ (void)uoDeleteShopFavoriteWithTarget:(id)target
                                userId:(NSNumber *)userId
                                shopId:(NSNumber *)shopId
                       completionBlock:(ARTCompletionBlock)completionBlock;

@end
