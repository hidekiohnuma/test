//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import "ARTBaseUO.h"

@interface ARTSearchUO : ARTBaseUO

+ (void)uoGetSearchListWithTarget:(id)target
                            index:(NSInteger)index
                  completionBlock:(ARTCompletionBlock)completionBlock;

@end
