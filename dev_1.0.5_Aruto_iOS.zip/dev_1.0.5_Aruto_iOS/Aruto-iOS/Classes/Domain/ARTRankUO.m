//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTRankUO.h"

@implementation ARTRankUO

+ (void)uoGetRankListWithTarget:(id)target
                       listType:(ARTRankListType)listType
                completionBlock:(ARTCompletionBlock)completionBlock
{
    __weak typeof(self) weakSelf = self;
    
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"rank/list.json"]
                httpFormat:@"GET"
                parameters:@{ @"list_type": @(listType) }
              successBlock: ^(id resultObject) {
                  NSDictionary *resultDict = (NSDictionary *)resultObject;
                  
                  dispatch_group_t disGroup = dispatch_group_create();
                  NSError *error = nil;
                  
                  [weakSelf setRankStaffEntityForResultArray:resultDict[@"Staffs"]
                                                    listType:listType
                                                       group:disGroup
                                                  groupError:&error];
                  
                  [weakSelf setEntityForResultArray:resultDict[@"Shops"]
                                 managedObjectClass:[Shop class]
                                            keyName:@"Shop"
                                              group:disGroup
                                         groupError:&error];
                  
                  if (!error) {
                      [[ARTUOCacheManager shared] setAlreadyRankUOForlistType:listType];
                  }
                  dispatch_group_wait(disGroup, DISPATCH_TIME_FOREVER);
                  dispatch_async(dispatch_get_main_queue(), ^{
                      art_SafeBlockCall(completionBlock, error);
                  });
              } failureBlock: ^(NSError *error) {
                  art_SafeBlockCall(completionBlock, error);
              }];
}

+ (void)setRankStaffEntityForResultArray:(NSArray *)array
                                listType:(ARTRankListType)listType
                                   group:(dispatch_group_t)group
                              groupError:(NSError **)groupError
{
    if (!array || !array.count) { return; }
    
    dispatch_group_enter(group);
    [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
        for (NSDictionary * dict in array) {
            [Staff art_updateOrInsertEntityForResultDict:dict[@"Staff"] localContext:localContext listType:listType];
        }
    } completion: ^{
        LOG(@"leave : Staff");
        dispatch_group_leave(group);
    }];
}

+ (void)uoGetRankTopListWithTarget:(id)target
                   completionBlock:(ARTCompletionBlock)completionBlock
{
    __weak typeof(self) weakSelf = self;
    
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"rank/top.json"]
                httpFormat:@"GET"
                parameters:nil
              successBlock: ^(id resultObject) {
                  NSDictionary *resultDict = (NSDictionary *)resultObject;
                  NSDictionary *accessDict = resultDict[@"access"];
                  NSDictionary *arutoDict = resultDict[@"aruto"];
                  NSDictionary *maleDict = resultDict[@"male"];
                  NSDictionary *femaleDict = resultDict[@"female"];
                  NSDictionary *pickupDict = resultDict[@"pickup"];
                  
                  dispatch_group_t disGroup = dispatch_group_create();
                  NSError *error = nil;
                  
                  [weakSelf setTopRankStaffEntityForResultDict:accessDict
                                                      listType:ARTRankListTypeAccess
                                                         group:disGroup groupError:&error];
                  
                  [weakSelf setTopRankStaffEntityForResultDict:arutoDict
                                                      listType:ARTRankListTypeAruto
                                                         group:disGroup groupError:&error];
                  
                  [weakSelf setTopRankStaffEntityForResultDict:maleDict
                                                      listType:ARTRankListTypeMale
                                                         group:disGroup groupError:&error];
                  
                  [weakSelf setTopRankStaffEntityForResultDict:femaleDict
                                                      listType:ARTRankListTypeFemale
                                                         group:disGroup groupError:&error];
                  
                  [weakSelf setTopRankStaffEntityForResultDict:pickupDict
                                                      listType:ARTRankListTypePickup
                                                         group:disGroup groupError:&error];
                  
                  if (!error) {
                      [ARTUOCacheManager shared].isAlreadyRankUOTypeTop = YES;
                  }
                  dispatch_group_wait(disGroup, DISPATCH_TIME_FOREVER);
                  dispatch_async(dispatch_get_main_queue(), ^{
                      art_SafeBlockCall(completionBlock, error);
                  });
              } failureBlock: ^(NSError *error) {
                  art_SafeBlockCall(completionBlock, error);
              }];
}

+ (void)setTopRankStaffEntityForResultDict:(NSDictionary *)dict
                                  listType:(ARTRankListType)listType
                                     group:(dispatch_group_t)group
                                groupError:(NSError **)groupError;
{
    if (!dict || !dict.count) { return; }
    
    dispatch_group_enter(group);
    [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
        [Staff art_updateOrInsertEntityForResultDict:dict[@"Staff"] localContext:localContext listType:listType];
    } completion: ^{
        LOG(@"leave : Staff");
        dispatch_group_leave(group);
    }];
}

@end
