//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTBaseUO.h"
#import <AFNetworking.h>

@implementation ARTBaseUO

+ (void)uoBaseWithTarget:(id)target
               urlString:(NSString *)urlString
              httpFormat:(NSString *)httpFormat
              parameters:(id)parameters
            successBlock:(ARTSuccessBlock)successBlock
            failureBlock:(ARTFailureBlock)failureBlock
{
    [ARTAnalytics sendTrackWithCategoryName:@"API"
                                 actionName:urlString
                                  labelName:httpFormat
                                      value:@([ARTAnalytics dateToYYYYMMDDHHMM:[NSDate date]].integerValue)];

    if (![ARTUtils isReachable]) {
        NSError *error = [ARTUtils errorFOrType:ARTErrorTypeUONotReachable];
        art_SafeBlockCall(failureBlock, error);
        return;
    }

    LOG(@"urlString : %@", urlString);

    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.requestSerializer = [AFHTTPRequestSerializer serializer];
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
#ifndef RELEASE
    [manager.requestSerializer setAuthorizationHeaderFieldWithUsername:@"aruto" password:@"Arut00303"];
#endif
    
    [UIApplication art_pushNetworkActivityIndicator];

    __weak typeof(target) weakTarget = target;

    void (^uoSuccessblock)(NSURLSessionDataTask *task, id responseObject) = ^(NSURLSessionDataTask *task, id responseObject) {
        [UIApplication art_popNetworkActivityIndicator];
        if (!weakTarget) { return; }
        LOG(@"success : %@", responseObject);

        NSDictionary *resultDict = (NSDictionary *)responseObject;
        if (resultDict[@"error"]) {
            LOG(@"%@", resultDict[@"error"]);
            art_SafeBlockCall(failureBlock, [ARTUtils uoErrorForDict:resultDict[@"error"]]);
            return;
        }

        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                art_SafeBlockCall(successBlock, responseObject);
            });
    };

    void (^uoFailureBlock)(NSURLSessionDataTask *task, NSError *error) = ^(NSURLSessionDataTask *task, NSError *error) {
        [UIApplication art_popNetworkActivityIndicator];
        if (!weakTarget) { return; }
        LOG(@"failure : %@", error);
        art_SafeBlockCall(failureBlock, error);
    };

    if ([httpFormat isEqualToString:@"GET"]) {
        [manager GET:urlString
          parameters:parameters
             success:uoSuccessblock
             failure:uoFailureBlock];
    } else if ([httpFormat isEqualToString:@"POST"]) {
        [manager POST:urlString
           parameters:parameters
              success:uoSuccessblock
              failure:uoFailureBlock];
    }
}

+ (void)setEntityForResultArray:(NSArray *)array
             managedObjectClass:(Class)managedObjectClass
                        keyName:(NSString *)keyName
                completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!array || !array.count) {
        art_SafeBlockCall(completionBlock, nil);
        return;
    }

    [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
         for (NSDictionary * dict in array) {
             [managedObjectClass art_updateOrInsertEntityForResultDict:dict[keyName] localContext:localContext];
         }
     } completion: ^{
         art_SafeBlockCall(completionBlock, nil);
     }];
}

+ (void)setEntityForResultArray:(NSArray *)array
             managedObjectClass:(Class)managedObjectClass
                        keyName:(NSString *)keyName
                          group:(dispatch_group_t)group
                     groupError:(NSError **)groupError;
{
    if (!array || !array.count) { return; }

    dispatch_group_enter(group);
    [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
         for (NSDictionary * dict in array) {
             [managedObjectClass art_updateOrInsertEntityForResultDict:dict[keyName] localContext:localContext];
         }
     } completion: ^{
         LOG(@"leave : %@", keyName);
         dispatch_group_leave(group);
     }];
}

+ (void)setSingleEntityForResultDict:(NSDictionary *)dict
                  managedObjectClass:(Class)managedObjectClass
                             keyName:(NSString *)keyName
                               group:(dispatch_group_t)group
                          groupError:(NSError **)groupError
{
    if (!dict) { return; }

    dispatch_group_enter(group);
    [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
         [managedObjectClass art_updateOrInsertEntityForResultDict:dict[keyName] localContext:localContext];
     } completion: ^{
         LOG(@"leave : %@", keyName);
         dispatch_group_leave(group);
     }];
}

+ (void)setSingleEntityForResultDict:(NSDictionary *)dict
                  managedObjectClass:(Class)managedObjectClass
                             keyName:(NSString *)keyName
                     completionBlock:(ARTCompletionBlock)completionBlock
{
    [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
         [managedObjectClass art_updateOrInsertEntityForResultDict:dict[keyName] localContext:localContext];
     } completion: ^{
         art_SafeBlockCall(completionBlock, nil);
     }];
}

@end
