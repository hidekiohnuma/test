//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTJobUO.h"

@implementation ARTJobUO

+ (void)uoGetJobWithTarget:(id)target
                     jobId:(NSNumber *)jobId
           completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!jobId) {
        art_SafeBlockCall(completionBlock, [ARTUtils errorFOrType:ARTErrorTypeUOParametorError]);
        return;
    }

    __weak typeof(self) weakSelf = self;

    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"job.json"]
                httpFormat:@"GET"
                parameters:@{ @"job_id": jobId }
              successBlock: ^(id resultObject) {
         NSDictionary *resultDict = (NSDictionary *)resultObject;

         dispatch_group_t disGroup = dispatch_group_create();
         NSError *error = nil;

         [weakSelf setSingleEntityForResultDict:resultDict[@"JobData"]
                             managedObjectClass:[Job class]
                                        keyName:@"Job"
                                          group:disGroup groupError:&error];

         [weakSelf setEntityForResultArray:resultDict[@"JobJobOtherPoints"]
                        managedObjectClass:[JobJobOtherPoint class]
                                   keyName:@"JobJobOtherPoint"
                                     group:disGroup groupError:&error];

         dispatch_group_wait(disGroup, DISPATCH_TIME_FOREVER);
         dispatch_async(dispatch_get_main_queue(), ^{
                 art_SafeBlockCall(completionBlock, error);
             });
     } failureBlock: ^(NSError *error) {
         art_SafeBlockCall(completionBlock, error);
     }];
}

@end
