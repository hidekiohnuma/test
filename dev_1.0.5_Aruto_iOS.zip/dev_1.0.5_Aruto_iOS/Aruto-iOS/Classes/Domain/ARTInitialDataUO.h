//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import "ARTBaseUO.h"

@interface ARTInitialDataUO : ARTBaseUO

+ (void)uoGetInitialDataWithTarget:(id)target
                        updateDate:(NSString *)updateDate
                      successBlock:(ARTSuccessBlock)successBlock
                      failureBlock:(ARTFailureBlock)failureBlock;

@end
