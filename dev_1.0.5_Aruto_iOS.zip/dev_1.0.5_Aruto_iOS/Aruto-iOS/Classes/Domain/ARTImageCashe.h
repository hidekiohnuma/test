//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

// 今はもう使ってない

#import <Foundation/Foundation.h>

@interface ARTImageCashe : NSObject

+ (void)clearImageCache;

+ (void)addThumbnailImageWithImage:(UIImage *)image imageURL:(NSURL *)imageURL;
+ (void)addStoreImageWithImage:(UIImage *)image imageURL:(NSURL *)imageURL;

+ (UIImage *)hasCacheThumbnailImageWIthURL:(NSURL *)imageURL;
+ (UIImage *)hasCacheStoreImageWIthURL:(NSURL *)imageURL;

@end
