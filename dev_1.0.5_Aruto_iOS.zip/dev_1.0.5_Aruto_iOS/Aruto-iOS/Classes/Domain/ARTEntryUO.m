//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTEntryUO.h"

@implementation ARTEntryUO

+ (void)uoGetEntryListWithTarget:(id)target
                          userId:(NSNumber *)userId
                           index:(NSNumber *)index
                 completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!userId) {
        art_SafeBlockCall(completionBlock, [ARTUtils errorFOrType:ARTErrorTypeUOParametorError]);
        return;
    }
    
    __weak typeof(self) weakSelf = self;
    
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"entry/list.json"]
                httpFormat:@"GET"
                parameters:@{ @"user_id": userId, @"index": index }
              successBlock: ^(id resultObject) {
                  LOG(@"successBlock :%@", resultObject);
                  NSDictionary *resultDict = (NSDictionary *)resultObject;
                  
                  NSString *totalCount = resultDict[@"TotalCount"];
                  ARTUserDefaults.shared.entryTotalCount = totalCount.integerValue;
                  
                  dispatch_group_t disGroup = dispatch_group_create();
                  NSError *error = nil;
                  BOOL canNextCall = YES;
                  
                  NSArray *array = resultDict[@"Entries"];
                  if (array && array.count > 0) {
                      [weakSelf setEntityForResultArray:resultDict[@"Entries"]
                                     managedObjectClass:[Entry class]
                                                keyName:@"Entry"
                                                  group:disGroup groupError:&error];
                      
                      [weakSelf setEntityForResultArray:resultDict[@"Shops"]
                                     managedObjectClass:[Shop class]
                                                keyName:@"Shop"
                                                  group:disGroup groupError:&error];
                      
                      [weakSelf setEntityForResultArray:resultDict[@"Jobs"]
                                     managedObjectClass:[Job class]
                                                keyName:@"Job"
                                                  group:disGroup groupError:&error];
                  } else {
                      canNextCall = NO;
                  }
                  
                  dispatch_group_wait(disGroup, DISPATCH_TIME_FOREVER);
                  dispatch_async(dispatch_get_main_queue(), ^{
                      if (error) {
                          art_SafeBlockCall(completionBlock, error);
                      } else {
                          art_SafeBlockCall(completionBlock, @(canNextCall));
                      }
                  });
              } failureBlock: ^(NSError *error) {
                  LOG(@"failureBlock :%@", error.description);
                  art_SafeBlockCall(completionBlock, error);
              }];
}

+ (void)uoPostEntryListWithTarget:(id)target
                           userId:(NSNumber *)userId
                            jobId:(NSNumber *)jobId
                      contactType:(NSString *)contactType
                        firstName:(NSString *)firstName
                         lastName:(NSString *)lastName
                    firstNameKana:(NSString *)firstNameKana
                     lastNameKana:(NSString *)lastNameKana
                      phoneNumber:(NSString *)phoneNumber
                         birthday:(NSString *)birthday
                  completionBlock:(ARTCompletionBlock)completionBlock
{
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"entry/entry.json"]
                httpFormat:@"POST"
                parameters:@{ @"user_id": userId,
                              @"job_id": jobId,
                              @"contact_type": contactType,
                              @"first_name": firstName,
                              @"last_name": lastName,
                              @"first_name_kana": firstNameKana,
                              @"last_name_kana": lastNameKana,
                              @"phone_number": phoneNumber,
                              @"birthday": birthday }
              successBlock: ^(id resultObject) {
                  NSDictionary *resultDict = (NSDictionary *)resultObject;
                  NSDictionary *jobSeekerDataDict = resultDict[@"JobSeekerData"];
                  NSDictionary *jobseekerDict = jobSeekerDataDict[@"JobSeeker"];
                  if (jobseekerDict) {
                      [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
                          [User art_updateEntityForJobSeekerDict:jobseekerDict localContext:localContext];
                      } completion: ^{
                          LOG(@"save JobSeeker");
                          dispatch_async(dispatch_get_main_queue(), ^{
                              art_SafeBlockCall(completionBlock, nil);
                          });
                      }];
                  } else {
                      dispatch_async(dispatch_get_main_queue(), ^{
                          art_SafeBlockCall(completionBlock, nil);
                      });
                  }
              } failureBlock: ^(NSError *error) {
                  art_SafeBlockCall(completionBlock, error);
              }];
}

@end
