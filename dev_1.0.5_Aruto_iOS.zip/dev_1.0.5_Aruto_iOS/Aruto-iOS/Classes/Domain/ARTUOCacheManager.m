//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTUOCacheManager.h"

@interface ARTUOCacheManager ()

@property (nonatomic, strong) NSMutableSet *staffIdSet;
@property (nonatomic, strong) NSMutableSet *shopIdSet;
@property (nonatomic, strong) NSMutableSet *jobIdSet;
@property (nonatomic, assign) BOOL          isAlreadyRankUOTypeAccess;
@property (nonatomic, assign) BOOL          isAlreadyRankUOTypeAruto;
@property (nonatomic, assign) BOOL          isAlreadyRankUOTypeMale;
@property (nonatomic, assign) BOOL          isAlreadyRankUOTypeFemale;
@property (nonatomic, assign) BOOL          isAlreadyRankUOTypePickup;

@end

@implementation ARTUOCacheManager

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Singleton

+ (instancetype)shared
{
    static ARTUOCacheManager *_shared = nil;
    static dispatch_once_t    onceToken;
    dispatch_once(&onceToken, ^{
            _shared = [[ARTUOCacheManager alloc] initWithSingleton];
        });

    return _shared;
}

- (instancetype)initWithSingleton
{
    if (!(self = [super init])) { return nil; }

    return self;
}

- (instancetype)init
{
    [self doesNotRecognizeSelector:_cmd];
    return nil;
}

- (void)clear
{
    self.staffIdSet                = [NSMutableSet set];
    self.shopIdSet                 = [NSMutableSet set];
    self.jobIdSet                  = [NSMutableSet set];
    self.isAlreadyRankUOTypeTop    = NO;
    self.isAlreadyRankUOTypeAccess = NO;
    self.isAlreadyRankUOTypeAruto  = NO;
    self.isAlreadyRankUOTypeMale   = NO;
    self.isAlreadyRankUOTypeFemale = NO;
    self.isAlreadyRankUOTypePickup = NO;
}

- (void)setAlreadyRankUOForlistType:(ARTRankListType)listType
{
    switch (listType) {
        case ARTRankListTypeAccess:
            self.isAlreadyRankUOTypeAccess = YES;
            break;

        case ARTRankListTypeAruto:
            self.isAlreadyRankUOTypeAruto = YES;
            break;

        case ARTRankListTypeMale:
            self.isAlreadyRankUOTypeMale = YES;
            break;

        case ARTRankListTypeFemale:
            self.isAlreadyRankUOTypeFemale = YES;
            break;

        case ARTRankListTypePickup:
            self.isAlreadyRankUOTypePickup = YES;
            break;
    }
}

- (BOOL)isAlreadyRankUOForlistType:(ARTRankListType)listType
{
    switch (listType) {
        case ARTRankListTypeAccess:
            return self.isAlreadyRankUOTypeAccess == YES;

        case ARTRankListTypeAruto:
            return self.isAlreadyRankUOTypeAruto == YES;

        case ARTRankListTypeMale:
            return self.isAlreadyRankUOTypeMale == YES;

        case ARTRankListTypeFemale:
            return self.isAlreadyRankUOTypeFemale == YES;

        case ARTRankListTypePickup:
            return self.isAlreadyRankUOTypePickup == YES;
    }
    return NO;
}

- (void)addStaffId:(NSNumber *)staffId
{
    if (!staffId) { return; }

    [self.staffIdSet addObject:staffId];
}

- (void)addShopId:(NSNumber *)shopfId
{
    if (!shopfId) { return; }

    [self.shopIdSet addObject:shopfId];
}

- (void)addJobId:(NSNumber *)jobId
{
    if (!jobId) { return; }

    [self.jobIdSet addObject:jobId];
}

- (BOOL)containsStaffId:(NSNumber *)staffId
{
    if (!staffId) { return NO; }

    if ([self.staffIdSet containsObject:staffId]) {
        return YES;
    } else {
        return NO;
    }
}

- (BOOL)containsShopId:(NSNumber *)shopfId
{
    if (!shopfId) { return NO; }

    if ([self.shopIdSet containsObject:shopfId]) {
        return YES;
    } else {
        return NO;
    }
}

- (BOOL)containsJobId:(NSNumber *)jobId
{
    if (!jobId) { return NO; }

    if ([self.jobIdSet containsObject:jobId]) {
        return YES;
    } else {
        return NO;
    }
}

@end
