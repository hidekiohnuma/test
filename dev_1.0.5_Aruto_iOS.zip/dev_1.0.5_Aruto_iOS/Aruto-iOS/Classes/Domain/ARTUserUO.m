//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTUserUO.h"

NSString *const ARTParamDeviceTokenKey = @"device_token";
NSString *const ARTParamEmailKey       = @"email";
NSString *const ARTParamPasswordKey    = @"password";
NSString *const ARTParamFacebookIdKey  = @"facebook_id";
NSString *const ARTParamTwitterIdKey   = @"twitter_id";

@implementation ARTUserUO

+ (ARTSuccessBlock)successBlock:(ARTCompletionBlock)completionBlock
{
    return ^(id resultObject) {
        NSDictionary *resultDict = (NSDictionary *)resultObject;
        
        NSDictionary    *userDict = resultDict[@"UserData"];
        NSDictionary *jobSeekerDict = resultDict[@"JobSeekerData"];
        NSDictionary *dataDict = jobSeekerDict[@"JobSeeker"];
        __block NSError *dbError  = nil;
        
        ARNDeferred *def = [ARNDeferred deferred];
        def.then ( ^(ARNDeferredTask *deferredTask, id resultObj) {
            [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
                [User art_updateOrInsertEntityForResultDict:userDict[@"User"]
                                              jobSeekerDict:dataDict
                                               localContext:localContext];
            } completion: ^{
                [deferredTask done:nil];
            }];
        });
        def.then ( ^(ARNDeferredTask *deferredTask, id resultObj) {
            NSArray *favoriteShopDatas = resultDict[@"FavoriteShops"];
            NSArray *favoriteStaffDatas = resultDict[@"FavoriteStaffs"];
            [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
                if (favoriteShopDatas && favoriteShopDatas.count) {
                    for (NSDictionary * entityDict in favoriteShopDatas) {
                        if (entityDict[@"FavoriteShop"]) {
                            [FavoriteShop art_updateOrInsertEntityForResultDict:entityDict[@"FavoriteShop"] localContext:localContext];
                        }
                    }
                }
                if (favoriteStaffDatas && favoriteStaffDatas.count) {
                    for (NSDictionary * entityDict in favoriteStaffDatas) {
                        if (entityDict[@"FavoriteStaff"]) {
                            [FavoriteStaff art_updateOrInsertEntityForResultDict:entityDict[@"FavoriteStaff"] localContext:localContext];
                        }
                    }
                }
            } completion: ^{
                [deferredTask done:nil];
            }];
        });
        def.then ( ^(ARNDeferredTask *deferredTask, id resultObj) {
            if (dbError) {
                LOG(@"end dispatch failure");
            } else {
                LOG(@"end dispatch success");
            }
            dispatch_async(dispatch_get_main_queue(), ^{
                art_SafeBlockCall(completionBlock, dbError);
                [deferredTask done:nil];
            });
        });
        [def runDeferred:nil];
    };
}

+ (ARTSuccessBlock)failureBlock:(ARTCompletionBlock)completionBlock
{
    return ^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            art_SafeBlockCall(completionBlock, error);
        });
    };
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Create

+ (void)uoCreateUserWithTarget:(id)target
                    facebookId:(NSString *)facebookId
               completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!target || !facebookId) {
        art_SafeBlockCall(completionBlock, [ARTUtils errorFOrType:ARTErrorTypeUOUserCreate]);
        return;
    }
    LOG(@"facebookId : %@", facebookId);
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:facebookId forKey:ARTParamFacebookIdKey];
    [params setObject:[ARTUserDefaults shared].deviceToken forKey:ARTParamDeviceTokenKey];
    
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"user/create_user_facebook.json"]
                httpFormat:@"POST"
                parameters:params
              successBlock:[self successBlock:completionBlock]
              failureBlock:[self failureBlock:completionBlock]];
}

+ (void)uoCreateUserWithTarget:(id)target
                     twitterId:(NSString *)twitterId
               completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!target || !twitterId) {
        art_SafeBlockCall(completionBlock, [ARTUtils errorFOrType:ARTErrorTypeUOUserCreate]);
        return;
    }
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:twitterId forKey:ARTParamTwitterIdKey];
    [params setObject:[ARTUserDefaults shared].deviceToken forKey:ARTParamDeviceTokenKey];
    
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"user/create_user_twitter.json"]
                httpFormat:@"POST"
                parameters:params
              successBlock:[self successBlock:completionBlock]
              failureBlock:[self failureBlock:completionBlock]];
}

+ (void)uoCreateUserWithTarget:(id)target
                         email:(NSString *)email
                      password:(NSString *)password
               completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!target || !email || !password) {
        art_SafeBlockCall(completionBlock, [ARTUtils errorFOrType:ARTErrorTypeUOUserCreate]);
        return;
    }
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:email forKey:ARTParamEmailKey];
    [params setObject:password forKey:ARTParamPasswordKey];
    [params setObject:[ARTUserDefaults shared].deviceToken forKey:ARTParamDeviceTokenKey];
    
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"user/create_user_email.json"]
                httpFormat:@"POST"
                parameters:params
              successBlock:[self successBlock:completionBlock]
              failureBlock:[self failureBlock:completionBlock]];
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Login

+ (void)uoLoginUserWithTarget:(id)target
                   facebookId:(NSString *)facebookId
              completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!target || !facebookId) {
        art_SafeBlockCall(completionBlock, [ARTUtils errorFOrType:ARTErrorTypeUOLogin]);
        return;
    }
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:facebookId forKey:ARTParamFacebookIdKey];
    [params setObject:[ARTUserDefaults shared].deviceToken forKey:ARTParamDeviceTokenKey];
    
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"user/login_facebook.json"]
                httpFormat:@"GET"
                parameters:params
              successBlock:[self successBlock:completionBlock]
              failureBlock:[self failureBlock:completionBlock]];
}

+ (void)uoLoginUserWithTarget:(id)target
                    twitterId:(NSString *)twitterId
              completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!target || !twitterId) {
        art_SafeBlockCall(completionBlock, [ARTUtils errorFOrType:ARTErrorTypeUOLogin]);
        return;
    }
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:twitterId forKey:ARTParamTwitterIdKey];
    [params setObject:[ARTUserDefaults shared].deviceToken forKey:ARTParamDeviceTokenKey];
    
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"user/login_twitter.json"]
                httpFormat:@"GET"
                parameters:params
              successBlock:[self successBlock:completionBlock]
              failureBlock:[self failureBlock:completionBlock]];
}

+ (void)uoLoginUserWithTarget:(id)target
                        email:(NSString *)email
                     password:(NSString *)password
              completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!target || !email || !password) {
        art_SafeBlockCall(completionBlock, [ARTUtils errorFOrType:ARTErrorTypeUOLogin]);
        return;
    }
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:email forKey:ARTParamEmailKey];
    [params setObject:password forKey:ARTParamPasswordKey];
    [params setObject:[ARTUserDefaults shared].deviceToken forKey:ARTParamDeviceTokenKey];
    
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"user/login_email.json"]
                httpFormat:@"GET"
                parameters:params
              successBlock:[self successBlock:completionBlock]
              failureBlock:[self failureBlock:completionBlock]];
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Update Device Token

+ (void)uoSendDeviceTokenWithTarget:(id)target
                       successBlock:(ARTSuccessBlock)successBlock
                       failureBlock:(ARTFailureBlock)failureBlock
{
    // チェックはしない
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setObject:[ARTUserManager shared].userId forKey:ARTParamEmailKey];
    [params setObject:[ARTUserDefaults shared].deviceToken forKey:ARTParamDeviceTokenKey];
    
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"user/device_token.json"]
                httpFormat:@"POST"
                parameters:params
              successBlock:successBlock
              failureBlock:failureBlock];
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Setting Notification

+ (void)uoChangeNotificationWithTarget:(id)target
                           isShopNotis:(BOOL)isShopNotis
                            canReceive:(BOOL)canReceive
                       completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!target) {
        art_SafeBlockCall(completionBlock, [ARTUtils errorFOrType:ARTErrorTypeUOChangeNotis]);
        return;
    }
    
    NSString *urlString;
    if (isShopNotis) {
        urlString = [ARTBaseURL stringByAppendingString:@"user/change_shop_notis.json"];
    } else {
        urlString = [ARTBaseURL stringByAppendingString:@"user/change_aruto_notis.json"];
    }
    
    [self uoBaseWithTarget:self
                 urlString:urlString
                httpFormat:@"POST"
                parameters:@{ @"user_id": [[ARTUserManager shared] userId], @"can_receive": @(canReceive) }
              successBlock: ^(id resultObject) {
                  //NSDictionary *resultDict = (NSDictionary *)resultObject;
                  
                  [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
                      User *entity = [User art_userForLocalContext:localContext];
                      if (isShopNotis) {
                          entity.notificationForYouflg = @(canReceive);
                      } else {
                          entity.notificationForAllflg = @(canReceive);
                      }
                  } completion: ^{
                      dispatch_async(dispatch_get_main_queue(), ^{
                          art_SafeBlockCall(completionBlock, nil);
                      });
                  }];
              } failureBlock: ^(NSError *error) {
                  art_SafeBlockCall(completionBlock, error);
              }];
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Forget Password

+ (void)uoReissueEmailWithTarget:(id)target
                           email:(NSString *)email
                 completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!target || !email) {
        art_SafeBlockCall(completionBlock, [ARTUtils errorFOrType:ARTErrorTypeUOChangeNotis]);
        return;
    }
    
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"user/reissue_email.json"]
                httpFormat:@"GET"
                parameters:@{ @"email": email }
              successBlock: ^(id resultObject) {
                  dispatch_async(dispatch_get_main_queue(), ^{
                      art_SafeBlockCall(completionBlock, nil);
                  });
              } failureBlock: ^(NSError *error) {
                  art_SafeBlockCall(completionBlock, error);
              }];
}

@end
