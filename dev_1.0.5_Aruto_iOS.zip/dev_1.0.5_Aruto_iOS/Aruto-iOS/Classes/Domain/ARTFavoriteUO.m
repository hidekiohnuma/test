//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTFavoriteUO.h"

@implementation ARTFavoriteUO

+ (void)uoGetFavoriteListWithTarget:(id)target
                            isStaff:(BOOL)isStaff
                             userId:(NSNumber *)userId
                              index:(NSNumber *)index
                    completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!userId) {
        art_SafeBlockCall(completionBlock, [ARTUtils errorFOrType:ARTErrorTypeUOParametorError]);
        return;
    }

    NSString *favoriteType = @"";
    if (isStaff) {
        favoriteType = @"1";
    } else {
        favoriteType = @"2";
    }

    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"favorite/list.json"]
                httpFormat:@"GET"
                parameters:@{ @"user_id": userId, @"index": index, @"favorite_type": favoriteType }
              successBlock: ^(id resultObject) {
         NSDictionary *resultDict = (NSDictionary *)resultObject;

         __block NSError *dbError = nil;
         __block BOOL canNextCall = YES;

         ARNDeferred *def = [ARNDeferred deferred];
         def.then ( ^(ARNDeferredTask *deferredTask, id resultObj) {
                        if (index.integerValue == 0) {
                            if (isStaff) {
                                [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
                                     [FavoriteStaff art_deleteAllEntiteisForLocalContext:localContext];
                                 } completion: ^{
                                     LOG(@"done : DeleteAll FavoriteStaff");
                                     [deferredTask done:nil];
                                 }];
                            } else {
                                [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
                                     [FavoriteShop art_deleteAllEntiteisForLocalContext:localContext];
                                 } completion: ^{
                                     LOG(@"done : DeleteAll FavoriteShop");
                                     [deferredTask done:nil];
                                 }];
                            }
                        } else {
                            [deferredTask done:nil];
                        }
                    });
         def.then ( ^(ARNDeferredTask *deferredTask, id resultObj) {
                        NSArray *staffDatas = resultDict[@"Staffs"];
                        NSArray *shopDatas = resultDict[@"Shops"];
                        NSArray *jobDatas = resultDict[@"Jobs"];
                        NSArray *favoriteShopDatas = resultDict[@"FavoriteShops"];
                        NSArray *favoriteStaffDatas = resultDict[@"FavoriteStaffs"];

                        NSArray *array;
                        if (isStaff) {
                            array = staffDatas;
                        } else {
                            array = shopDatas;
                        }
                        if (!array || !array.count) {
                            canNextCall = NO;
                        }

                        [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
                             if (staffDatas && staffDatas.count) {
                                 for (NSDictionary * entityDict in staffDatas) {
                                     [Staff art_updateOrInsertEntityForResultDict:entityDict[@"Staff"] localContext:localContext];
                                 }
                             }
                             if (shopDatas && shopDatas.count) {
                                 for (NSDictionary * entityDict in shopDatas) {
                                     [Shop art_updateOrInsertEntityForResultDict:entityDict[@"Shop"] localContext:localContext];
                                 }
                             }
                             if (jobDatas && jobDatas.count) {
                                 for (NSDictionary * entityDict in jobDatas) {
                                     [Job art_updateOrInsertEntityForResultDict:entityDict[@"Job"] localContext:localContext];
                                 }
                             }
                             if (favoriteStaffDatas && favoriteStaffDatas.count) {
                                 for (NSDictionary * entityDict in favoriteStaffDatas) {
                                     [FavoriteStaff art_updateOrInsertEntityForResultDict:entityDict[@"FavoriteStaff"] localContext:localContext];
                                 }
                             }
                             if (favoriteShopDatas && favoriteShopDatas.count) {
                                 for (NSDictionary * entityDict in favoriteShopDatas) {
                                     [FavoriteShop art_updateOrInsertEntityForResultDict:entityDict[@"FavoriteShop"] localContext:localContext];
                                 }
                             }
                         } completion: ^{
                             LOG(@"done : StaffDatas Staff");
                             [deferredTask done:nil];
                         }];
                    });
         def.then ( ^(ARNDeferredTask *deferredTask, id resultObj) {
                        dispatch_async(dispatch_get_main_queue(), ^{
                                if (dbError) {
                                    art_SafeBlockCall(completionBlock, dbError);
                                } else {
                                    art_SafeBlockCall(completionBlock, @(canNextCall));
                                }
                            });
                        [deferredTask done:nil];
                    });
         [def runDeferred:nil];
     } failureBlock: ^(NSError *error) {
         art_SafeBlockCall(completionBlock, error);
     }];
}

+ (void)uoAddStaffFavoriteWithTarget:(id)target
                              userId:(NSNumber *)userId
                             staffId:(NSNumber *)staffId
                     completionBlock:(ARTCompletionBlock)completionBlock
{
    [self uoEditFavoriteWithTarget:target userId:userId isAdd:YES isStaff:YES targetId:staffId completionBlock:completionBlock];
}

+ (void)uoDeleteStaffFavoriteWithTarget:(id)target
                                 userId:(NSNumber *)userId
                                staffId:(NSNumber *)staffId
                        completionBlock:(ARTCompletionBlock)completionBlock
{
    [self uoEditFavoriteWithTarget:target userId:userId isAdd:NO isStaff:YES targetId:staffId completionBlock:completionBlock];
}

+ (void)uoAddShopFavoriteWithTarget:(id)target
                             userId:(NSNumber *)userId
                             shopId:(NSNumber *)shopId
                    completionBlock:(ARTCompletionBlock)completionBlock
{
    [self uoEditFavoriteWithTarget:target userId:userId isAdd:YES isStaff:NO targetId:shopId completionBlock:completionBlock];
}

+ (void)uoDeleteShopFavoriteWithTarget:(id)target
                                userId:(NSNumber *)userId
                                shopId:(NSNumber *)shopId
                       completionBlock:(ARTCompletionBlock)completionBlock
{
    [self uoEditFavoriteWithTarget:target userId:userId isAdd:NO isStaff:NO targetId:shopId completionBlock:completionBlock];
}

+ (void)uoEditFavoriteWithTarget:(id)target
                          userId:(NSNumber *)userId
                           isAdd:(BOOL)isAdd
                         isStaff:(BOOL)isStaff
                        targetId:(NSNumber *)targetId
                 completionBlock:(ARTCompletionBlock)completionBlock
{
    NSString *editType = @"";
    if (isAdd) {
        editType = @"1";
    } else {
        editType = @"2";
    }

    NSString *favoriteType = @"";
    NSString *paramKey     = @"";
    if (isStaff) {
        favoriteType = @"1";
        paramKey     = @"staff_id";
    } else {
        favoriteType = @"2";
        paramKey     = @"shop_id";
    }

    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"favorite/edit.json"]
                httpFormat:@"POST"
                parameters:@{ @"user_id": userId,
                              @"edit_type": editType,
                              @"favorite_type": favoriteType,
                              paramKey: targetId }
              successBlock: ^(id resultObject) {
         LOG(@"successBlock :%@", resultObject);
         NSDictionary *resultDict = (NSDictionary *)resultObject;
         if (resultObject[@"error"]) {
             LOG(@"%@", resultObject[@"error"]);
             dispatch_async(dispatch_get_main_queue(), ^{
                     art_SafeBlockCall(completionBlock, [ARTUtils uoErrorForDict:resultObject[@"error"]]);
                 });
             return;
         }

         ARNDeferred *def = [ARNDeferred deferred];
         def.then ( ^(ARNDeferredTask *deferredTask, id resultObj) {
                        if (isStaff) {
                            [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
                                 [FavoriteStaff art_deleteAllEntiteisForLocalContext:localContext];
                             } completion: ^{
                                 LOG(@"done : DeleteAll FavoriteStaff");
                                 [deferredTask done:nil];
                             }];
                        } else {
                            [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
                                 [FavoriteShop art_deleteAllEntiteisForLocalContext:localContext];
                             } completion: ^{
                                 LOG(@"done : DeleteAll FavoriteShop");
                                 [deferredTask done:nil];
                             }];
                        }
                    });
         def.then ( ^(ARNDeferredTask *deferredTask, id resultObj) {
                        dispatch_group_t disGroup = dispatch_group_create();
                        NSError *error = nil;

                        [self setEntityForResultArray:resultDict[@"FavoriteShops"]
                                   managedObjectClass:[FavoriteShop class]
                                              keyName:@"FavoriteShop"
                                                group:disGroup groupError:&error];

                        [self setEntityForResultArray:resultDict[@"FavoriteStaffs"]
                                   managedObjectClass:[FavoriteStaff class]
                                              keyName:@"FavoriteStaff"
                                                group:disGroup groupError:&error];

                        dispatch_group_wait(disGroup, DISPATCH_TIME_FOREVER);
                        if (error) {
                            LOG(@"end dispatch failure");
                            dispatch_async(dispatch_get_main_queue(), ^{
                                    art_SafeBlockCall(completionBlock, error);
                                });
                        } else {
                            LOG(@"end dispatch success");
                            dispatch_async(dispatch_get_main_queue(), ^{
                                    art_SafeBlockCall(completionBlock, nil);
                                });
                        }
                        [deferredTask done:nil];
                    });
         [def runDeferred:nil];
     } failureBlock: ^(NSError *error) {
         art_SafeBlockCall(completionBlock, error);
     }];
}

@end
