//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTTaskManager.h"

#import "ARTSearchDataUpdateTask.h"
#import "ARTFavoriteUO.h"
#import "ARTUserUO.h"
#import "ARTAvailableSearchDataUO.h"

@interface ARTTaskManager ()

@property (nonatomic, strong, readwrite) ARTSearchDataUpdateTask *initialTask;

@end

@implementation ARTTaskManager

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Singleton

+ (instancetype)shared
{
    static ARTTaskManager *_shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _shared = [[ARTTaskManager alloc] initWithSingleton];
    });
    
    return _shared;
}

- (instancetype)initWithSingleton
{
    if (!(self = [super init])) { return nil; }
    
    return self;
}

- (instancetype)init
{
    [self doesNotRecognizeSelector:_cmd];
    return nil;
}

- (void)scheduleTaskWithSelector:(SEL)selector
{
    [self performSelector:selector withObject:nil afterDelay:2.0];
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Task InitData

- (void)startInitialDataTask
{
    __weak typeof(self) weakSelf = self;
    
    if (![ARTUserDefaults shared].isFinishInitialDataLoad) {
        [[ARTViewContainer shared] showLoadingView];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [weakSelf loadInitialData];
        });
    }
    
    if (![ARTUserDefaults shared].isFinishInitialBigDataLoad) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [weakSelf loadInitialBigData];
        });
    }
    
    if ([ARTUserDefaults shared].isFinishInitialDataLoad &&
        [ARTUserDefaults shared].isFinishInitialBigDataLoad) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            [weakSelf updateAvailableSearchDataTask];
        });
    }
    
    // 時間かかるから使わなくなった
    //    if (self.initialTask) { return; }
    //
    //    if (!ARTUserDefaults.shared.isFinishInitialDataLoad) {
    //        [[ARTViewContainer shared] showLoadingView];
    //    }
    //
    //    self.initialTask             = [[ARTSearchDataUpdateTask alloc] init];
    //    __weak typeof(self) weakSelf = self;
    //
    //    [self.initialTask startWithSuccessBlock:
    //     ^(id resultObject) {
    //         if (!ARTUserDefaults.shared.isFinishInitialDataLoad) {
    //             [[ARTViewContainer shared] hideLoadingView];
    //         }
    //         ARTUserDefaults.shared.isFinishInitialDataLoad = YES;
    //         weakSelf.initialTask = nil;
    //     }                         failureBlock: ^(NSError *error) {
    //         weakSelf.initialTask = nil;
    //
    //         if (!ARTUserDefaults.shared.isFinishInitialDataLoad) {
    //             [UIAlertView bk_showAlertViewWithTitle:@"エラー"
    //                                            message:@"データ取得に失敗しました。\n通信環境を確認してリトライして下さい。"
    //                                  cancelButtonTitle:@"リトライ"
    //                                  otherButtonTitles:nil
    //                                            handler: ^(UIAlertView *alertView, NSInteger buttonIndex) {
    //                  [weakSelf scheduleTask];
    //              }];
    //         } else {
    //             [weakSelf scheduleTask];
    //         }
    //     }];
}

- (void)loadInitialData
{
    dispatch_group_t disGroup = dispatch_group_create();
    NSError         *error    = nil;
    
    [self setEntityForJsonName:@"Areas"
            managedObjectClass:[Area class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"Prefectures"
            managedObjectClass:[Prefecture class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"Cities"
            managedObjectClass:[City class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"Sexes"
            managedObjectClass:[Sex class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"Generations"
            managedObjectClass:[Generation class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"HobbyTypes"
            managedObjectClass:[HobbyType class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"Hobbies"
            managedObjectClass:[Hobby class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"FutureGoals"
            managedObjectClass:[FutureGoal class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"JobTypeCategories"
            managedObjectClass:[JobTypeCategory class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"EntryStatuses"
            managedObjectClass:[EntryStatus class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"JobTypes"
            managedObjectClass:[JobType class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"JobOtherPoints"
            managedObjectClass:[JobOtherPoint class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"SalaryDayTypes"
            managedObjectClass:[SalaryDayType class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"SalaryHourTypes"
            managedObjectClass:[SalaryHourType class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"WorkDayTypes"
            managedObjectClass:[WorkDayType class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"StaffOtherQuestions"
            managedObjectClass:[StaffOtherQuestion class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"SchoolTypes"
            managedObjectClass:[SchoolType class]
                         group:disGroup groupError:&error];
    
    [self setEntityForJsonName:@"AccessMethods"
            managedObjectClass:[AccessMethod class]
                         group:disGroup groupError:&error];
    
    [self setEntityForPlistName:@"TrainLines"
             managedObjectClass:[TrainLine class]
                          group:disGroup groupError:&error];
    
    __weak typeof(self) weakSelf = self;
    
    dispatch_group_wait(disGroup, DISPATCH_TIME_FOREVER);
    if (error) {
        LOG(@"loadInitialDataForPlist failure");
        if (!ARTUserDefaults.shared.isFinishInitialDataLoad) {
            [ARNAlert showAlertWithTitle:@"エラー"
                                message:@"データ取得に失敗しました。\n通信環境を確認してリトライして下さい。"
                      cancelButtonTitle:nil
                            cancelBlock:nil
                          okButtonTitle:@"リトライ"
                                okBlock:^(id action) {
                              [weakSelf scheduleTaskWithSelector:@selector(loadInitialData)];
                                }];
        } else {
            [weakSelf scheduleTaskWithSelector:@selector(loadInitialData)];
        }
    } else {
        LOG(@"loadInitialDataForPlist success");
        dispatch_async(dispatch_get_main_queue(), ^{
            ARTUserDefaults.shared.isFinishInitialDataLoad = YES;
            [[ARTViewContainer shared] hideLoadingView];
            [weakSelf updateAvailableSearchDataTask];
        });
    }
}

- (void)loadInitialBigData
{
    dispatch_group_t disGroup = dispatch_group_create();
    NSError         *error    = nil;
    
    [self setEntityForJsonName:@"Schools"
            managedObjectClass:[School class]
                         group:disGroup groupError:&error];
    
    [self setEntityForPlistName:@"TrainStations"
             managedObjectClass:[TrainStation class]
                          group:disGroup groupError:&error];
    
    __weak typeof(self) weakSelf = self;
    
    dispatch_group_wait(disGroup, DISPATCH_TIME_FOREVER);
    if (error) {
        LOG(@"loadInitialBigData failure");
        [weakSelf scheduleTaskWithSelector:@selector(loadInitialBigData)];
    } else {
        LOG(@"loadInitialBigData success");
        dispatch_async(dispatch_get_main_queue(), ^{
            ARTUserDefaults.shared.isFinishInitialBigDataLoad = YES;
            [weakSelf updateAvailableSearchDataTask];
        });
    }
}

- (void)setEntityForJsonName:(NSString *)jsonName
          managedObjectClass:(Class)managedObjectClass
                       group:(dispatch_group_t)group
                  groupError:(NSError **)groupError;
{
    NSString     *filePath   = [[NSBundle mainBundle] pathForResource:jsonName ofType:@"json"];
    NSString     *jsonString = [[NSString alloc] initWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    NSData       *data       = [jsonString dataUsingEncoding:NSUTF8StringEncoding];
    NSError      *jsonError  = nil;
    NSDictionary *json       = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingAllowFragments error:&jsonError];
    if (!json) { return; }
    
    if (group) {
        dispatch_group_enter(group);
    }
    [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
        for (NSDictionary * dict in json) {
            //LOG(@"save : %@", jsonName);
            [managedObjectClass art_updateOrInsertEntityForResultDict:dict localContext:localContext];
        }
    } completion: ^{
        LOG(@"leave : %@", managedObjectClass);
        if (group) {
            dispatch_group_leave(group);
        }
    }];
}

- (void)setEntityForPlistName:(NSString *)plistName
           managedObjectClass:(Class)managedObjectClass
                        group:(dispatch_group_t)group
                   groupError:(NSError **)groupError;
{
    NSArray *array = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:plistName ofType:@"plist"]];
    if (!array.count) { return; }
    
    if (group) {
        dispatch_group_enter(group);
    }
    [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
        for (NSDictionary * dict in array) {
            //LOG(@"save : %@", plistName);
            [managedObjectClass art_updateOrInsertEntityForResultDict:dict localContext:localContext];
        }
    } completion: ^{
        LOG(@"leave : %@", managedObjectClass);
        if (group) {
            dispatch_group_leave(group);
        }
    }];
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Task Favorite

- (void)addFavoriteWithStaffId:(NSNumber *)staffId completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!staffId) { return; }
    
    [self editFavoriteWithStaffId:staffId isEditTypeAdd:YES completionBlock:completionBlock];
}

- (void)removeFavoriteWithStaffId:(NSNumber *)staffId completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!staffId) { return; }
    
    [self editFavoriteWithStaffId:staffId isEditTypeAdd:NO completionBlock:completionBlock];
}

- (void)editFavoriteWithStaffId:(NSNumber *)staffId
                  isEditTypeAdd:(BOOL)isEditTypeAdd
                completionBlock:(ARTCompletionBlock)completionBlock
{
    @synchronized(self)
    {
        if ([FavoriteStaff art_isFavoriteForStaffId:staffId] == isEditTypeAdd) {
            art_SafeBlockCall(completionBlock, nil);
            return;
        }
        
        if (isEditTypeAdd) {
            [ARTFavoriteUO uoAddStaffFavoriteWithTarget:self
                                                 userId:[ARTUserManager shared].userId
                                                staffId:staffId
                                        completionBlock: ^(id resultObject) {
                                            if ([resultObject isKindOfClass:[NSError class]]) {
                                                NSError *error = (NSError *)resultObject;
                                                LOG(@"add favorite error %@", error.localizedFailureReason);
                                            } else {
                                                [[NSNotificationCenter defaultCenter] postNotificationName:ARTNofiricationFavoriteStaffChenged
                                                                                                    object:staffId
                                                                                                  userInfo:nil];
                                                LOG(@"add favorite success %@", staffId);
                                            }
                                            art_SafeBlockCall(completionBlock, resultObject);
                                        }];
        } else {
            [ARTFavoriteUO uoDeleteStaffFavoriteWithTarget:self
                                                    userId:[ARTUserManager shared].userId
                                                   staffId:staffId
                                           completionBlock: ^(id resultObject) {
                                               if ([resultObject isKindOfClass:[NSError class]]) {
                                                   NSError *error = (NSError *)resultObject;
                                                   LOG(@"remove favorite error %@", error);
                                               } else {
                                                   [[NSNotificationCenter defaultCenter] postNotificationName:ARTNofiricationFavoriteStaffChenged
                                                                                                       object:staffId
                                                                                                     userInfo:nil];
                                                   LOG(@"remove favorite success %@", staffId);
                                               }
                                               art_SafeBlockCall(completionBlock, resultObject);
                                           }];
        }
    }
}

- (void)addFavoriteWithShopId:(NSNumber *)shopId completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!shopId) { return; }
    
    [self editFavoriteWithShopId:shopId isEditTypeAdd:YES completionBlock:completionBlock];
}

- (void)removeFavoriteWithShopId:(NSNumber *)shopId completionBlock:(ARTCompletionBlock)completionBlock
{
    if (!shopId) { return; }
    
    [self editFavoriteWithShopId:shopId isEditTypeAdd:NO completionBlock:completionBlock];
}

- (void)editFavoriteWithShopId:(NSNumber *)shopId
                 isEditTypeAdd:(BOOL)isEditTypeAdd
               completionBlock:(ARTCompletionBlock)completionBlock
{
    @synchronized(self)
    {
        if ([FavoriteShop art_isFavoriteForShopId:shopId] == isEditTypeAdd) {
            art_SafeBlockCall(completionBlock, nil);
            return;
        }
        
        if (isEditTypeAdd) {
            [ARTFavoriteUO uoAddShopFavoriteWithTarget:self
                                                userId:[ARTUserManager shared].userId
                                                shopId:shopId
                                       completionBlock: ^(id resultObject) {
                                           if ([resultObject isKindOfClass:[NSError class]]) {
                                               NSError *error = (NSError *)resultObject;
                                               LOG(@"add favorite error %@", error.localizedFailureReason);
                                           } else {
                                               [[NSNotificationCenter defaultCenter] postNotificationName:ARTNofiricationFavoriteShopChenged
                                                                                                   object:shopId
                                                                                                 userInfo:nil];
                                               LOG(@"add favorite success %@", shopId);
                                           }
                                           art_SafeBlockCall(completionBlock, resultObject);
                                       }];
        } else {
            [ARTFavoriteUO uoDeleteShopFavoriteWithTarget:self
                                                   userId:[ARTUserManager shared].userId
                                                   shopId:shopId
                                          completionBlock: ^(id resultObject) {
                                              if ([resultObject isKindOfClass:[NSError class]]) {
                                                  NSError *error = (NSError *)resultObject;
                                                  LOG(@"remove favorite error %@", error);
                                              } else {
                                                  [[NSNotificationCenter defaultCenter] postNotificationName:ARTNofiricationFavoriteShopChenged
                                                                                                      object:shopId
                                                                                                    userInfo:nil];
                                                  LOG(@"remove favorite success %@", shopId);
                                              }
                                              art_SafeBlockCall(completionBlock, resultObject);
                                          }];
        }
    }
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Update DeviceToken

- (void)updateDeviceTokenTaskWithDeviceTokenString:(NSString *)deviceTokenString retryCount:(int)retryCount
{
    if ([deviceTokenString isEqualToString:[ARTUserDefaults shared].deviceToken]) { return; }
    
    if ([ARTUserManager shared].isLogined) {
        [self scheduleUpdateDeviceTokenWithDeviceTokenString:deviceTokenString retryCount:retryCount];
    } else {
        [ARTUserDefaults shared].deviceToken = deviceTokenString;
    }
}

- (void)scheduleUpdateDeviceTokenWithDeviceTokenString:(NSString *)deviceTokenString retryCount:(int)retryCount
{
    retryCount++;
    __weak typeof(self) weakSelf = self;
    [ARTUserUO uoSendDeviceTokenWithTarget:self
                              successBlock:^(id resultObject) {
                                  [ARTUserDefaults shared].deviceToken = deviceTokenString;
                              } failureBlock:^(NSError *error) {
                                  if (retryCount >= 20) {
                                      return;
                                  }
                                  dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                                      [NSThread sleepForTimeInterval:5];
                                      dispatch_async(dispatch_get_main_queue(), ^{
                                          [weakSelf updateDeviceTokenTaskWithDeviceTokenString:deviceTokenString retryCount:retryCount];
                                      });
                                  });
                              }];
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Update SearchData

- (void)updateAvailableSearchDataTask
{
    if (![ARTUtils isReachable]) {
        // TODO : 接続できない状況じゃどうしようもないので終わりにする。ここはロジックもっとスマートにしたいね
        return;
    }
    
    // 一旦すべての表示項目を表示OFFにする（性別は除外）
    [Area art_updateAllEntityDisplayFlag:NO];
    [Prefecture art_updateAllEntityDisplayFlag:NO];
    [City art_updateAllEntityDisplayFlag:NO];
    [Generation art_updateAllEntityDisplayFlag:NO];
    [HobbyType art_updateAllEntityDisplayFlag:NO];
    [Hobby art_updateAllEntityDisplayFlag:NO];
    [FutureGoal art_updateAllEntityDisplayFlag:NO];
    [JobTypeCategory art_updateAllEntityDisplayFlag:NO];
    [JobType art_updateAllEntityDisplayFlag:NO];
    [JobOtherPoint art_updateAllEntityDisplayFlag:NO];
    [SalaryDayType art_updateAllEntityDisplayFlag:NO];
    [SalaryHourType art_updateAllEntityDisplayFlag:NO];
    [WorkDayType art_updateAllEntityDisplayFlag:NO];
    [School art_updateAllEntityDisplayFlag:NO];
    [TrainLine art_updateAllEntityDisplayFlag:NO];
    [TrainStation art_updateAllEntityDisplayFlag:NO];
    
    // TODO : とりあえず成功するまで永遠に繰り返すようにしてしまっている
    // ここ取れないと検索ができなくなるので致し方なし。。失敗時はキャッシュ使うとかした方がいいかもですね
    [self startAvailableSearchDataUO];
}

- (void)startAvailableSearchDataUO
{
    __weak typeof(self) weakSelf = self;
    [ARTAvailableSearchDataUO uoGetAvailableDataWithTarget:self
                                           completionBlock:^(id resultObject) {
                                               if ([resultObject isKindOfClass:[NSError class]]) {
                                                   NSError *error = (NSError *)resultObject;
                                                   LOG(@"startAvailableSearchDataUO error %@", error);
                                                   [weakSelf scheduleTaskWithSelector:@selector(startAvailableSearchDataUO)];
                                                   return;
                                               }
                                               LOG(@"startAvailableSearchDataUO finish");
                                           }];
}

@end
