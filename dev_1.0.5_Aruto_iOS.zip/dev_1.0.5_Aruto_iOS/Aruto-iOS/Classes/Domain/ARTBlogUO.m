//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTBlogUO.h"

@implementation ARTBlogUO

+ (void)uoGetSpecialEditionWithTarget:(id)target
                      completionBlock:(ARTCompletionBlock)completionBlock
{

    __weak typeof(self) weakSelf = self;
    
    [self uoBaseWithTarget:target
                 urlString:[ARTBaseURL stringByAppendingString:@"blog/list.json"]
                httpFormat:@"GET"
                parameters:nil
              successBlock: ^(id resultObject) {
                  LOG(@"successBlock :%@", resultObject);
                  NSDictionary *resultDict = (NSDictionary *)resultObject;
                  dispatch_group_t disGroup = dispatch_group_create();
                  NSError *error = nil;
                  BOOL canNextCall = YES;
                  
                  NSArray *array = resultDict[@"Blogs"];

                  if (array && array.count > 0) {
                      [weakSelf setEntityForResultArray:resultDict[@"Blogs"]
                                     managedObjectClass:[Entry class]
                                                keyName:@"Blog"
                                                  group:disGroup groupError:&error];
                  } else {
                      canNextCall = NO;
                  }
                  
                  dispatch_group_wait(disGroup, DISPATCH_TIME_FOREVER);
                  dispatch_async(dispatch_get_main_queue(), ^{
                      if (error) {
                          art_SafeBlockCall(completionBlock, error);
                      } else {
                          art_SafeBlockCall(completionBlock, @(canNextCall));
                      }
                  });
              } failureBlock: ^(NSError *error) {
                  LOG(@"failureBlock :%@", error.description);
                  art_SafeBlockCall(completionBlock, error);
              }
     ];
     
    
}



@end