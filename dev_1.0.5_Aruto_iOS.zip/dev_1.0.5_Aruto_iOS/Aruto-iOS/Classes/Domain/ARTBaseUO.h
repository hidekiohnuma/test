//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

@interface ARTBaseUO : NSObject

+ (void)uoBaseWithTarget:(id)target
               urlString:(NSString *)urlString
              httpFormat:(NSString *)httpFormat
              parameters:(id)parameters
            successBlock:(ARTSuccessBlock)successBlock
            failureBlock:(ARTFailureBlock)failureBlock;

+ (void)setEntityForResultArray:(NSArray *)array
             managedObjectClass:(Class)managedObjectClass
                        keyName:(NSString *)keyName
                completionBlock:(ARTCompletionBlock)completionBlock;

+ (void)setEntityForResultArray:(NSArray *)array
             managedObjectClass:(Class)managedObjectClass
                        keyName:(NSString *)keyName
                          group:(dispatch_group_t)group
                     groupError:(NSError **)groupError;

+ (void)setSingleEntityForResultDict:(NSDictionary *)dict
                  managedObjectClass:(Class)managedObjectClass
                             keyName:(NSString *)keyName
                               group:(dispatch_group_t)group
                          groupError:(NSError **)groupError;

+ (void)setSingleEntityForResultDict:(NSDictionary *)dict
                  managedObjectClass:(Class)managedObjectClass
                             keyName:(NSString *)keyName
                     completionBlock:(ARTCompletionBlock)completionBlock;

@end
