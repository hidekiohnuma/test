//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSearchDataUpdateTask.h"
#import "ARTInitialDataUO.h"

#define kARTSearchDataUpdateTaskMaxRetryCount 15

@interface ARTSearchDataUpdateTask ()

@property (nonatomic, copy) ARTSuccessBlock successBlock;
@property (nonatomic, copy) ARTFailureBlock failureBlock;

@property (nonatomic, assign) BOOL      isDataLoading;
@property (nonatomic, assign) NSInteger retryCount;

@end

@implementation ARTSearchDataUpdateTask

- (void)startWithSuccessBlock:(ARTSuccessBlock)successBlock
                 failureBlock:(ARTFailureBlock)failureBlock
{
    self.successBlock = successBlock;
    self.failureBlock = failureBlock;
    self.retryCount   = 0;
    
    [self uoAction];
}

- (void)scheduleUOAction
{
    LOG_METHOD;
    
    __weak typeof(self) weakSelf = self;
    
    if (self.retryCount >= kARTSearchDataUpdateTaskMaxRetryCount) {
        dispatch_async(dispatch_get_main_queue(), ^{
            art_SafeBlockCall(weakSelf.failureBlock, nil);
        });
        return;
    }
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)), art_main_queue, ^{
        if (weakSelf.isDataLoading) { return; }
        [weakSelf uoAction];
    });
}

- (void)uoAction
{
    self.isDataLoading = YES;
    NSString *lastUpdate = [ARTUserDefaults shared].initialDataLastUpdateTimestamp;
    if (!lastUpdate) {
        lastUpdate = @"";
    }
    __weak typeof(self) weakSelf = self;
    
    [ARTInitialDataUO uoGetInitialDataWithTarget:self
                                      updateDate:lastUpdate
                                    successBlock:^(id resultObject) {
                                        dispatch_async(dispatch_get_main_queue(), ^{
                                            [ARTUserDefaults shared].initialDataLastUpdateTimestamp = (NSString *)resultObject;
                                            art_SafeBlockCall(weakSelf.successBlock, nil);
                                        });
                                    }
     
                                    failureBlock:^(NSError *error) {
                                        weakSelf.retryCount++;
                                        weakSelf.isDataLoading = NO;
                                        [weakSelf scheduleUOAction];
                                    }];
}

@end
