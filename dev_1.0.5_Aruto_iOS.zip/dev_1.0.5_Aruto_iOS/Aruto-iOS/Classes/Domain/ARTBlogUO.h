//  Copyright (c) 2015年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import "ARTBaseUO.h"

@interface ARTBlogUO : ARTBaseUO

+ (void)uoGetSpecialEditionWithTarget:(id)target
             completionBlock:(ARTCompletionBlock)completionBlock;

@end
