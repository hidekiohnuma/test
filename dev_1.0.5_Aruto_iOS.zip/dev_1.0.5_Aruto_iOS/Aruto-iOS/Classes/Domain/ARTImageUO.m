//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTImageUO.h"
#import <AFNetworking.h>

@implementation ARTImageUO

+ (void)requestThumbnailWithTarget:(id)target
                          imageURL:(NSURL *)imageURL
                      successBlock:(ARTImageCacheSuccessBlock)successBlock
                      failureBlock:(ARTImageCacheFailureBlock)failureBlock
{
    UIImage *cachedImage = [ARTImageCashe hasCacheThumbnailImageWIthURL:imageURL];
    if (cachedImage) {
        art_SafeBlockCall(successBlock, cachedImage, imageURL.absoluteString);
        return;
    }

    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    manager.responseSerializer = [AFImageResponseSerializer serializer];

    __weak typeof(target) weakTarget = target;

    [manager GET:imageURL.absoluteString
      parameters:nil
         success: ^(NSURLSessionDataTask *task, id responseObject) {
         if (!weakTarget) { return; }

         UIImage *image = (UIImage *)responseObject;
         dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                 [ARTImageCashe addThumbnailImageWithImage:image imageURL:imageURL];
             });
         art_SafeBlockCall(successBlock, image, imageURL.absoluteString);
     } failure: ^(NSURLSessionDataTask *task, NSError *error) {
         if (!weakTarget) { return; }
         art_SafeBlockCall(failureBlock, error);
     }];
}

@end
