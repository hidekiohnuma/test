//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#define ART_BaseColor_White    art_UIColorWithRGBA(255, 253, 250, 1)
#define ART_BaseColor_OffWhite art_UIColorWithRGBA(255, 246, 233, 1)
#define ART_BaseColor_Orange   art_UIColorWithRGBA(243, 152, 0, 1)
#define ART_BaseColor_Brown    art_UIColorWithRGBA(93, 58, 0, 1)

UIKIT_EXTERN NSString *const ARTControllerNameMyPage;
UIKIT_EXTERN NSString *const ARTControllerNameMail;
UIKIT_EXTERN NSString *const ARTControllerNameSearch;
UIKIT_EXTERN NSString *const ARTControllerNameSearchResult;
UIKIT_EXTERN NSString *const ARTControllerNameFavorite;
UIKIT_EXTERN NSString *const ARTControllerNameRanking;
UIKIT_EXTERN NSString *const ARTControllerNameEntry;
UIKIT_EXTERN NSString *const ARTControllerNameEntryFinish;
UIKIT_EXTERN NSString *const ARTControllerNameEntryList;
UIKIT_EXTERN NSString *const ARTControllerNameSetting;
UIKIT_EXTERN NSString *const ARTControllerNameSettingNotis;
UIKIT_EXTERN NSString *const ARTControllerNameSettingHelp;
UIKIT_EXTERN NSString *const ARTControllerNameSettingQuestion;
UIKIT_EXTERN NSString *const ARTControllerNameSettingPrivacyPolicy;
UIKIT_EXTERN NSString *const ARTControllerNameSettingUserAgreement;
UIKIT_EXTERN NSString *const ARTControllerNameLogin;
UIKIT_EXTERN NSString *const ARTControllerNameBanner;
UIKIT_EXTERN NSString *const ARTControllerNameSpecialEdition;
UIKIT_EXTERN NSString *const ARTControllerNamePrefectureArea;
UIKIT_EXTERN NSString *const ARTControllerNameGallery;
UIKIT_EXTERN NSString *const ARTNofiricationLogined;
UIKIT_EXTERN NSString *const ARTNofiricationLogouted;
UIKIT_EXTERN NSString *const ARTNofiricationFavoriteStaffChenged;
UIKIT_EXTERN NSString *const ARTNofiricationFavoriteShopChenged;
UIKIT_EXTERN NSString *const ARTNofiricationSearchItemChenged;
UIKIT_EXTERN NSString *const ARTNofiricationSearched;

UIKIT_EXTERN NSString *const ARTUserAgreement;
UIKIT_EXTERN NSString *const ARTPrivacyPolicy;

typedef NS_ENUM (NSUInteger, ARTErrorType) {
    ARTErrorTypeUONotReachable = 1,
    ARTErrorTypeUOParametorError,
    ARTErrorTypeUOUserCreate,
    ARTErrorTypeUOLogin,
    ARTErrorTypeUOChangeNotis,
    ARTErrorTypeNeedLogin
};

typedef NS_ENUM (NSUInteger, ARTSearchGroup) {
    ARTSearchGroupSelectOptionType = 1,
    ARTSearchGroupAge,
    ARTSearchGroupSex,
    ARTSearchGroupBirthPlace,
    ARTSearchGroupHobby,
    ARTSearchGroupFutureGoal,
    ARTSearchGroupSchool,
    ARTSearchGroupWorkPlace,
    ARTSearchGroupTrain,
    ARTSearchGroupSalaryHour,
    ARTSearchGroupJobType,
    ARTSearchGroupWorkDayType,
    ARTSearchGroupJobOtherOption
};

typedef NS_ENUM (NSUInteger, ARTSearchType) {
    ARTSearchTypeSelectOptionType = 1,
    ARTSearchTypeBirthPlaceArea,
    ARTSearchTypeBirthPlacePrefecture,
    ARTSearchTypeWorkPlaceArea,
    ARTSearchTypeWorkPlacePrefecture,
    ARTSearchTypeWorkPlaceCity,
    ARTSearchTypeTrainLine,
    ARTSearchTypeTrainStation,
    ARTSearchTypeJobTypeCategory,
    ARTSearchTypeJobType,
    ARTSearchTypeJobOtherOption,
    ARTSearchTypeAge,
    ARTSearchTypeSex,
    ARTSearchTypeHobbyType,
    ARTSearchTypeHobby,
    ARTSearchTypeFutureGoal,
    ARTSearchTypeSalaryHourType,
    ARTSearchTypeSalaryDayType,
    ARTSearchTypeWorkDayType,
    ARTSearchTypeSchoolType,
    ARTSearchTypeSchool
};

typedef NS_ENUM (NSUInteger, ARTRankListType) {
    ARTRankListTypeAccess = 1,
    ARTRankListTypeAruto,
    ARTRankListTypeMale,
    ARTRankListTypeFemale,
    ARTRankListTypePickup
};

typedef NS_ENUM (NSUInteger, ARTBlogListType) {
    ARTBlogList = 1,
    ARTBlogList2,
    ARTBlogList3,
    ARTBlogList4,
    ARTBlogList5
};


typedef NS_ENUM (NSUInteger, ARTWatchListType) {
    ARTWatchListTypeStaff = 1,
    ARTWatchListTypeShop
};

typedef NS_ENUM (NSUInteger, ARTSexType) {
    ARTSexTypeMale = 1,
    ARTSexTypeFemale
};

typedef NS_ENUM (NSInteger, ARTLoadingViewState) {
    ARTLoadingViewStateWait = 0,
    ARTLoadingViewStateLoading,
    ARTLoadingViewStateRefreshing,
    ARTLoadingViewStateFinishLoading,
    ARTLoadingViewStateNothing
};

typedef void (^ARTVoidBlock)();
typedef void (^ARTSuccessBlock)(id resultObject);
typedef void (^ARTFailureBlock)(NSError *error);
typedef void (^ARTCompletionBlock)(id resultObject);

#ifdef DEBUG
// 開発
    // (yos Local)
    //#define ARTBaseURL @"http://dev.mirkoborivojevic.localhost/aruto/api/"
    //#define ARTBaseURL @"https://www.aruto.me/api/"
    //#define ARTBaseURL @"http://sv2.aruto.me/api/"
    #define ARTBaseURL @"http://www-stg.aruto.me/api/"
    //#define ARTBaseURL @"http://www-dev.aruto.me/api/"
#endif

#ifdef STAGE
// 検証
    #define ARTBaseURL @"http://www-dev.aruto.me/api/"
    //#define ARTBaseURL @"http://www-stg.aruto.me/api/"
    //#define ARTBaseURL @"https://www.aruto.me/api/"
#endif

#ifdef RELEASE
// 本番
    #define ARTBaseURL @"https://www.aruto.me/api/"
#endif

#define ARTErrorDomain @"com.aruto.errordomain"

#define ART_UO_Index_Interval 10

#define ARTFacebookCutsomURLScheme             @"fb261467434039492"
#define ARTFacebookCutsomURLSchemeNotification @"ARTFacebookCutsomURLSchemeNotification"
