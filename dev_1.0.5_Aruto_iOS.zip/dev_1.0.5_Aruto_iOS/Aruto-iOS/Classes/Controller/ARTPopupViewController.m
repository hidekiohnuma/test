//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTPopupViewController.h"

#import "ARTPresentingAnimator.h"
#import "ARTDismissingAnimator.h"

@interface ARTPopupViewController ()

@end

@implementation ARTPopupViewController

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.contentsView.layer.cornerRadius = 5.f;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - UIViewControllerAnimatedTransitioning Protocol

- (id <UIViewControllerAnimatedTransitioning> )animationControllerForPresentedController:(UIViewController *)presented
                                                                    presentingController:(UIViewController *)presenting
                                                                        sourceController:(UIViewController *)source
{
    return [ARTPresentingAnimator new];
}

- (id <UIViewControllerAnimatedTransitioning> )animationControllerForDismissedController:(UIViewController *)dismissed
{
    return [ARTDismissingAnimator new];
}

@end
