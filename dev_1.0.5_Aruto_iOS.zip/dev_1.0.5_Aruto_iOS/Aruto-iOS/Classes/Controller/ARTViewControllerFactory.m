//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTViewControllerFactory.h"

#import "ARTPopupViewController.h"
#import "ARTMessageViewController.h"

#import "ARTRankingSelectView.h"
#import "ARTRankingListView.h"
#import "ARTMyPageView.h"
#import "ARTFavoriteView.h"

#import "ARTSearchRootView.h"
#import "ARTSearchMainView.h"
#import "ARTSearchResultView.h"

#import "ARTStaffDetailView.h"
#import "ARTStoreDetailView.h"
#import "ARTJobDetailView.h"

#import "ARTEntryView.h"
#import "ARTEntryFinishView.h"
#import "ARTEntryListView.h"

#import "ARTUserAuthView.h"
#import "ARTWelcomeView.h"
#import "ARTLoadingView.h"

#import "ARTSettingView.h"
#import "ARTNotisSettingView.h"
#import "ARTSettingHelpView.h"
#import "ARTSettingTextView.h"

#import "ARTBannerView.h"
#import "ARTSpecialEditionView.h"
#import "ARTSpecialEditionDetailView.h"

#import "ARTPrefectureAreaView.h"
#import "ARTPrefectureAreaChangeView.h"
#import "ARTGalleryView.h"

@implementation ARTViewControllerFactory


// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - ARTBaseViewController Factory

+ (ARTBaseViewController *)baseViewControllerForShowTab:(BOOL)isShowTabView
                                       viewDidLoadBlock:(ARTViewDidLoadBlock)viewDidLoadBlock
{
    ARTBaseViewController *controller = [[ARTBaseViewController alloc] initWithNib];
    controller.viewDidLoadBlock = viewDidLoadBlock;
    controller.isShowTabView    = isShowTabView;

    return controller;
}

+ (ARTBaseViewController *)baseViewControllerWithTitle:(NSString *)headerTitle
                                         isShowTabView:(BOOL)isShowTabView
                                     contentsViewClass:(Class)contentsViewClass
                                              needBack:(BOOL)needBack
{
    return [self baseViewControllerForShowTab:isShowTabView
                             viewDidLoadBlock: ^(ARTBaseViewController *controller){
                                 [controller setHeaderTitle:headerTitle numberOfLines:1];
                                 ARTBaseContentsView *view = [contentsViewClass art_createViewByNib];
                                 [view sendViewName:headerTitle];
                                 view.parentController = controller;
                                 [controller addContentsView:view];
                                 
                                 if([view isMemberOfClass:[ARTMyPageView class]] || [view isMemberOfClass:[ARTNotisSettingView class]] || [view isMemberOfClass:[ARTSettingHelpView class]] || [view isMemberOfClass:[ARTSettingView class]] || [view isMemberOfClass:[ARTPrefectureAreaChangeView class]]){
                                     //サーチボタンを表示しないので何もしない
                                 }
                                 else {
                                     //サーチボタンを出す
                                     //set serch button
                                     [controller setRightSearchButtonWithblock: ^{
                                         [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupSelectOptionType];
                                     }];
                                 }
                                 if ([view isMemberOfClass:[ARTSearchMainView class]] ) {
                                     [(ARTSearchMainView*)view setSearchType:ARTSearchTypeSelectOptionType];
                                 }
                                 if (needBack) {
                                     [controller setLeftBackButtonImageWithblock: ^{
                                         [[ARTViewContainer shared] popActiveNavController];
                                     }];
                                 }
                             }];
}

// add prefacture area
+ (ARTBaseViewController *)baseViewControllerWithTitle:(NSString *)headerTitle
                                         isShowTabView:(BOOL)isShowTabView
                       contentsViewClass:(Class)contentsViewClass
{
    return [self baseViewControllerForShowTab:isShowTabView
                             viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                                 [controller setHeaderTitle:headerTitle numberOfLines:1];
                                 ARTBaseContentsView *view = [contentsViewClass art_createViewByNib];
                                 [view sendViewName:headerTitle];
                                 view.parentController = controller;
                                 [controller addContentsView:view];
                             }
            ];
    
}
+ (ARTBaseViewController *)baseViewControllerWithTitle:(NSString *)headerTitle
                                         isShowTabView:(BOOL)isShowTabView
                                     contentsViewClass:(Class)contentsViewClass
                                              needBack:(BOOL)needBack
                                          selectedItem:(NSString *)selectedItem
{
    return [self baseViewControllerForShowTab:isShowTabView
                             viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                                 [controller setHeaderTitle:headerTitle numberOfLines:1];
                                 ARTBaseContentsView *view = [contentsViewClass art_createViewByNib];
                                 [view sendViewName:headerTitle];
                                 view.parentController = controller;
                                 [controller addContentsView:view];
                                 
                                 /*
                                 //サーチボタンを出すかどうか？
                                 //set serch button
                                 [controller setRightSearchButtonWithblock: ^{
                                     [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupSelectOptionType];
                                 }];
                                 */
                                 if ([view isMemberOfClass:[ARTSearchMainView class]] ) {
                                     [(ARTSearchMainView*)view setSearchType:ARTSearchTypeSelectOptionType];
                                 }
                                 if (needBack) {
                                     [controller setLeftBackButtonImageWithblock: ^{
                                         [[ARTViewContainer shared] popActiveNavController];
                                     }];
                                 }
                                 if(selectedItem){
                                     [self selecetedItemValue:selectedItem];
                                 }
                             }];
}

+ (ARTBaseViewController *)searchRootController
{
    // 勤務地設定追加
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSString *prefectureAreaId = [ud stringForKey:@"prefectureAreaId"];
    
    if(prefectureAreaId == nil){
        return [self prefectureAreaView];
    }else{
        return [self baseViewControllerWithTitle:ARTControllerNameSearch
                                   isShowTabView:YES
                               contentsViewClass:[ARTSearchRootView class]
                                        needBack:NO];
    }
    
    
    /*
    return [self baseViewControllerWithTitle:ARTControllerNameSearch
                               isShowTabView:YES
                           contentsViewClass:[ARTSearchMainView class]
                                    needBack:NO];
    */
}

+ (ARTBaseViewController *)searchControllerWithType:(ARTSearchType)type isModal:(BOOL)isModal needBack:(BOOL)needBack
{
    return [self baseViewControllerForShowTab:NO
                             viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                [controller setHeaderTitle:[[ARTSearchManager shared] headerTitleWithType:type] numberOfLines:2];
                ARTSearchMainView *view = [ARTSearchMainView art_createViewByNib];
                [view sendViewName:[[ARTSearchManager shared] headerTitleWithType:type]];
                view.parentController = controller;
                [view setSearchType:type];
                [controller addContentsView:view];

                if (isModal) {
                    [controller setRightCloseButtonWithblock: ^{
                         [[ARTViewContainer shared] closeModalViewWithAnimationBlock: ^(id container) {
                          } completionBlock: ^(id container) {
                              [ARTSearchManager shared].isModal = NO;
                          }];
                     }];
                    if (needBack) {
                        [controller setLeftBackButtonImageWithblock: ^{
                             [[ARTViewContainer shared] popActiveModalNavController];
                         }];
                    }
                } else {
                    if (needBack) {
                        
                        [controller setLeftBackButtonImageWithblock: ^{
                             [[ARTViewContainer shared] popActiveNavController];
                         }];
                        
                    }
                    //「絞り込み」「閉じる」のナビゲーションバーを表示させている部分（切り替え）
                    /*
                    [controller setRightSearchOptionButtonWithblock: ^{
                         [[ARTSearchManager shared] presentSearchOptionViewController];
                     }];
                    */
                }
            }];
}

+ (ARTBaseViewController *)rankingSelectViewControllerWithNeedBack:(BOOL)needBack
{
    return [self baseViewControllerWithTitle:ARTControllerNameRanking
                               isShowTabView:YES
                           contentsViewClass:[ARTRankingSelectView class]
                                    needBack:needBack];
}

+ (ARTBaseViewController *)rankingListViewControllerWithType:(ARTRankListType)type
{
    NSString *headerTitle;
    if (type == ARTRankListTypePickup) {
        headerTitle = @"ピックアップ";
    } else if (type == ARTRankListTypeAccess) {
        headerTitle = @"アクセスランキング";
    } else if (type == ARTRankListTypeAruto) {
        headerTitle = @"Aruto推薦ランキング";
    } else if (type == ARTRankListTypeMale) {
        headerTitle = @"人気男子ランキング";
    } else if (type == ARTRankListTypeFemale) {
        headerTitle = @"人気女子ランキング";
    }

    return [self baseViewControllerForShowTab:YES
                             viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                [controller setHeaderTitle:headerTitle numberOfLines:1];
                ARTRankingListView *view = [ARTRankingListView art_createViewByNib];
                [view sendViewName:headerTitle];
                view.parentController = controller;
                [view setRankType:type];
                [controller addContentsView:view];
                [view setContentsScrollView];
                
                //set serch button
                [controller setRightSearchButtonWithblock: ^{
                    [[ARTSearchManager shared] pushControllerWithSearchGroup:ARTSearchGroupSelectOptionType];
                }];
                
                [controller setLeftBackButtonImageWithblock: ^{
                     [[ARTViewContainer shared] popActiveNavController];
                 }];
            }];
}

// Mypage
+ (ARTBaseViewController *)myPageViewController
{
        return [self baseViewControllerWithTitle:ARTControllerNameMyPage
                                   isShowTabView:YES
                               contentsViewClass:[ARTMyPageView class]
                                        needBack:NO];
}

// Favorite
+ (ARTBaseViewController *)favoriteViewControllerWithNeedBack:(BOOL)needBack
{
    if (needBack) {
        return [self baseViewControllerForShowTab:YES
                                 viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                    [controller setHeaderTitle:ARTControllerNameFavorite numberOfLines:1];
                    ARTFavoriteView *view = [ARTFavoriteView art_createViewByNib];
                    [view sendViewName:ARTControllerNameFavorite];
                    view.parentController = controller;
                    [controller addContentsView:view];
                    [view setContentsScrollView];
                    [controller setLeftBackButtonImageWithblock: ^{
                         [[ARTViewContainer shared] popActiveNavController];
                     }];
                }];
    } else {
        return [self baseViewControllerForShowTab:YES
                                 viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                    [controller setHeaderTitle:ARTControllerNameFavorite numberOfLines:1];
                    ARTFavoriteView *view = [ARTFavoriteView art_createViewByNib];
                    [view sendViewName:ARTControllerNameFavorite];
                    view.parentController = controller;
                    [controller addContentsView:view];
                    [view setContentsScrollView];
                }];
    }
}

// Search Result
+ (ARTBaseViewController *)searchResultViewController
{
    return [self baseViewControllerForShowTab:YES
                             viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                [controller setHeaderTitle:ARTControllerNameSearchResult numberOfLines:1];
                ARTSearchResultView *view = [ARTSearchResultView art_createViewByNib];
                [view sendViewName:ARTControllerNameSearchResult];
                view.parentController = controller;
                [view setting];
                [controller addContentsView:view];
                [view setContentsScrollView];
                [controller setLeftBackButtonImageWithblock: ^{
                     [ARTSearchManager shared].isSearched = NO;
                     [[ARTViewContainer shared] popActiveNavController];
                 }];
                                 /*検索結果ページで右上表示の「絞り込み」「閉じる」を非表示
                                //※ここに「ひと検索」「お店検索」のセグメントコントローラーを入れる
                [controller setRightSearchOptionButtonWithblock: ^{
                     [[ARTSearchManager shared] presentSearchOptionViewController];
                 }];
                                 */
                                 //[controller setRightSearchOptionSegmentControlWithblock: ^{
                                     /*
                                     //セグメントコントローラー追加
                                     NSArray *items = [NSArray arrayWithObjects:@"人", @"店", nil];
                                     UISegmentedControl *segment = [[UISegmentedControl alloc]initWithItems:items];
                                     segment.frame = CGRectMake(0,0,40,40);
                                     segment.selectedSegmentIndex = 1;
                                     */
                                     //[[ARTSearchManager shared] presentSearchOptionViewController];
                                 //}];
            }];
}

// Detail
+ (ARTBaseViewController *)staffDetailViewControllerWithStaffId:(NSNumber *)staffId
{
    Staff *staffData = [Staff art_staffWithStaffId:staffId localContext:nil];

    NSString *headerTitle;
    if (staffData.name) {
        headerTitle = [NSString stringWithFormat:@"%@ さん", staffData.name];
    } else {
        headerTitle = @"スタッフ詳細";
    }

    return [self baseViewControllerForShowTab:NO
                             viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                [controller setHeaderTitle:headerTitle numberOfLines:1];
                ARTStaffDetailView *view = [ARTStaffDetailView art_createViewByNib];
                [view sendViewName:[NSString stringWithFormat:@"スタッフ詳細 - %@ StaffID : %@", headerTitle, staffId]];
                view.parentController = controller;
                [view setStaffId:staffId];
                [controller addContentsView:view];
                [controller setLeftBackButtonImageWithblock: ^{
                     [[ARTViewContainer shared] popActiveNavController];
                 }];
            }];
}

+ (ARTBaseViewController *)storeDetailViewControllerWithShopId:(NSNumber *)shopId
{
    Shop *shopData = [Shop art_shopWithShopId:shopId localContext:nil];

    NSString *headerTitle;
    if (shopData.name && shopData.branchName.length) {
        headerTitle = [NSString stringWithFormat:@"%@\n%@", shopData.name, shopData.branchName];
    } else if (shopData.name) {
        headerTitle = [NSString stringWithFormat:@"%@", shopData.name];
    } else {
        headerTitle = @"店舗詳細";
    }

    return [self baseViewControllerForShowTab:NO
                             viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                [controller setHeaderTitle:headerTitle numberOfLines:3];
                ARTStoreDetailView *view = [ARTStoreDetailView art_createViewByNib];
                [view sendViewName:[NSString stringWithFormat:@"店舗詳細 - %@ ShopID : %@", headerTitle, shopId]];
                view.parentController = controller;
                [view setShopId:shopId];
                [controller addContentsView:view];
                [controller setLeftBackButtonImageWithblock: ^{
                     [[ARTViewContainer shared] popActiveNavController];
                 }];
            }];
}

+ (ARTBaseViewController *)jobDetailViewControllerWithJobId:(NSNumber *)jobId showEntryButton:(BOOL)showEntryButton
{
    Job *jobData = [Job art_jobWithJobId:jobId localContext:nil];

    NSString *headerTitle;
    if (jobData.jobTypeId) {
        headerTitle = [JobType art_nameForId:jobData.jobTypeId];
    } else {
        headerTitle = @"求人詳細";
    }

    return [self baseViewControllerForShowTab:NO
                             viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                [controller setHeaderTitle:headerTitle numberOfLines:2];
                ARTJobDetailView *view = [ARTJobDetailView art_createViewByNib];
                [view sendViewName:[NSString stringWithFormat:@"求人詳細 - %@ JobID : %@", headerTitle, jobId]];
                view.parentController = controller;
                [view entryButtonIsShow:showEntryButton];
                [view setJobId:jobId];
                [controller addContentsView:view];
                [controller setLeftBackButtonImageWithblock: ^{
                     [[ARTViewContainer shared] popActiveNavController];
                 }];
            }];
}

// Entry
+ (ARTBaseViewController *)entryViewControllerWithShopId:(NSNumber *)shopId;
{
    return [self baseViewControllerForShowTab:NO
                             viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                [controller setHeaderTitle:ARTControllerNameEntry numberOfLines:1];
                ARTEntryView *view = [ARTEntryView art_createViewByNib];
                [view sendViewName:ARTControllerNameEntry];
                view.parentController = controller;
                [view setShopId:shopId];
                [controller addContentsView:view];
                [controller setLeftBackButtonImageWithblock: ^{
                     [[ARTViewContainer shared] popActiveNavController];
                 }];
            }];
}

+ (ARTBaseViewController *)entryFinishViewController
{
    return [self baseViewControllerWithTitle:ARTControllerNameEntryFinish
                               isShowTabView:NO
                           contentsViewClass:[ARTEntryFinishView class]
                                    needBack:NO];
}

+ (ARTBaseViewController *)entryListViewControllerWithNeedBack:(BOOL)needBack
{
    return [self baseViewControllerForShowTab:YES
                             viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                [controller setHeaderTitle:ARTControllerNameEntryList numberOfLines:1];
                ARTEntryListView *view = [ARTEntryListView art_createViewByNib];
                [view sendViewName:ARTControllerNameEntryList];
                view.parentController = controller;
                [controller addContentsView:view];
                [view setContentsScrollView];
                if (needBack) {
                    [controller setLeftBackButtonImageWithblock: ^{
                         [[ARTViewContainer shared] popActiveNavController];
                     }];
                }
            }];
}
// SpecialEdition
+ (ARTBaseViewController *)specialEditionView
{
    // 勤務地設定追加
    NSUserDefaults *ud = [NSUserDefaults standardUserDefaults];
    NSString *prefectureAreaId = [ud stringForKey:@"prefectureAreaId"];
    
    if(prefectureAreaId == nil){
        return [self prefectureAreaView];
    }else{
        return [self baseViewControllerWithTitle:ARTControllerNameSpecialEdition
                                   isShowTabView:YES
                               contentsViewClass:[ARTSpecialEditionView class]
                                        needBack:NO];
    }
}

// SpecialEditionDetail
+ (ARTBaseViewController *)specialEditionDetailView:(NSString *)selecetedItemValue
{
    return [self baseViewControllerForShowTab:NO
                      viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                          [controller setHeaderTitle:ARTControllerNameSpecialEdition numberOfLines:1];
                          ARTSpecialEditionDetailView *view = [ARTSpecialEditionDetailView art_createViewByNib];
                          [view sendViewName:ARTControllerNameSpecialEdition];
                          view.parentController = controller;
                          [view setBlogSelectedItem:selecetedItemValue];// add setBlogSelectedItem
                          [controller addContentsView:view];
                          [controller setLeftBackButtonImageWithblock: ^{
                              [[ARTViewContainer shared] popActiveNavController];
                          }];
                      }];
}

// PrefecureArea
+ (ARTBaseViewController *)prefectureAreaView
{
    return [self baseViewControllerForShowTab:NO
                             viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                                 controller.isHiddenHeaderImage = YES;
                                 ARTPrefectureAreaView *view = [ARTPrefectureAreaView art_createViewByNib];
                                 [controller addContentsView:view];
                             }
            ];
}

//prefectureAreaChangeView
+ (ARTBaseViewController *)prefectureAreaChangeView
{
    return [self baseViewControllerWithTitle:ARTControllerNamePrefectureArea
                               isShowTabView:NO
                           contentsViewClass:[ARTPrefectureAreaChangeView class]
                                    needBack:NO];
}


// Gallery
+ (ARTBaseViewController *)galleryView
{
    return [self baseViewControllerWithTitle:ARTControllerNameGallery
                               isShowTabView:YES
                           contentsViewClass:[ARTGalleryView class]
                                    needBack:NO];
}

// Setting
+ (ARTBaseViewController *)settingViewController
{
    return [self baseViewControllerWithTitle:ARTControllerNameSetting
                               isShowTabView:YES
                           contentsViewClass:[ARTSettingView class]
                                    needBack:NO];
}

+ (ARTBaseViewController *)settingNotisViewController
{
    return [self baseViewControllerWithTitle:ARTControllerNameSettingNotis
                               isShowTabView:NO
                           contentsViewClass:[ARTNotisSettingView class]
                                    needBack:YES];
}

+ (ARTBaseViewController *)settingHelpViewController
{
    return [self baseViewControllerWithTitle:ARTControllerNameSettingHelp
                               isShowTabView:NO
                           contentsViewClass:[ARTSettingHelpView class]
                                    needBack:YES];
}

+ (ARTBaseViewController *)settingPrivacyPolicyViewController
{
    return [self baseViewControllerForShowTab:NO
                             viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                [controller setHeaderTitle:ARTControllerNameSettingPrivacyPolicy numberOfLines:1];
                ARTSettingTextView *view = [ARTSettingTextView art_createViewByNib];
                [view sendViewName:ARTControllerNameSettingPrivacyPolicy];
                view.parentController = controller;
                [view setText:ARTPrivacyPolicy];
                [controller addContentsView:view];
                [controller setLeftBackButtonImageWithblock: ^{
                     [[ARTViewContainer shared] popActiveNavController];
                 }];
            }];
}

+ (ARTBaseViewController *)settingUserAgreementViewController
{
    return [self baseViewControllerForShowTab:NO
                             viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                [controller setHeaderTitle:ARTControllerNameSettingUserAgreement numberOfLines:1];
                ARTSettingTextView *view = [ARTSettingTextView art_createViewByNib];
                [view sendViewName:ARTControllerNameSettingUserAgreement];
                view.parentController = controller;
                [view setText:ARTUserAgreement];
                [controller addContentsView:view];
                [controller setLeftBackButtonImageWithblock: ^{
                     [[ARTViewContainer shared] popActiveNavController];
                 }];
            }];
}

+ (ARTBaseViewController *)settingViewControllerWithNeedBack:(BOOL)needBack
{
    return [self baseViewControllerWithTitle:ARTControllerNameSetting
                               isShowTabView:YES
                           contentsViewClass:[ARTSettingView class]
                                    needBack:YES];
}

// Banner
+ (ARTBaseViewController *)bannerViewController
{
    return [self baseViewControllerForShowTab:NO
                             viewDidLoadBlock: ^(ARTBaseViewController *controller) {
                controller.isModalController = YES;
                [controller setHeaderTitle:ARTControllerNameBanner numberOfLines:1];
                ARTBannerView *view = [ARTBannerView art_createViewByNib];
                [view sendViewName:ARTControllerNameBanner];
                view.parentController = controller;
                [controller addContentsView:view];
                [controller setRightButtonImageWithBlock: ^(UIButton *button) {
                     [button setTitle:@"閉じる" forState:UIControlStateNormal];
                     [button setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
                 } block: ^{
                     [[ARTViewContainer shared] closeModalViewWithAnimationBlock: ^(id container) {
                      } completionBlock: ^(id container) {
                      }];
                 }];
            }];
}

// User Auth
+ (UIViewController *)userAuthViewController
{
    ARTPopupViewController *controller = [[ARTPopupViewController alloc] initWithNib];
    controller.viewDidLoadBlock = ^(ARTPopupViewController *controller) {
        controller.isModalController = YES;
        ARTUserAuthView *view = [ARTUserAuthView art_createViewByNib];
        [view sendViewName:ARTControllerNameLogin];
        [controller addContentsView:view];
        view.parentController = controller;

        [view setHeaderTitle:ARTControllerNameLogin];

        [view setRightCancelButtonWithblock: ^{
             [[ARTViewContainer shared] hideUserAuthModalView];
         }];
    };
    controller.modalPresentationStyle = UIModalPresentationCustom;
    controller.transitioningDelegate  = controller;

    return controller;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - ARTFullScreenViewController Factory

+ (ARTFullScreenViewController *)fullScreenViewControllerWithViewDidLoadBlock:(ARTViewDidLoadBlock)viewDidLoadBlock
{
    ARTFullScreenViewController *controller = [[ARTFullScreenViewController alloc] initWithNib];
    controller.viewDidLoadBlock = viewDidLoadBlock;

    return controller;
}

+ (ARTFullScreenViewController *)welcomeViewController
{
    return [self fullScreenViewControllerWithViewDidLoadBlock: ^(ARTFullScreenViewController *controller) {
                controller.isModalController = YES;
                ARTWelcomeView *view = [ARTWelcomeView art_createViewByNib];
                [view sendViewName:@"Welcome"];
                view.parentController = controller;
                [controller addContentsView:view];
            }];
}

+ (ARTFullScreenViewController *)loadingViewController
{
    return [self fullScreenViewControllerWithViewDidLoadBlock: ^(ARTFullScreenViewController *controller) {
                controller.isModalController = YES;
                ARTLoadingView *view = [ARTLoadingView art_createViewByNib];
                [controller addContentsView:view];
            }];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - ARTMessageViewController Factory

+ (UIViewController *)messageViewControllerWithEntryId:(NSNumber *)entryId;
{
    [[ARTViewContainer shared] tabViewisShow:NO];
    ARTMessageViewController *controller = [ARTMessageViewController messagesViewController];
    controller.entryId = entryId;
    return controller;
}
+ (ARTBaseViewController *)selecetedItemValue:(NSString *)selecetedItemValue
{
    return selecetedItemValue;
}

@end
