//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

#import <JSQMessages.h>

#import "ARTMessageDataModel.h"

@interface ARTMessageViewController : JSQMessagesViewController

@property (nonatomic, strong) ARTMessageDataModel *messageData;

@property (nonatomic, copy) NSNumber *entryId;

@end
