//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

@interface ARTViewControllerFactory : NSObject

// Search
+ (ARTBaseViewController *)searchRootController;
+ (ARTBaseViewController *)searchControllerWithType:(ARTSearchType)type isModal:(BOOL)isModal needBack:(BOOL)needBack;

// Rank
+ (ARTBaseViewController *)rankingSelectViewControllerWithNeedBack:(BOOL)needBack;
+ (ARTBaseViewController *)rankingListViewControllerWithType:(ARTRankListType)type;

// Mypage
+ (ARTBaseViewController *)myPageViewController;

// Favorite
+ (ARTBaseViewController *)favoriteViewControllerWithNeedBack:(BOOL)needBack;

// Search Result
+ (ARTBaseViewController *)searchResultViewController;

// Detail
+ (ARTBaseViewController *)staffDetailViewControllerWithStaffId:(NSNumber *)staffId;
+ (ARTBaseViewController *)storeDetailViewControllerWithShopId:(NSNumber *)shopId;
+ (ARTBaseViewController *)jobDetailViewControllerWithJobId:(NSNumber *)jobId showEntryButton:(BOOL)showEntryButton;

// Entry
+ (ARTBaseViewController *)entryViewControllerWithShopId:(NSNumber *)shopId;
+ (ARTBaseViewController *)entryFinishViewController;
+ (ARTBaseViewController *)entryListViewControllerWithNeedBack:(BOOL)needBack;

// Setting
+ (ARTBaseViewController *)settingViewController;
+ (ARTBaseViewController *)settingNotisViewController;
+ (ARTBaseViewController *)settingHelpViewController;
+ (ARTBaseViewController *)settingPrivacyPolicyViewController;
+ (ARTBaseViewController *)settingUserAgreementViewController;
+ (ARTBaseViewController *)settingViewControllerWithNeedBack:(BOOL)needBack;

// Banner
+ (ARTBaseViewController *)bannerViewController;

// User Auth
+ (UIViewController *)userAuthViewController;

+ (ARTFullScreenViewController *)fullScreenViewControllerWithViewDidLoadBlock:(ARTViewDidLoadBlock)viewDidLoadBlock;
+ (ARTFullScreenViewController *)welcomeViewController;
+ (ARTFullScreenViewController *)loadingViewController;

// Chat Message
+ (UIViewController *)messageViewControllerWithEntryId:(NSNumber *)entryId;

// Special Edition
+ (ARTBaseViewController *)specialEditionView;
// Special Edition Result
+ (ARTBaseViewController *)specialEditionResultView:(NSString *)selecetedItemValue;
+ (ARTBaseViewController *)specialEditionDetailView:(NSString *)selecetedItemValue;
+ (ARTBaseViewController *)selecetedItemValue:(NSString *)selecetedItemValue;

// PrefectireArea
+ (ARTBaseViewController *)prefectureAreaView;
// PrefectireAreaChange
+ (ARTBaseViewController *)prefectureAreaChangeView;

// Gallery
+ (ARTBaseViewController *)galleryView;

@end
