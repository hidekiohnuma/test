//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTFullScreenViewController.h"

@interface ARTFullScreenViewController ()

@end

@implementation ARTFullScreenViewController

- (void)deallocChild
{
    LOG_METHOD;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
