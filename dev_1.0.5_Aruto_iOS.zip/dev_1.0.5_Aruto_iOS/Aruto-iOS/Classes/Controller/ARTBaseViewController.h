//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

typedef void (^ARTViewDidLoadBlock)(id controller);

@interface ARTBaseViewController : UIViewController

@property (nonatomic, weak) IBOutlet UIView *contentsView;

@property (nonatomic, copy) ARTViewDidLoadBlock viewDidLoadBlock;

@property (nonatomic, assign) BOOL        isModalController;
// add isHiddenHeaderImage
@property (nonatomic, assign) BOOL        isHiddenHeaderImage;
@property (nonatomic, assign) BOOL        isShowTabView;
@property (nonatomic, weak) UIScrollView *targetScrollView;

- (instancetype)initWithNib;
- (void)deallocChild;
- (void)addContentsView:(UIView *)view;
- (void)setHeaderImageForURL:(NSURL *)imageURL;

- (void)setHeaderTitle:(NSString *)headerTitle numberOfLines:(NSInteger)numberOfLines;

- (void)setLeftBackButtonImageWithblock:(void (^)())block;
- (void)setLeftButtonImageWithBlock:(void (^)(UIButton *button))imageBlock block:(void (^)())block;

- (void)setRightCloseButtonWithblock:(void (^)())block;
- (void)setRightSearchOptionButtonWithblock:(void (^)())block;
- (void)setRightSearchOptionSegmentControlWithblock:(void (^)())block;
- (void)setRightButtonImageWithBlock:(void (^)(UIButton *button))imageBlock block:(void (^)())block;

- (void)setRightSearchButtonWithblock:(void (^)())block;

- (void)resetHeaderView;
- (void)hiddenHeaderView;
- (void)scrollHeadeForscrollView:(UIScrollView *)scrollView;

@end
