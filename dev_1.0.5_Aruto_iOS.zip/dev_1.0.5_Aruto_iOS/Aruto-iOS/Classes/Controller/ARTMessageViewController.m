//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTMessageViewController.h"

#import "ARTMessageUO.h"

@interface ARTMessageViewController ()

@property (nonatomic, copy) NSURL *shopImageURL;
@property (nonatomic, copy) NSString *storeName;

@end

@implementation ARTMessageViewController

- (void)awakeFromNib
{
    [super awakeFromNib];
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    [ARTAnalytics sendGAScreenName:@"チャット"];
    
    self.senderId = [ARTUserManager shared].userId.stringValue;
    self.senderDisplayName = @"あなた";
    
    self.messageData = [[ARTMessageDataModel alloc] init];
    
    self.navigationController.navigationBarHidden = NO;
    self.view.backgroundColor = ART_BaseColor_OffWhite;

    // スワイプで戻るのを無効化
    if ([self.navigationController respondsToSelector:@selector(interactivePopGestureRecognizer)]) {
        self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    }
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[IonIcons imageWithIcon:ion_ios_refresh_empty
                                                                                                  iconColor:[UIColor whiteColor]
                                                                                                   iconSize:40
                                                                                                  imageSize:CGSizeMake(25, 35)]
                                                                              style:UIBarButtonItemStyleBordered
                                                                             target:self
                                                                             action:@selector(getUO)];

    Entry *entry    = [Entry art_findById:self.entryId localContext:nil];
    Job   *jobData  = [Job art_jobWithJobId:entry.jobId localContext:nil];
    Shop  *shopData = [Shop art_shopWithShopId:jobData.shopId localContext:nil];
    self.storeName = @"お店";
    if (shopData) {
        self.shopImageURL = [NSURL URLWithString:shopData.thumbnailURL];
        
        if (shopData.name && shopData.branchName) {
            self.title =  [NSString stringWithFormat:@"%@\n%@", shopData.name, shopData.branchName];
            self.storeName = [NSString stringWithFormat:@"%@ %@", shopData.name, shopData.branchName];
        } else if (shopData.name) {
            self.title =  shopData.name;
            self.storeName = shopData.name;
        } else {
            self.title = @"メッセージ";
        }
    } else {
        self.title = @"メッセージ";
    }

    self.collectionView.backgroundColor = ART_BaseColor_OffWhite;

    // 写真ボタンは非表示
    self.inputToolbar.contentView.leftBarButtonItem = nil;

    [self.inputToolbar.contentView.rightBarButtonItem setTitle:@"送信" forState:UIControlStateNormal];
    self.inputToolbar.contentView.textView.placeHolder = nil;
    
    self.inputToolbar.contentView.rightBarButtonItem.titleLabel.font = [UIFont fontWithName:@"HiraKakuProN-W6" size:19];

    [self getUO];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[ARTViewContainer shared] tabViewisShow:NO];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];

    self.navigationController.navigationBarHidden = YES;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)tapBackButton
{
    [[ARTViewContainer shared] popActiveNavController];
}

- (void)receiveMessagePressed:(UIBarButtonItem *)sender
{
    LOG_METHOD;
}

- (void)reloadData
{
    NSArray *messageArray = [EntryMessage art_allEntiteisByEntryId:self.entryId];
    
    [self.messageData.messages removeAllObjects];

    for (int i = 0; i < messageArray.count; ++i) {
        EntryMessage *entity = messageArray[i];
        JSQTextMessage *message;
        NSString *userName = @"";
        if (entity.userId.integerValue == self.senderId.integerValue) {
            userName = self.senderDisplayName;
        } else {
            userName = self.storeName;
        }
        message = [[JSQTextMessage alloc] initWithSenderId:entity.userId.stringValue
                                         senderDisplayName:userName
                                                      date:entity.created
                                                      text:entity.message];
        [self.messageData.messages addObject:message];
    }

    [self finishReceivingMessage];
}

- (void)getUO
{
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeClear];

    __weak typeof(self) weakSelf = self;

    [ARTMessageUO uoGetMessageListWithTarget:self
                                      userId:[ARTUserManager shared].userId
                                     entryId:self.entryId
                             completionBlock: ^(id resultObject) {
         [SVProgressHUD dismiss];
         if (!weakSelf) { return; }

         if ([resultObject isKindOfClass:[NSError class]]) {
             NSError *error = (NSError *)resultObject;
             [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                          message:error.localizedFailureReason
                                      buttonTitle:nil];
         } else {
             [weakSelf reloadData];
         }
     }];
}

- (void)postUOForText:(NSString *)text completionBlock:(ARTCompletionBlock)completionBlock
{
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeClear];

    __weak typeof(self) weakSelf = self;

    [ARTMessageUO uoPostMessageWithTarget:self
                                   userId:[ARTUserManager shared].userId
                                  entryId:self.entryId
                                     text:text
                          completionBlock: ^(id resultObject) {
         [SVProgressHUD dismiss];
         if (!weakSelf) { return; }

         if ([resultObject isKindOfClass:[NSError class]]) {
             NSError *error = (NSError *)resultObject;
             [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                          message:error.localizedFailureReason
                                      buttonTitle:nil];
         } else {
             art_SafeBlockCall(completionBlock, nil);
         }
     }];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - JSQMessages CollectionView DataSource

- (id<JSQMessageData>)collectionView:(JSQMessagesCollectionView *)collectionView messageDataForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return [self.messageData.messages objectAtIndex:indexPath.item];
}

- (id<JSQMessageBubbleImageDataSource>)collectionView:(JSQMessagesCollectionView *)collectionView messageBubbleImageDataForItemAtIndexPath:(NSIndexPath *)indexPath
{
    JSQMessage *message = [self.messageData.messages objectAtIndex:indexPath.item];
    
    if ([message.senderId isEqualToString:self.senderId]) {
        return self.messageData.outgoingBubbleImageData;
    }
    
    return self.messageData.incomingBubbleImageData;
}

- (id<JSQMessageAvatarImageDataSource>)collectionView:(JSQMessagesCollectionView *)collectionView avatarImageDataForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return [self.messageData.avatars objectForKey:kARTAvatarDefault];
}

- (NSAttributedString *)collectionView:(JSQMessagesCollectionView *)collectionView attributedTextForCellTopLabelAtIndexPath:(NSIndexPath *)indexPath
{
    JSQMessage *message = [self.messageData.messages objectAtIndex:indexPath.item];
    return [[NSAttributedString alloc] initWithString:[message.date art_stringWithFormatJapaneseYYYYMD]];
}

- (NSAttributedString *)collectionView:(JSQMessagesCollectionView *)collectionView attributedTextForMessageBubbleTopLabelAtIndexPath:(NSIndexPath *)indexPath
{
    return nil;
}

- (CGFloat)                    collectionView:(JSQMessagesCollectionView *)collectionView
                                       layout:(JSQMessagesCollectionViewFlowLayout *)collectionViewLayout
    heightForMessageBubbleTopLabelAtIndexPath:(NSIndexPath *)indexPath
{
    return 5;
}

- (NSAttributedString *)collectionView:(JSQMessagesCollectionView *)collectionView attributedTextForCellBottomLabelAtIndexPath:(NSIndexPath *)indexPath
{
    JSQTextMessage *message = [self.messageData.messages objectAtIndex:indexPath.item];
    if (message.date) {
        return [[NSAttributedString alloc] initWithString:[message.date art_stringWithFormatJapaneseMD_HM]];
    }
    return nil;
}

- (CGFloat)collectionView:(JSQMessagesCollectionView *)collectionView
                   layout:(JSQMessagesCollectionViewFlowLayout *)collectionViewLayout heightForCellBottomLabelAtIndexPath:(NSIndexPath *)indexPath
{
    JSQTextMessage *message = [self.messageData.messages objectAtIndex:indexPath.item];
    if (message.date) {
        return 30.0;
    }
    return 0.0f;
}

// title height
- (CGFloat)collectionView:(JSQMessagesCollectionView *)collectionView
                   layout:(JSQMessagesCollectionViewFlowLayout *)collectionViewLayout heightForCellTopLabelAtIndexPath:(NSIndexPath *)indexPath
{
    return 10.0f;
}

- (void)collectionView:(JSQMessagesCollectionView *)collectionView
 didTapCellAtIndexPath:(NSIndexPath *)indexPath
         touchLocation:(CGPoint)touchLocation
{
}

- (void)collectionView:(JSQMessagesCollectionView *)collectionView
                header:(JSQMessagesLoadEarlierHeaderView *)headerView
didTapLoadEarlierMessagesButton:(UIButton *)sender
{
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UICollectionView DataSource

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [self.messageData.messages count];
}

- (UICollectionViewCell *)collectionView:(JSQMessagesCollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    JSQMessagesCollectionViewCell *cell = (JSQMessagesCollectionViewCell *)[super collectionView:collectionView cellForItemAtIndexPath:indexPath];

    JSQTextMessage *msg = [self.messageData.messages objectAtIndex:indexPath.item];
    cell.backgroundColor = [UIColor clearColor];

    if ([msg.senderId isEqualToString:self.senderId]) {
        cell.textView.textColor = [UIColor blackColor];
    } else {
        cell.textView.textColor = [UIColor blackColor];
        [cell.avatarImageView art_setImageWithURL:self.shopImageURL
                                 placeholderImage:[UIImage imageNamed:@"no_image_private"]
                                          noImage:[UIImage imageNamed:@"no_image_private"]
                                            alpha:1.0
                                       parentView:nil
                                    needAnimation:YES];
        cell.avatarImageView.clipsToBounds      = YES;
        cell.avatarImageView.contentMode        = UIViewContentModeScaleAspectFill;
        cell.avatarImageView.layer.cornerRadius = cell.avatarImageView.width * 0.5;
    }

    cell.textView.linkTextAttributes = @{ NSForegroundColorAttributeName: cell.textView.textColor,
                                          NSUnderlineStyleAttributeName: @(NSUnderlineStyleSingle | NSUnderlinePatternSolid) };

    return cell;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - JSQMessagesViewController method overrides

- (void)didPressSendButton:(UIButton *)button
           withMessageText:(NSString *)text
                  senderId:(NSString *)senderId
         senderDisplayName:(NSString *)senderDisplayName
                      date:(NSDate *)date
{
    __weak typeof(self) weakSelf = self;
    
    [self postUOForText:text
        completionBlock: ^(id resultObject) {
            JSQTextMessage *message = [[JSQTextMessage alloc] initWithSenderId:self.senderId
                                                             senderDisplayName:self.senderDisplayName
                                                                          date:date
                                                                          text:text];
            [weakSelf.messageData.messages addObject:message];
            [weakSelf finishSendingMessage];
        }];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - Messages collection view cell delegate

- (void)messagesCollectionViewCellDidTapAvatar:(JSQMessagesCollectionViewCell *)cell
{
}

- (void)messagesCollectionViewCellDidTapMessageBubble:(JSQMessagesCollectionViewCell *)cell
{
}

- (void)messagesCollectionViewCellDidTapCell:(JSQMessagesCollectionViewCell *)cell atPosition:(CGPoint)position
{
}

@end
