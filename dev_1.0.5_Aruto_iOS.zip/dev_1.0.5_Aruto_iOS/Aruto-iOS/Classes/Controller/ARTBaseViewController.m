//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTBaseViewController.h"

@interface ARTBaseViewController () <UIGestureRecognizerDelegate>

@property (nonatomic, weak) IBOutlet UILabel     *headerTitleLabel;
@property (nonatomic, weak) IBOutlet UIImageView *headerImageView;
@property (nonatomic, weak) IBOutlet UIView      *headerView;
@property (nonatomic, weak) IBOutlet UIButton    *leftButton;
@property (nonatomic, weak) IBOutlet UIButton    *rightButton;

@property (nonatomic, strong) IBOutlet NSLayoutConstraint *headerConstraint;

@property (nonatomic, copy) void (^leftButtonBlock)();
@property (nonatomic, copy) void (^rightButtonBlock)();

@end

@implementation ARTBaseViewController

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [self deallocChild];
}

- (void)deallocChild
{
    // override if you needed
}

- (instancetype)initWithNib
{
    if (!(self = [super initWithNibName:NSStringFromClass([self class]) bundle:nil])) { return nil; }

    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.navigationController.navigationBarHidden = YES;
    // 拡張レイアウトのエッジをクリア
    self.edgesForExtendedLayout = UIRectEdgeNone;
    // 不透明バーが拡張レイアウトに含まれない
    self.extendedLayoutIncludesOpaqueBars = NO;
    // ScrollViewのインセット自動調整をしない
    self.automaticallyAdjustsScrollViewInsets = NO;

    art_SafeBlockCall(_viewDidLoadBlock, self);

    self.leftButton.exclusiveTouch                  = YES;
    self.rightButton.exclusiveTouch                 = YES;
    self.headerTitleLabel.adjustsFontSizeToFitWidth = YES;

    /*
    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.frame  = CGRectMake(0, self.headerImageView.height - 30, self.headerImageView.width, 30);
    gradient.colors = @[(id)[art_UIColorWithRGBA(243, 152, 0, 0.0) CGColor],
                        (id)[art_UIColorWithRGBA(243, 152, 0, 1.0) CGColor]];
    [self.headerImageView.layer insertSublayer:gradient atIndex:0];
    */
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.navigationController.interactivePopGestureRecognizer.delegate = self;

    if (!self.isModalController) {
        [[ARTViewContainer shared] tabViewisShow:self.isShowTabView];
        [[ARTViewContainer shared] tabViewTargetScrollView:self.targetScrollView];
        [self resetHeaderView];
        // hiddenHeaderImage　表示するかしないか
        if(self.isHiddenHeaderImage){
            [self hiddenHeaderView];
        }
    }
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    if (self.navigationController.interactivePopGestureRecognizer.delegate == self) {
        self.navigationController.interactivePopGestureRecognizer.delegate = nil;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (void)addContentsView:(UIView *)view
{
    [self.contentsView addSubview:view];
    view.frame = self.contentsView.bounds;
}

- (void)setHeaderImageForURL:(NSURL *)imageURL
{
    [self.headerImageView art_setImageWithURL:imageURL
                             placeholderImage:nil
                                      noImage:nil
                                        alpha:0.13
                                   parentView:nil
                                needAnimation:NO];
}

- (void)setHeaderTitle:(NSString *)headerTitle numberOfLines:(NSInteger)numberOfLines
{
    self.headerTitleLabel.numberOfLines = numberOfLines;
    
    /*
    //iconfontを使うかどうかのチェック
    if ([headerTitle isEqualToString:ARTControllerNameRanking]) {
        //aruto-iconfontを適用
        self.headerTitleLabel.font = [UIFont fontWithName:@"aruto-iconfont" size:20];
        self.headerTitleLabel.text = aruto_icon_ranking;
    }
    else if ([headerTitle isEqualToString:ARTControllerNameMyPage]) {
        //aruto-iconfontを適用
        self.headerTitleLabel.font = [UIFont fontWithName:@"aruto-iconfont" size:20];
        self.headerTitleLabel.text = aruto_icon_mypage;
    }
    else if ([headerTitle isEqualToString:ARTControllerNameSpecialEdition]) {
        //aruto-iconfontを適用
        self.headerTitleLabel.font = [UIFont fontWithName:@"aruto-iconfont" size:20];
        self.headerTitleLabel.text = aruto_icon_specialedition;
    }
    else if ([headerTitle isEqualToString:ARTControllerNameGallery]) {
        //aruto-iconfontを適用
        self.headerTitleLabel.font = [UIFont fontWithName:@"aruto-iconfont" size:20];
        self.headerTitleLabel.text = aruto_icon_gallery;
    }
    else{
        self.headerTitleLabel.numberOfLines = numberOfLines;
        self.headerTitleLabel.text          = headerTitle;
    }
    */
    
    self.headerTitleLabel.text          = headerTitle;
}

- (void)setLeftBackButtonImageWithblock:(void (^)())block
{
    if (!block) {
        self.leftButton.hidden = YES;
        return;
    }

    self.leftButton.titleLabel.font = [UIFont systemFontOfSize:12];
    [self.leftButton setTitle:@"BACK" forState:UIControlStateNormal];
    [self.leftButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.leftButton setImage:[IonIcons imageWithIcon:ion_chevron_left
                                            iconColor:[UIColor blackColor]
                                             iconSize:15
                                            imageSize:CGSizeMake(22, 22)] forState:UIControlStateNormal];
    [self.leftButton setImageEdgeInsets:UIEdgeInsetsMake(0, -3, 0, -10)];
    [self.leftButton setTitleEdgeInsets:UIEdgeInsetsMake(2, 5, 0, -5)];
    self.leftButton.hidden = NO;
    self.leftButtonBlock   = block;
}

- (void)setLeftButtonImageWithBlock:(void (^)(UIButton *button))imageBlock block:(void (^)())block
{
    if (!imageBlock || !block) {
        self.leftButton.hidden = YES;
        return;
    }

    [self.leftButton setImageEdgeInsets:UIEdgeInsetsZero];
    self.leftButton.hidden = NO;
    imageBlock(self.leftButton);
    self.leftButtonBlock = block;
}

- (void)setRightCloseButtonWithblock:(void (^)())block
{
    if (!block) {
        self.rightButton.hidden = YES;
        return;
    }

    self.rightButton.layer.borderWidth  = 0;
    self.rightButton.layer.cornerRadius = 0;
    [self.rightButton setTitle:@"閉じる" forState:UIControlStateNormal];
    [self.rightButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    self.rightButton.hidden = NO;
    self.rightButtonBlock   = block;
}

- (void)setRightSearchOptionButtonWithblock:(void (^)())block
{
    if (!block) {
        self.rightButton.hidden = YES;
        return;
    }

    //    self.rightButton.layer.borderWidth = 1;
    //    self.rightButton.layer.cornerRadius = 5;
    self.rightButton.layer.borderColor = [UIColor whiteColor].CGColor;
    [self.rightButton setTitle:@"絞り込み" forState:UIControlStateNormal];
    [self.rightButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    self.rightButton.hidden = NO;
    self.rightButtonBlock   = block;
}

- (void)setRightSearchOptionSegmentControlWithblock:(void (^)())block
{
    if (!block) {
        self.rightButton.hidden = YES;
        return;
    }
    
    //    self.rightButton.layer.borderWidth = 1;
    //    self.rightButton.layer.cornerRadius = 5;
    /*
    self.rightButton.layer.borderColor = [UIColor whiteColor].CGColor;
    [self.rightButton setTitle:@"絞り込み" forState:UIControlStateNormal];
    [self.rightButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    self.rightButton.hidden = NO;
    self.rightButtonBlock   = block;
    */
    
    //※このクラスにセグメントコントロールをxibで配置する必要があるかも
    
    //セグメントコントールボタンを右に配置
    NSArray *items = [NSArray arrayWithObjects:@"人", @"店", nil];
    UISegmentedControl *segment = [[UISegmentedControl alloc]initWithItems:items];
    segment.frame = CGRectMake(0,0,80,40);
    segment.selectedSegmentIndex = 1;
    
    UIBarButtonItem *segmentBarItem = [[UIBarButtonItem alloc] initWithCustomView:segment];
    
    self.navigationItem.rightBarButtonItem = segmentBarItem;
    
    //self.rightButton.hidden = NO;
    //self.rightButtonBlock   = block;
    //self.navigationItem.rightBarButtonItem = block;
}

- (void)setRightButtonImageWithBlock:(void (^)(UIButton *button))imageBlock block:(void (^)())block
{
    if (!imageBlock || !block) {
        self.rightButton.hidden = YES;
        return;
    }

    self.rightButton.layer.borderWidth  = 0;
    self.rightButton.layer.cornerRadius = 0;
    self.rightButton.hidden             = NO;
    imageBlock(self.rightButton);
    self.rightButtonBlock = block;
}

- (void)setRightSearchButtonWithblock:(void (^)())block
{
//    if (!block) {
//        self.rightButton.hidden = YES;
//        return;
//    }
    
    //    self.rightButton.layer.borderWidth = 1;
    //    self.rightButton.layer.cornerRadius = 5;
    self.rightButton.layer.borderColor = [UIColor whiteColor].CGColor;
    [self.rightButton setImage:[ARTIcons imageWithIcon:aruto_icon_search
                                               iconColor:[UIColor darkGrayColor]
                                                iconSize:15
                                               imageSize:CGSizeMake(30, 30)] forState:UIControlStateNormal];
    //[self.rightButton setTitle:@"絞り込み" forState:UIControlStateNormal];//元絞り込み
    [self.rightButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    self.rightButton.hidden = NO;
    self.rightButtonBlock   = block;
}

- (IBAction)tapLeftButton:(id)sender
{
    art_SafeBlockCall(_leftButtonBlock);
}

- (IBAction)tapRightButton:(id)sender
{
    art_SafeBlockCall(_rightButtonBlock);
}

- (void)resetHeaderView
{
    // todo : 現状使ってない（scrollHeadeForscrollView使ってないから）
    return;
    
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationFade];

    self.headerConstraint.constant = 64;
    [self.headerView setNeedsUpdateConstraints];
}

- (void)hiddenHeaderView
{
    [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationFade];
    
    self.headerConstraint.constant = 0;
    [self.headerView setNeedsUpdateConstraints];
}


- (void)scrollHeadeForscrollView:(UIScrollView *)scrollView
{
    // todo : 現状使ってない
    return;
    
    CGFloat offset          = scrollView.contentOffset.y;
    CGFloat currentConstant = self.headerConstraint.constant;
    //LOG(@"%f", offset);

    if (offset >= 0 && offset <= 352) {
        self.headerConstraint.constant = 64 - offset / 8;
    } else if (offset > 352) {
        if (self.headerConstraint.constant > 20 && self.headerConstraint.constant <= 64) {
            self.headerConstraint.constant -= 1;
        } else {
            if (self.headerConstraint.constant != 20) {
                self.headerConstraint.constant = 20;
            }
        }
    } else if (offset < 0) {
        if (self.headerConstraint.constant != 64) {
            self.headerConstraint.constant = 64;
        }
    }

    if (self.headerConstraint.constant > 30) {
        [[UIApplication sharedApplication] setStatusBarHidden:NO withAnimation:UIStatusBarAnimationFade];
    } else {
        [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationFade];
    }

    if (currentConstant != self.headerConstraint.constant) {
        [self.headerView setNeedsUpdateConstraints];
    }
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - UIGestureRecognizer Delegate

- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer
{
    if (self.isEditing) {
        return NO;
    } else {
        return YES;
    }
}

@end
