//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTViewContainer.h"
#import "ARTAppDelegate.h"
#import "ARTTabView.h"

@interface ARTViewContainer ()

@property (nonatomic, strong) UIView *mainLayerView;
@property (nonatomic, strong) UIView *loadingLayerView;
@property (nonatomic, strong) UIView *modalLayerView;
@property (nonatomic, strong) UIView *disableLayerView;

@property (nonatomic, strong) UINavigationController *activeNavigationController;
@property (nonatomic, strong) UINavigationController *activeModalViewController;
@property (nonatomic, strong) UIViewController       *activeLoadingViewController;
@property (nonatomic, strong) UIViewController       *activeLoginViewController;
@property (nonatomic, strong) ARTTabView             *tabView;

@property (nonatomic, assign) BOOL isToggle;

@end

@implementation ARTViewContainer

+ (ARTViewContainer *)shared
{
    return [(ARTAppDelegate *)[[UIApplication sharedApplication] delegate] rootController];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.isToggle = NO;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

- (UIViewController *)activeViewController
{
    if (self.activeLoginViewController) {
        return self.activeLoginViewController;
    }
    if (self.activeLoadingViewController) {
        return self.activeLoadingViewController;
    }
    if (self.activeModalViewController) {
        return self.activeModalViewController.topViewController;
    }
    if (self.activeNavigationController) {
        return self.activeNavigationController.topViewController;
    }
    return self;
}

- (void)toggleMenuWithCompletionBlock:(void (^)())block
{
    [UIView animateWithDuration:0.3
                     animations: ^{
                         if (!self.isToggle) {
                             self.modalLayerView.left = 200;
                             self.mainLayerView.left = 200;
                             self.modalLayerView.userInteractionEnabled = NO;
                             self.mainLayerView.userInteractionEnabled = NO;
                         } else {
                             self.modalLayerView.left = 0;
                             self.mainLayerView.left = 0;
                             self.modalLayerView.userInteractionEnabled = YES;
                             self.mainLayerView.userInteractionEnabled = YES;
                         }
                     } completion: ^(BOOL finished) {
                         self.isToggle = !self.isToggle;
                         art_SafeBlockCall(block);
                     }];
}

- (void)initialSetting
{
    self.mainLayerView = UIView.new;
    [self addLayerView:self.mainLayerView];
    
    self.tabView        = [ARTTabView art_createViewByNib];
    self.tabView.bottom = self.view.bottom;
    [self.tabView setTranslatesAutoresizingMaskIntoConstraints:NO];
    [self.view addSubview:self.tabView];
    
    // todo : ほんとはIBでやりたかったが致し方無し
    [self.tabView addConstraint:[NSLayoutConstraint constraintWithItem:self.tabView
                                                             attribute:NSLayoutAttributeHeight
                                                             relatedBy:NSLayoutRelationEqual
                                                                toItem:nil
                                                             attribute:NSLayoutAttributeHeight
                                                            multiplier:1.0
                                                              constant:50.0]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tabView
                                                          attribute:NSLayoutAttributeLeft
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:self.view
                                                          attribute:NSLayoutAttributeLeft
                                                         multiplier:1.0
                                                           constant:0.0]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tabView
                                                          attribute:NSLayoutAttributeRight
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:self.view
                                                          attribute:NSLayoutAttributeRight
                                                         multiplier:1.0
                                                           constant:0.0]];
    [self.view addConstraint:[NSLayoutConstraint constraintWithItem:self.tabView
                                                          attribute:NSLayoutAttributeBottom
                                                          relatedBy:NSLayoutRelationEqual
                                                             toItem:self.view
                                                          attribute:NSLayoutAttributeBottom
                                                         multiplier:1.0
                                                           constant:0.0]];
    
    self.loadingLayerView = UIView.new;
    [self addLayerView:self.loadingLayerView];
    self.loadingLayerView.alpha = 0.0f;
    
    self.modalLayerView = UIView.new;
    [self addLayerView:self.modalLayerView];
    self.modalLayerView.alpha = 0.0f;
    
    self.disableLayerView = UIView.new;
    [self addLayerView:self.disableLayerView];
    self.disableLayerView.alpha = 0.0f;
    
    
    if ([[ARTUserManager shared] isLogined]) {
        //[self setTopController:[ARTViewControllerFactory myPageViewController] needToggle:NO];
        [self setTopController:[ARTViewControllerFactory specialEditionView] needToggle:NO];
    } else {
        //[self setTopController:[ARTViewControllerFactory searchRootController] needToggle:NO];
        [self setTopController:[ARTViewControllerFactory specialEditionView] needToggle:NO];
    }
    
    /* welcomeviewを表示させるときの分岐（welcomeviewをブラッシュアップした時に使うので残している）
    if (ARTUserDefaults.shared.isFinishWelcomeView) {
        if ([[ARTUserManager shared] isLogined]) {
            //[self setTopController:[ARTViewControllerFactory myPageViewController] needToggle:NO];
            [self setTopController:[ARTViewControllerFactory specialEditionView] needToggle:NO];
        } else {
            //[self setTopController:[ARTViewControllerFactory searchRootController] needToggle:NO];
            [self setTopController:[ARTViewControllerFactory specialEditionView] needToggle:NO];
        }
    } else {
        [self showModalViewWithController:[ARTViewControllerFactory welcomeViewController]
                                 animated:NO
                           animationBlock:nil
                          completionBlock:nil];
    }
    */
    
    [[ARTTaskManager shared] startInitialDataTask];
}

- (void)tabViewisShow:(BOOL)isShow
{
    if (isShow) {
        self.tabView.hidden = NO;
        [self.tabView initSetting];
    } else {
        self.tabView.hidden = YES;
    }
}

- (void)tabViewTargetScrollView:(UIScrollView *)scrollView
{
    self.tabView.targetScrollView = scrollView;
}

- (void)hideTabViewAnimationWithScrollView:(UIScrollView *)scrollView
{
    if (!self.tabView || self.tabView.hidden) { return; }
    
    [self.tabView hideAnimationWithScrollView:scrollView];
}

- (void)showTabViewAnimationWithScrollView:(UIScrollView *)scrollView
{
    if (!self.tabView || self.tabView.hidden) { return; }
    
    [self.tabView showAnimationWithScrollView:scrollView];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - Navigation

- (void)setTopController:(UIViewController *)controller needToggle:(BOOL)needToggle
{
    //    if (self.activeNavigationController) {
    //        UIViewController *topController = [self.activeNavigationController topViewController];
    //        if ([controller isKindOfClass:[topController class]]) {
    //            return;
    //        }
    //    }
    //
    __weak typeof(self) weakSelf = self;
    
    [self setTopController:controller
             navController:self.activeNavigationController
                 layerView:self.mainLayerView
           completionBlock: ^(UINavigationController *resultNavController) {
               weakSelf.activeNavigationController = resultNavController;
           }];
}

- (void)pushActiveNavController:(UIViewController *)viewController
{
    [self pushNavController:self.activeNavigationController viewController:viewController];
}

- (void)pushActiveModalNavController:(UIViewController *)viewController
{
    [self pushNavController:self.activeModalViewController viewController:viewController];
}

- (void)popActiveNavController
{
    [self popNavController:self.activeNavigationController];
}

- (void)popRootActiveNavController
{
    [self popRootController:self.activeNavigationController];
}

- (void)popActiveModalNavController
{
    [self popNavController:self.activeModalViewController];
}

- (void)popRootActiveModalNavController
{
    [self popRootController:self.activeModalViewController];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - Modal Layer

- (void)showModalViewWithController:(UIViewController *)controller
                           animated:(BOOL)animated
                     animationBlock:(void (^)())animationBlock
                    completionBlock:(void (^)(UINavigationController *resultNavController))completionBlock
{
    __weak typeof(self) weakSelf = self;
    
    [self showModalViewWithController:controller
                            layerView:weakSelf.modalLayerView
                             animated:animated
                       animationBlock: ^{
                           weakSelf.modalLayerView.alpha = 1;
                           art_SafeBlockCall(animationBlock);
                       } completionBlock: ^(UINavigationController *resultNavController) {
                           weakSelf.activeModalViewController = resultNavController;
                           art_SafeBlockCall(completionBlock, resultNavController);
                       }];
}

- (void)closeModalViewWithAnimationBlock:(void (^)(id container))animationBlock
                         completionBlock:(void (^)(id container))completionBlock
{
    __weak typeof(self) weakSelf = self;
    
    [self closeModalViewWithLayerView:self.modalLayerView
                       animationBlock:animationBlock
                      completionBlock: ^(id container) {
                          art_SafeBlockCall(completionBlock, container);
                          weakSelf.activeModalViewController = nil;
                      }];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - Modal

- (void)showUserAuthModalView
{
    if (self.activeLoginViewController) { return; }
    
    self.activeLoginViewController = [ARTViewControllerFactory userAuthViewController];
    [self presentViewController:self.activeLoginViewController animated:YES completion:nil];
}

- (void)hideUserAuthModalView
{
    if (!self.activeLoginViewController) { return; }
    
    [self.activeLoginViewController dismissViewControllerAnimated:YES completion: ^{
        self.activeLoginViewController = nil;
    }];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - Modal Layer

- (void)showLoadingView
{
    if (self.activeLoadingViewController) { return; }
    
    UIViewController *controller = [ARTViewControllerFactory loadingViewController];
    [self.loadingLayerView addSubview:controller.view];
    self.activeLoadingViewController = controller;
    controller.view.frame            = self.loadingLayerView.bounds;
    self.loadingLayerView.alpha      = 1;
}

- (void)hideLoadingView
{
    [UIView animateWithDuration:0.2 animations: ^{
        self.loadingLayerView.alpha = 0;
    } completion: ^(BOOL finished) {
        for (UIView * view in self.loadingLayerView.subviews) {
            [view removeFromSuperview];
        }
        self.activeLoadingViewController = nil;
    }];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - Push

- (void)showPushMessageViewForEntryId:(NSNumber *)entryId
{
    [self hideUserAuthModalView];
    
    __weak typeof(self) weakSelf = self;
    [self closeModalViewWithAnimationBlock: ^(id container) {
    } completionBlock: ^(id container) {
        [weakSelf setTopController:[ARTViewControllerFactory myPageViewController] needToggle:NO];
        [weakSelf.activeNavigationController pushViewController:[ARTViewControllerFactory entryListViewControllerWithNeedBack:YES] animated:NO];
        [weakSelf pushActiveNavController:[ARTViewControllerFactory messageViewControllerWithEntryId:entryId]];
    }];
}

- (void)showPushNotisView
{
    [self hideUserAuthModalView];
    
    __weak typeof(self) weakSelf = self;
    [self closeModalViewWithAnimationBlock: ^(id container) {
    } completionBlock: ^(id container) {
        [weakSelf showModalViewWithController:[ARTViewControllerFactory bannerViewController]
                                     animated:YES animationBlock: ^{
                                     } completionBlock: ^(UINavigationController *resultNavController) {
                                     }];
    }];
}

@end
