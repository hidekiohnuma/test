//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTRootContainer : UIViewController

- (void)addLayerView:(UIView *)view;

- (void)setTopController:(UIViewController *)controller
           navController:(UIViewController *)navController
               layerView:(UIView *)layerView
         completionBlock:(void (^)(UINavigationController *resultNavController))completionBlock;

- (void)pushNavController:(UINavigationController *)navController viewController:(UIViewController *)viewController;
- (void)popRootController:(UINavigationController *)navController;
- (void)popNavController:(UINavigationController *)navController;

- (void)showModalViewWithController:(UIViewController *)controller
                          layerView:(UIView *)layerView
                           animated:(BOOL)animated
                     animationBlock:(void (^)())animationBlock
                    completionBlock:(void (^)(UINavigationController *resultNavController))completionBlock;
- (void)closeModalViewWithLayerView:(UIView *)layerView
                     animationBlock:(void (^)(id container))animationBlock
                    completionBlock:(void (^)(id container))completionBlock;
- (void)pushModalNavController:(UINavigationController *)navController viewController:(UIViewController *)viewController;
- (void)popModalNavController:(UINavigationController *)navController;

@end
