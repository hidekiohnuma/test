//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTModalContainer.h"

@interface ARTModalContainer ()

@property (nonatomic, strong) UIImageView *backgroundImageView;

@property (nonatomic, strong) UIView *mainLayerView;

@property (nonatomic, strong) UINavigationController *activeNavigationController;

@end

@implementation ARTModalContainer

- (void)dealloc
{
    LOG_METHOD;
}

- (void)settingWithTopController:(UIViewController *)controller backgroundImage:(UIImage *)backgroundImage
{
    self.backgroundImageView                  = [[UIImageView alloc] initWithFrame:self.view.bounds];
    self.backgroundImageView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.backgroundImageView.clipsToBounds    = YES;
    self.backgroundImageView.image            = backgroundImage;
    [self.view addSubview:self.backgroundImageView];

    self.mainLayerView = UIView.new;
    [self addLayerView:self.mainLayerView];
    self.mainLayerView.backgroundColor = [UIColor clearColor];

    __weak typeof(self) weakSelf = self;

    [self setTopController:controller
             navController:self.activeNavigationController
                 layerView:self.mainLayerView
           completionBlock: ^(UINavigationController *resultNavController) {
         weakSelf.activeNavigationController = resultNavController;
     }];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

@end
