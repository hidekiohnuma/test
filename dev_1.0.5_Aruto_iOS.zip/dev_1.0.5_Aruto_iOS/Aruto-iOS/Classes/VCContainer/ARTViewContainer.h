//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTViewContainer : ARTRootContainer

+ (ARTViewContainer *)shared;

- (UIViewController *)activeViewController;

- (void)toggleMenuWithCompletionBlock:(void (^)())block;

- (void)initialSetting;

- (void)tabViewisShow:(BOOL)isShow;
- (void)tabViewTargetScrollView:(UIScrollView *)scrollView;
- (void)hideTabViewAnimationWithScrollView:(UIScrollView *)scrollView;
- (void)showTabViewAnimationWithScrollView:(UIScrollView *)scrollView;

- (void)setTopController:(UIViewController *)controller needToggle:(BOOL)needToggle;
- (void)pushActiveNavController:(UIViewController *)viewController;
- (void)pushActiveModalNavController:(UIViewController *)viewController;
- (void)popActiveNavController;
- (void)popRootActiveNavController;
- (void)popActiveModalNavController;
- (void)popRootActiveModalNavController;

- (void)showModalViewWithController:(UIViewController *)controller
                           animated:(BOOL)animated
                     animationBlock:(void (^)())animationBlock
                    completionBlock:(void (^)(UINavigationController *resultNavController))completionBlock;
- (void)closeModalViewWithAnimationBlock:(void (^)(id container))animationBlock
                         completionBlock:(void (^)(id container))completionBlock;

- (void)showUserAuthModalView;
- (void)hideUserAuthModalView;

- (void)showLoadingView;
- (void)hideLoadingView;

- (void)showPushMessageViewForEntryId:(NSNumber *)entryId;
- (void)showPushNotisView;

@end
