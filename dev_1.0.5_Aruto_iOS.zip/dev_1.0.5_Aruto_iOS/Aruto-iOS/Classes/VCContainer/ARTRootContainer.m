//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTRootContainer.h"

@implementation ARTRootContainer

- (void)viewDidLoad
{
    [super viewDidLoad];

    self.navigationController.navigationBarHidden = YES;
    // 拡張レイアウトのエッジをクリア
    self.edgesForExtendedLayout = UIRectEdgeNone;
    // 不透明バーが拡張レイアウトに含まれない
    self.extendedLayoutIncludesOpaqueBars = NO;
    // ScrollViewのインセット自動調整をしない
    self.automaticallyAdjustsScrollViewInsets = NO;
}

- (void)addLayerView:(UIView *)view
{
    view.frame            = self.view.bounds;
    view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    view.clipsToBounds    = YES;
    [self.view addSubview:view];
}

- (void)setTopController:(UIViewController *)controller
           navController:(UIViewController *)navController
               layerView:(UIView *)layerView
         completionBlock:(void (^)(UINavigationController *resultNavController))completionBlock
{
    if (!controller) { return; }

    @synchronized(self)
    {
        if (navController) {
            for (UIView *view in layerView.subviews) {
                [view removeFromSuperview];
            }
            [navController removeFromParentViewController];
            navController = nil;
        }

        UINavigationController *newNavController = [[UINavigationController alloc] initWithRootViewController:controller];
        [self addChildViewController:newNavController];
        [layerView addSubview:newNavController.view];
        newNavController.view.frame = layerView.bounds;
        art_SafeBlockCall(completionBlock, newNavController);
    }
}

- (void)pushNavController:(UINavigationController *)navController viewController:(UIViewController *)viewController
{
    if (!navController || !viewController) { return; }

    @synchronized(self)
    {
        [navController pushViewController:viewController animated:YES];
    }
}

- (void)popNavController:(UINavigationController *)navController
{
    if (!navController) { return; }

    @synchronized(self)
    {
        [navController popViewControllerAnimated:YES];
    }
}

- (void)popRootController:(UINavigationController *)navController
{
    if (!navController) { return; }

    @synchronized(self)
    {
        [navController popToRootViewControllerAnimated:YES];
    }
}

- (void)showModalViewWithController:(UIViewController *)controller
                          layerView:(UIView *)layerView
                           animated:(BOOL)animated
                     animationBlock:(void (^)())animationBlock
                    completionBlock:(void (^)(UINavigationController *resultNavController))completionBlock
{
    if (!controller) { return; }

    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:controller];
    navController.navigationBarHidden = YES;

    __weak typeof(self) weakSelf = self;

    void (^modalBlock)(id container) = ^(id container) {
        [layerView addSubview:navController.view];
        [weakSelf.view bringSubviewToFront:layerView];
        if (animated) {
            [UIView animateWithDuration:0.2
                             animations: ^{
                 art_SafeBlockCall(animationBlock);
             } completion: ^(BOOL finished) {
                 art_SafeBlockCall(completionBlock, navController);
             }];
        } else {
            art_SafeBlockCall(animationBlock);
            art_SafeBlockCall(completionBlock, navController);
        }
    };
    @synchronized(self)
    {
        if (layerView.subviews.count != 0) {
            [self closeModalViewWithLayerView:layerView animationBlock:animationBlock completionBlock:modalBlock];
        } else {
            art_SafeBlockCall(modalBlock, self);
        }
    }
}

- (void)closeModalViewWithLayerView:(UIView *)layerView
                     animationBlock:(void (^)(id container))animationBlock
                    completionBlock:(void (^)(id container))completionBlock
{
    @synchronized(self)
    {
        __weak typeof(self) weakSelf = self;

        [UIView animateWithDuration:0.2
                         animations: ^{
             art_SafeBlockCall(animationBlock, weakSelf);
             layerView.alpha = 0;
         } completion: ^(BOOL finished) {
             for (UIView * view in layerView.subviews) {
                 [view removeFromSuperview];
             }
             art_SafeBlockCall(completionBlock, weakSelf);
         }];
    }
}

- (void)pushModalNavController:(UINavigationController *)navController viewController:(UIViewController *)viewController
{
    if (!navController || !viewController) { return; }

    @synchronized(self)
    {
        UIViewController *controller = navController.topViewController;
        [navController pushViewController:viewController animated:YES];
        [UIView animateWithDuration:0.2
                         animations: ^{
             controller.view.alpha = 0;
         } completion: ^(BOOL finished) {
         }];
    }
}

- (void)popModalNavController:(UINavigationController *)navController
{
    if (!navController) { return; }

    @synchronized(self)
    {
        for (UIViewController *controller in navController.viewControllers) {
            controller.view.alpha = 0;
        }
        [navController popViewControllerAnimated:YES];

        [UIView animateWithDuration:1
                         animations: ^{
             for (UIViewController * controller in navController.viewControllers) {
                 controller.view.alpha = 1;
             }
         }];
    }
}

@end
