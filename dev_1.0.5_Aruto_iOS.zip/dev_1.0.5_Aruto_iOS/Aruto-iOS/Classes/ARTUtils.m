//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTUtils.h"
#include <sys/xattr.h>

@implementation ARTUtils

+ (BOOL)isReachable
{
    Reachability *reachability = [Reachability reachabilityForInternetConnection];
    NetworkStatus status       = [reachability currentReachabilityStatus];
    if (status == NotReachable) {
        return NO;
    } else {
        return YES;
    }
}

+ (id)nullCheckWithObject:(id)checkObject isNumeric:(BOOL)isNumeric
{
    if (!checkObject || [checkObject isEqual:[NSNull null]]) {
        return nil;
    } else {
        if (isNumeric) {
            return @([checkObject intValue]);
        } else {
            return checkObject;
        }
    }
}

// ディレクトリがあればパスを返す。なければ作って返す(iCloud対象外の設定もする)
+ (NSString *)checkAndCreateDirectoryAtPath:(NSString *)path
{
    if (![[NSFileManager defaultManager] fileExistsAtPath:path]) {
        // ないので作る
        NSError *error = nil;
        if ([[NSFileManager defaultManager] createDirectoryAtPath:path
                                      withIntermediateDirectories:YES
                                                       attributes:nil
                                                            error:&error]) {
            if (error) {
                LOG(@"checkAndCreateDirectoryAtPath error : %@", [error localizedDescription]);

                return nil;
            }
            NSURL *directoryURL = [NSURL fileURLWithPath:path isDirectory:YES];
            [self addSkipBackupAttributeToItemAtURL:directoryURL];

            return path;
        } else {
            return nil;
        }
    } else {
        // 既にある
        return path;
    }
}

// iCloud保存対象外にする
+ (BOOL)addSkipBackupAttributeToItemAtURL:(NSURL *)URL
{
    const char *filePath = [[URL path] fileSystemRepresentation];
    const char *attrName = "com.apple.MobileBackup";
    if (&NSURLIsExcludedFromBackupKey == nil) {
        // iOS 5.0.1 and lower
        u_int8_t attrValue = 1;
        int      result    = setxattr(filePath, attrName, &attrValue, sizeof(attrValue), 0, 0);

        return result == 0;
    } else {
        // First try and remove the extended attribute if it is present
        long result = getxattr(filePath, attrName, NULL, sizeof(u_int8_t), 0, 0);
        if (result != -1) {
            int removeResult = removexattr(filePath, attrName, 0);
            if (removeResult == 0) {
                LOG(@"Removed extended attribute on file %@", URL);
            }
        }

        return [URL setResourceValue:[NSNumber numberWithBool:YES] forKey:NSURLIsExcludedFromBackupKey error:nil];
    }
}

+ (UIImage *)imageWithColor:(UIColor *)color
{
    CGRect rect = CGRectMake(0, 0, 1, 1);
    UIGraphicsBeginImageContext(rect.size);
    CGContextRef contextRef = UIGraphicsGetCurrentContext();
    CGContextSetFillColorWithColor(contextRef, [color CGColor]);
    CGContextFillRect(contextRef, rect);
    UIImage *img = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();

    return img;
}

+ (void)showPopControllerAlertWithTitle:(NSString *)title message:(NSString *)message
{
    [ARNAlert showNoActionAlertWithTitle:title message:message buttonTitle:nil];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [NSThread sleepForTimeInterval:1];
        dispatch_async(dispatch_get_main_queue(), ^{
            [[ARTViewContainer shared] popActiveNavController];
        });
    });
}

+ (UIView *)keyboardToolbarWithTarget:(id)target selector:(SEL)selector width:(float)width
{
    float sizeWidth = width;
    if (sizeWidth <= 320) {
        sizeWidth = 320;
    }

    UIView *toolBarView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, sizeWidth, 30)];
    toolBarView.backgroundColor = art_UIColorWithRGBA(250, 220, 200, 0.9);

    UIButton *cancelButton = [UIButton buttonWithType:UIButtonTypeSystem];
    [cancelButton setTitle:@"キーボードを閉じる" forState:UIControlStateNormal];
    cancelButton.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Thin" size:14];
    cancelButton.frame           = CGRectMake(sizeWidth - 140, 0, 140, 30);
    [cancelButton setTitleColor:art_UIColorWithRGBA(150, 150, 255, 1) forState:UIControlStateNormal];
    [cancelButton addTarget:target action:selector forControlEvents:UIControlEventTouchUpInside];
    [toolBarView addSubview:cancelButton];

    return toolBarView;
}

+ (NSString *)escapeString:(NSString *)aString
{
    return (__bridge_transfer NSString *)CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
        (CFStringRef)aString,
        NULL,
        (CFStringRef)@"!*'();:@&=+$,/?%#[]",
        kCFStringEncodingUTF8);
}

+ (void)setBaseButtonStyle:(UIButton *)button
{
    button.exclusiveTouch = YES;
    [button setBackgroundImage:[ARTUtils imageWithColor:ART_BaseColor_Orange] forState:UIControlStateNormal];
    [button setBackgroundImage:[ARTUtils imageWithColor:art_UIColorWithRGBA(243, 200, 200, 1)] forState:UIControlStateHighlighted];
    [button setBackgroundImage:[ARTUtils imageWithColor:ART_BaseColor_White] forState:UIControlStateSelected];
    [button setTitleColor:[UIColor grayColor] forState:UIControlStateSelected];
}

+ (void)setBaseButtonStyleGray:(UIButton *)button
{
    button.exclusiveTouch = YES;
    [button setBackgroundImage:[ARTUtils imageWithColor:ART_BaseColor_White] forState:UIControlStateNormal];
    [button setBackgroundImage:[ARTUtils imageWithColor:art_UIColorWithRGBA(243, 200, 200, 1)] forState:UIControlStateHighlighted];
    [button setBackgroundImage:[ARTUtils imageWithColor:ART_BaseColor_Orange] forState:UIControlStateSelected];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    //[button setTitleColor:[UIColor grayColor] forState:UIControlStateSelected];
    [button setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
}

+ (void)selectActionForView:(UIView *)view
{
    [UIView animateWithDuration:0.3
                     animations: ^{
         view.alpha = 0;
         view.alpha = 1;
     }];
}

// 正規表現チェック
+ (BOOL)checkRegex:(NSInteger)stringType string:(NSString *)checkString
{
    // todo : ちょっと急ごしらえだな。。精査・リファクタしたい
    if (stringType == 1) {
        // パスワードチェックの場合(半角英数以外をチェック)
        NSError             *error  = nil;
        NSRegularExpression *regexp = [NSRegularExpression regularExpressionWithPattern:@"[^a-zA-Z0-9]"
                                                                                options:0
                                                                                  error:&error];
        if (!error) {
            NSTextCheckingResult *match = [regexp firstMatchInString:checkString options:0 range:NSMakeRange(0, checkString.length)];
            // match.numberOfRangesが0以上の場合、指定文字以外の文字列が含まれている
            if (match.numberOfRanges > 0) {
                return NO;
            } else {
                return YES;
            }
        }
    } else if (stringType == 2) {
        // メールアドレスの場合(特殊文字や記号をチェック)
        NSString    *regex     = @"[a-zA-Z0-9!#$%&’*+/=?^_`{|}~-]+(?:\\.[a-zA-Z0-9!#$%&’*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?";
        NSPredicate *predicate = [NSPredicate predicateWithFormat:@"%@ MATCHES %@", checkString, regex];
        return [predicate evaluateWithObject:self];;
    }

    return NO;
}

+ (NSError *)uoErrorForDict:(NSDictionary *)dict
{
    [ARTAnalytics sendTrackWithCategoryName:@"API Error"
                                 actionName:dict[@"title"]
                                  labelName:dict[@"message"]
                                      value:@([ARTAnalytics dateToYYYYMMDDHHMM:[NSDate date]].integerValue)];

    return [NSError errorWithDomain:ARTErrorDomain
                               code:[dict[@"code"] integerValue]
                           userInfo:@{ NSLocalizedDescriptionKey: dict[@"title"],
                                       NSLocalizedFailureReasonErrorKey: dict[@"message"] }];
}

+ (NSError *)errorFOrType:(ARTErrorType)type
{
    switch (type) {
        case ARTErrorTypeUONotReachable:
        {
            NSDictionary *info = @{ NSLocalizedDescriptionKey: @"ネットワークエラー",
                                    NSLocalizedFailureReasonErrorKey: @"通信が行えません\n通信が行える状態になってから再度操作して下さい" };
            return [NSError errorWithDomain:ARTErrorDomain code:7001 userInfo:info];
        }

        case ARTErrorTypeUOParametorError:
        {
            NSDictionary *info = @{ NSLocalizedDescriptionKey: @"システムエラー",
                                    NSLocalizedFailureReasonErrorKey: @"パラメータエラー(7002)" };
            return [NSError errorWithDomain:ARTErrorDomain code:7002 userInfo:info];
        }

        case ARTErrorTypeUOUserCreate:
        {
            NSDictionary *info = @{ NSLocalizedDescriptionKey: @"アカウント登録失敗",
                                    NSLocalizedFailureReasonErrorKey: @"お手数ですが、やり直して下さい" };
            return [NSError errorWithDomain:ARTErrorDomain code:7003 userInfo:info];
        }

        case ARTErrorTypeUOLogin:
        {
            NSDictionary *info = @{ NSLocalizedDescriptionKey: @"ログイン失敗",
                                    NSLocalizedFailureReasonErrorKey: @"お手数ですが、やり直して下さい" };
            return [NSError errorWithDomain:ARTErrorDomain code:7004 userInfo:info];
        }

        case ARTErrorTypeUOChangeNotis:
        {
            NSDictionary *info = @{ NSLocalizedDescriptionKey: @"設定更新失敗",
                                    NSLocalizedFailureReasonErrorKey: @"お手数ですが、やり直して下さい" };
            return [NSError errorWithDomain:ARTErrorDomain code:7005 userInfo:info];
        }

        case ARTErrorTypeNeedLogin:
        {
            NSDictionary *info = @{ NSLocalizedDescriptionKey: @"",
                                    NSLocalizedFailureReasonErrorKey: @"ログイン、\nまたはユーザー登録してから\nお使いいただけます" };
            return [NSError errorWithDomain:ARTErrorDomain code:7006 userInfo:info];
        }

        default:
            break;
    }
    return nil;
}

+ (void)addNotisForName:(NSString *)name block:(void (^)(NSNotification *note))block
{
    [[NSNotificationCenter defaultCenter] addObserverForName:name
                                                      object:nil
                                                       queue:[NSOperationQueue mainQueue]
                                                  usingBlock:block];
}

@end
