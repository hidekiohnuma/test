//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

@interface ARTUserManager : NSObject

+ (instancetype)shared;

// Create User
- (void)createUserByFacebockWithCompletionBlock:(ARTCompletionBlock)completionBlock;
- (void)createUserByTwitterWithCompletionBlock:(ARTCompletionBlock)completionBlock;
- (void)createUserWithEmail:(NSString *)email
                   password:(NSString *)password
            completionBlock:(ARTCompletionBlock)completionBlock;

// Login User
- (void)loginUserByFacebockWithCompletionBlock:(ARTCompletionBlock)completionBlock;
- (void)loginUserByTwitterWithCompletionBlock:(ARTCompletionBlock)completionBlock;
- (void)loginUserWithEmail:(NSString *)email
                  password:(NSString *)password
           completionBlock:(ARTCompletionBlock)completionBlock;

- (void)initialSetting;

- (void)logout;

- (NSNumber *)userId;

- (BOOL)isLogined;

@end
