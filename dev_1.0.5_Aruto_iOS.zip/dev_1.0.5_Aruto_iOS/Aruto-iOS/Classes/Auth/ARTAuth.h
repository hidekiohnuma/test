//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface ARTAuth : NSObject

// Facebook
- (void)authFacebookWithSuccessBlock:(ARTSuccessBlock)successBlock
                        failureBlock:(ARTFailureBlock)failureBlock;

// Twitter
- (void)authTwitterWithSuccessBlock:(ARTSuccessBlock)successBlock
                       failureBlock:(ARTFailureBlock)failureBlock;

@end
