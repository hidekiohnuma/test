//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTAuth.h"

#import <FBConnect.h>

@interface ARTAuth () <FBSessionDelegate>

@property (nonatomic, strong) Facebook     *facebook;
@property (nonatomic, copy) ARTSuccessBlock fbSuccessBlock;
@property (nonatomic, copy) ARTFailureBlock fbFailureBlock;

@property (nonatomic, assign) BOOL isFbConnecting;

@end

@import Accounts;

@implementation ARTAuth

- (instancetype)init
{
    if (!(self = [super init])) { return nil; }

    __weak typeof(self) weakSelf = self;

    [[NSNotificationCenter defaultCenter] addObserverForName:ARTFacebookCutsomURLSchemeNotification
                                                      object:nil
                                                       queue:[NSOperationQueue mainQueue]
                                                  usingBlock:
     ^(NSNotification *note) {
         NSURL *url = note.userInfo[@"url"];
         [weakSelf.facebook handleOpenURL:url];
     }];

    [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidBecomeActiveNotification
                                                      object:nil
                                                       queue:[NSOperationQueue mainQueue]
                                                  usingBlock: ^(NSNotification *note) {
         weakSelf.facebook = nil;
         if (weakSelf.fbFailureBlock && weakSelf.isFbConnecting) {
             weakSelf.isFbConnecting = NO;
             NSString *msg = @"\nFacebook認証に失敗しました";
             NSError *error = [NSError errorWithDomain:ARTErrorDomain
                                                  code:7010
                                              userInfo:@{ NSLocalizedDescriptionKey: @"Facebook認証失敗",
                                                          NSLocalizedFailureReasonErrorKey: msg }];
             art_SafeBlockCall(weakSelf.fbFailureBlock, error);
         }
     }];

    return self;
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Facebook

- (void)authFacebookWithSuccessBlock:(ARTSuccessBlock)successBlock
                        failureBlock:(ARTFailureBlock)failureBlock
{
    if (!self.facebook) {
        self.facebook = [[Facebook alloc] initWithAppId:@"261467434039492" andDelegate:self];
    }
    self.isFbConnecting = YES;
    self.fbSuccessBlock = successBlock;
    self.fbFailureBlock = failureBlock;
    [self.facebook authorize:nil];
}

- (void)userData
{
    LOG_METHOD;
    self.isFbConnecting = NO;
    FBRequest *request = [FBRequest requestForGraphPath:@"me"];
    request.session = self.facebook.session;
    
    __weak typeof(self) weakSelf = self;
    
    [request startWithCompletionHandler: ^(FBRequestConnection *connection, id result, NSError *error) {
        if (error) {
            LOG(@"error:%@", error);
            art_SafeBlockCall(weakSelf.fbFailureBlock, error);
        } else {
            LOG(@"result:%@", result);
            NSDictionary *resultDict = (NSDictionary *)result;
            
            art_SafeBlockCall(weakSelf.fbSuccessBlock, resultDict);
        }
    }];
}

- (NSError *)facebookAuthError
{
    NSString *msg   = @"\nアプリがFacebookのアカウントにアクセスするのを許可するよう設定してください";
    NSError  *error = [NSError errorWithDomain:ARTErrorDomain
                                          code:7011
                                      userInfo:@{ NSLocalizedDescriptionKey: @"Facebook認証失敗",
                                                  NSLocalizedFailureReasonErrorKey: msg }];
    return error;
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - FBSession Delegate

/**
 * Called when the user dismissed the dialog without logging in.
 */
- (void)fbDidNotLogin:(BOOL)cancelled
{
    LOG_METHOD;
    self.isFbConnecting = NO;
    art_SafeBlockCall(self.fbFailureBlock, [self facebookAuthError]);
}

/**
 * Called when the user successfully logged in.
 */
- (void)fbDidLogin
{
    LOG_METHOD;
    self.isFbConnecting = NO;
    [self userData];
}

/**
 * Called after the access token was extended. If your application has any
 * references to the previous access token (for example, if your application
 * stores the previous access token in persistent storage), your application
 * should overwrite the old access token with the new one in this method.
 * See extendAccessToken for more details.
 */
- (void)fbDidExtendToken:(NSString *)accessToken
               expiresAt:(NSDate *)expiresAt
{
    LOG_METHOD;
    self.isFbConnecting = NO;
    art_SafeBlockCall(self.fbFailureBlock, [self facebookAuthError]);
}

/**
 * Called when the user logged out.
 */
- (void)fbDidLogout
{
    LOG_METHOD;
    self.isFbConnecting = NO;
    art_SafeBlockCall(self.fbFailureBlock, [self facebookAuthError]);
}

/**
 * Called when the current session has expired. This might happen when:
 *  - the access token expired
 *  - the app has been disabled
 *  - the user revoked the app's permissions
 *  - the user changed his or her password
 */
- (void)fbSessionInvalidated
{
    LOG_METHOD;
    self.isFbConnecting = NO;
    art_SafeBlockCall(self.fbFailureBlock, [self facebookAuthError]);
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Twitter

- (void)authTwitterWithSuccessBlock:(ARTSuccessBlock)successBlock
                       failureBlock:(ARTFailureBlock)failureBlock
{
    ACAccountStore *acStore            = [[ACAccountStore alloc] init];
    ACAccountType  *twitterAccountType = [acStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];

    [acStore requestAccessToAccountsWithType:twitterAccountType
                                     options:NULL
                                  completion:
     ^(BOOL granted, NSError *error) {
         if (error) {
             LOG(@"%@", error.description);
             dispatch_async(dispatch_get_main_queue(), ^{
                     art_SafeBlockCall(failureBlock, error);
                 });
             return;
         }
         if (granted) {
             NSArray *twitterAccounts = [acStore accountsWithAccountType:twitterAccountType];
             if (twitterAccounts.count == 0) {
                 // Twitterアカウント設定が１つもない
                 LOG(@"Twitterアカウント設定が１つもない");
                 dispatch_async(dispatch_get_main_queue(), ^{
                         NSString *msg = @"\nTwitterアカウントがみつかりませんでした";
                         NSError *error = [NSError errorWithDomain:ARTErrorDomain
                                                              code:7010
                                                          userInfo:@{ NSLocalizedDescriptionKey: @"Twitter認証失敗",
                                                                      NSLocalizedFailureReasonErrorKey: msg }];
                         art_SafeBlockCall(failureBlock, error);
                     });
             } else {
                 // Twitterアカウント設定が１つまたは複数（最初のを使う）
                 ACAccount *twitterAccount = twitterAccounts.firstObject;
                 //LOG(@"twitterAccount : %@", twitterAccount);
                 NSString *userID = [twitterAccount valueForKeyPath:@"properties.user_id"];
                 // 裏通信が続くからこのままでよい
                 art_SafeBlockCall(successBlock, userID);
             }
         } else {
             // 認証失敗
             LOG(@"認証失敗");
             dispatch_async(dispatch_get_main_queue(), ^{
                     NSString *msg = @"\n設定を開き、プライバシー > Twitterから、アプリがTwitterアカウントにアクセスするのを許可して下さい";
                     NSError *error = [NSError errorWithDomain:ARTErrorDomain
                                                          code:7011
                                                      userInfo:@{ NSLocalizedDescriptionKey: @"Twitter認証失敗",
                                                                  NSLocalizedFailureReasonErrorKey: msg }];
                     art_SafeBlockCall(failureBlock, error);
                 });
         }
     }];
}

@end
