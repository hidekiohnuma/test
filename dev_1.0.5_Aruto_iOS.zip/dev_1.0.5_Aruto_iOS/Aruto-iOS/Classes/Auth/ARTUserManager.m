//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTUserManager.h"

#import "ARTAuth.h"
#import "ARTUserUO.h"
#import <ARNDeferred.h>

@interface ARTUserManager ()

@property (nonatomic, strong) ARTAuth *socialAuth;
@property (nonatomic, copy) NSNumber  *cacheUserId;

@end

@implementation ARTUserManager

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Singleton

+ (instancetype)shared
{
    static ARTUserManager *_shared = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
            _shared = [[ARTUserManager alloc] initWithSingleton];
        });

    return _shared;
}

- (instancetype)initWithSingleton
{
    if (!(self = [super init])) { return nil; }

    self.socialAuth = [[ARTAuth alloc] init];

    return self;
}

- (instancetype)init
{
    [self doesNotRecognizeSelector:_cmd];
    return nil;
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Create

- (void)createUserByFacebockWithCompletionBlock:(ARTCompletionBlock)completionBlock
{
    __weak typeof(self) weakSelf = self;

    [self.socialAuth authFacebookWithSuccessBlock: ^(id resultObject) {
         NSDictionary *userDict = (NSDictionary *)resultObject;
         NSString *facebookId = userDict[@"id"];

         [ARTUserUO uoCreateUserWithTarget:weakSelf
                                facebookId:facebookId
                           completionBlock:completionBlock];
     } failureBlock: ^(NSError *error) {
         art_SafeBlockCall(completionBlock, error);
     }];
}

- (void)createUserByTwitterWithCompletionBlock:(ARTCompletionBlock)completionBlock
{
    __weak typeof(self) weakSelf = self;

    [self.socialAuth authTwitterWithSuccessBlock: ^(id resultObject) {
         LOG(@"twitterID : %@", resultObject);
         [ARTUserUO uoCreateUserWithTarget:weakSelf
                                 twitterId:resultObject
                           completionBlock:completionBlock];
     } failureBlock: ^(NSError *error) {
         art_SafeBlockCall(completionBlock, error);
     }];
}

- (void)createUserWithEmail:(NSString *)email
                   password:(NSString *)password
            completionBlock:(ARTCompletionBlock)completionBlock
{
    [ARTUserUO uoCreateUserWithTarget:self
                                email:email
                             password:password
                      completionBlock:completionBlock];
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Login

- (void)loginUserByFacebockWithCompletionBlock:(ARTCompletionBlock)completionBlock
{
    __weak typeof(self) weakSelf = self;

    [self.socialAuth authFacebookWithSuccessBlock: ^(id resultObject) {
         NSDictionary *userDict = (NSDictionary *)resultObject;
         NSString *facebookId = userDict[@"id"];

         [ARTUserUO uoLoginUserWithTarget:weakSelf
                               facebookId:facebookId
                          completionBlock:completionBlock];
     } failureBlock: ^(NSError *error) {
         art_SafeBlockCall(completionBlock, error);
     }];
}

- (void)loginUserByTwitterWithCompletionBlock:(ARTCompletionBlock)completionBlock
{
    __weak typeof(self) weakSelf = self;

    [self.socialAuth authTwitterWithSuccessBlock: ^(id resultObject) {
         LOG(@"twitterID : %@", resultObject);
         [ARTUserUO uoLoginUserWithTarget:weakSelf
                                twitterId:resultObject
                          completionBlock:completionBlock];
     } failureBlock: ^(NSError *error) {
         art_SafeBlockCall(completionBlock, error);
     }];
}

- (void)loginUserWithEmail:(NSString *)email
                  password:(NSString *)password
           completionBlock:(ARTCompletionBlock)completionBlock
{
    [ARTUserUO uoLoginUserWithTarget:self
                               email:email
                            password:password
                     completionBlock:completionBlock];
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Other

- (void)initialSetting
{
    if (![ARTUserDefaults shared].uuid) {
        NSUUID *uuid = [NSUUID UUID];
        [ARTUserDefaults shared].uuid = uuid.UUIDString;
    }
    
    if (![ARTUserDefaults shared].deviceToken) {
        [ARTUserDefaults shared].deviceToken = @"nothing";
    }
}

- (void)logout
{
    [User art_deleteAllEntiteis];
    [FavoriteShop art_deleteAllEntiteis];
    [FavoriteStaff art_deleteAllEntiteis];
    [Entry art_deleteAllEntiteis];
    [EntryMessage art_deleteAllEntiteis];
    self.cacheUserId = nil;
    [[NSNotificationCenter defaultCenter] postNotificationName:ARTNofiricationLogouted object:nil userInfo:nil];
}

- (NSNumber *)userId
{
    if (!self.cacheUserId) {
        self.cacheUserId = [User art_userId];
    }
    return self.cacheUserId;
}

- (BOOL)isLogined
{
    if ([User art_userId]) {
        return YES;
    } else {
        return NO;
    }
}

@end
