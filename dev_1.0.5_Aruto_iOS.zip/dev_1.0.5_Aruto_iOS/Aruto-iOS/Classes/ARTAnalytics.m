//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTAnalytics.h"

#import <GAI.h>
#import <GAIDictionaryBuilder.h>
#import <GAIFields.h>
#import <GAITracker.h>

#import <Flurry.h>

static NSString *gaTrackingId_ = nil;
static NSString *flurryAppId_  = nil;

@implementation ARTAnalytics

+ (void)setupWithGATrackingId:(NSString *)trackingId;
{
    if (!trackingId) { return; }

    gaTrackingId_ = trackingId;

    [GAI sharedInstance].trackUncaughtExceptions = YES;
    [GAI sharedInstance].dispatchInterval        = 20;
    [[GAI sharedInstance].logger setLogLevel:kGAILogLevelVerbose];
    [[GAI sharedInstance] trackerWithTrackingId:gaTrackingId_];
}

+ (void)setupFlurryWithAppId:(NSString *)appId
{
    if (!appId) { return; }

    flurryAppId_ = appId;

    [Flurry setCrashReportingEnabled:YES];
    [Flurry startSession:flurryAppId_];
    [Flurry logEvent:@"start_app"];
}

+ (void)sendGAScreenName:(NSString *)screenName
{
    if (!gaTrackingId_) { return; }

    [[GAI sharedInstance].defaultTracker set:kGAIScreenName value:screenName];
    [[GAI sharedInstance].defaultTracker send:[[GAIDictionaryBuilder createAppView] build]];
}

+ (void)sendTrackWithCategoryName:(NSString *)categoryName
                       actionName:(NSString *)actionName
                        labelName:(NSString *)labelName
                            value:(NSNumber *)value
{
    if (gaTrackingId_) {
        GAIDictionaryBuilder *builder = [GAIDictionaryBuilder createEventWithCategory:categoryName
                                                                               action:actionName
                                                                                label:labelName
                                                                                value:value];
        id <GAITracker> tracker = [[GAI sharedInstance] defaultTracker];
        [tracker send:[builder build]];
    }

    if (flurryAppId_) {
        [Flurry logEvent:actionName];
    }
}

+ (NSString *)dateToYYYYMMDDHHMM:(NSDate *)aDate
{
    NSDate *beforeDate = aDate;
    if (!beforeDate) {
        beforeDate = [NSDate date];
    }

    NSCalendar       *cal        = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [cal components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSHourCalendarUnit | NSMinuteCalendarUnit) fromDate:beforeDate];
    NSDate           *date       = [cal dateFromComponents:components];

    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setLocale:[NSLocale currentLocale]];
    [formatter setTimeZone:[NSTimeZone localTimeZone]];
    [formatter setCalendar:[[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar]];

    [formatter setDateFormat:@"yyyyMMddHHmm"];
    return [formatter stringFromDate:date];
}

@end
