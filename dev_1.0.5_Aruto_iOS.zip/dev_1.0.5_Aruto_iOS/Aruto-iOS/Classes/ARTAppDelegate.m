//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTAppDelegate.h"

#import <Crittercism.h>
#import <ARNPush.h>

@implementation ARTAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    //[[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    
    [UINavigationBar appearance].barTintColor = art_UIColorWithRGBA(229, 138, 0, 1);
    [UINavigationBar appearance].tintColor = [UIColor whiteColor];
    [UINavigationBar appearance].titleTextAttributes = @{NSForegroundColorAttributeName : [UIColor whiteColor],
                                                         NSFontAttributeName : [UIFont fontWithName:@"HiraKakuProN-W6" size:19]};
    
    NSString *appVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleVersion"];
    if (![appVersion isEqualToString:[ARTUserDefaults shared].currentVersion]) {
        [ARTUserDefaults shared].currentVersion = appVersion;
        [ARTImageCashe clearImageCache];
    }
    
    [ARTCoreDataFetcher setUp];
    [ARTCoreDataFetcher cleanData];
    [[ARTUOCacheManager shared] clear];
    [[SDImageCache sharedImageCache] cleanDisk];
    [[ARTUserManager shared] initialSetting];
    
    // アナリティクス・開発は疎通確認できたから切ってる
#ifdef RELEASE
    [ARTAnalytics setupWithGATrackingId:@"UA-52790302-1"];
    [ARTAnalytics setupFlurryWithAppId:@"56DQPC3TPPYRRZTPM2BF"];
#else
//  [ARTAnalytics setupWithGATrackingId:@"UA-52790302-2"];
//  [ARTAnalytics setupFlurryWithAppId:@"W6FFQ4TW695FGMWT589F"];
#endif
    
    // クラッシュログ収集
    // Releaseビルドのみ実行
#ifdef RELEASE
    [Crittercism enableWithAppID:@"53d2140ad478bc36ef000002"];
#endif
    
    _rootController            = [[ARTViewContainer alloc] init];
    self.window                = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor    = [UIColor blackColor];
    self.window.rootViewController = _rootController;
    [self.window makeKeyAndVisible];
    
    [_rootController initialSetting];
    
    // アプリがバックグラウンドになっても延命(10分)
    __block UIBackgroundTaskIdentifier bgTask = [application beginBackgroundTaskWithExpirationHandler: ^{
        [application endBackgroundTask:bgTask];
        bgTask = UIBackgroundTaskInvalid;
    }];
    
    // Push通知用設定
    [ARNPush setDeviceTokenBlock:^(NSString *deviceToken, NSError *error) {
        if (error) {
            LOG(@"didFailToRegisterForRemoteNotificationsWithError: %@", error);
            return;
        }
        LOG(@"deviceTokenString : %@", deviceToken);
        [[ARTTaskManager shared] updateDeviceTokenTaskWithDeviceTokenString:deviceToken retryCount:0];
    }];
    
    __weak typeof(self) weakSelf = self;
    
    [ARNPush setAlertBlock:^(NSDictionary *userInfo) {
        LOG(@"remote notification: %@", [userInfo description]);
        
        // ログインしていないユーザーへは通知しない
        if (![ARTUserManager shared].isLogined) {
            return;
        }
        
        NSDictionary *apsInfo = userInfo[@"aps"];
        NSString     *alert   = apsInfo[@"alert"];
        
        NSNumber *notisType = [ARTUtils nullCheckWithObject:userInfo[@"notis_type"] isNumeric:YES];
        User *entity = [User art_userForLocalContext:nil];
        if (notisType.intValue == 1) {
            if (!entity.notificationForYouflg.boolValue) {
                return;
            }
        } else if (notisType.intValue == 2) {
            if (!entity.notificationForAllflg.boolValue) {
                return;
            }
        }
        
        [ARNAlert showAlertWithTitle:@"Aruto"
                            message:alert
                  cancelButtonTitle:@"キャンセル"
                        cancelBlock:^(id action) {}
                      okButtonTitle:@"見てみる"
                            okBlock:^(id action) {
                                if (notisType.intValue == 1) {
                                    // メッセージ
                                    NSNumber *entryId = [ARTUtils nullCheckWithObject:userInfo[@"entry_id"] isNumeric:YES];
                                    if (!entryId) {
                                        [ARNAlert showNoActionAlertWithTitle:nil
                                                                     message:@"応募情報を取得出来ませんでした"
                                                                 buttonTitle:nil];
                                    } else {
                                        [[ARTViewContainer shared] showPushMessageViewForEntryId:entryId];
                                        [weakSelf updateBadgeNum:0];
                                    }
                                } else if (notisType.intValue == 2) {
                                    // お知らせ
                                    [[ARTViewContainer shared] showPushNotisView];
                                }
                            }];
        
    }];
    
    [ARNPush setBadgeBlock:^(NSDictionary *userInfo) {
        NSDictionary *apsInfo  = userInfo[@"aps"];
        NSString     *badge    = [ARTUtils nullCheckWithObject:apsInfo[@"badge"] isNumeric:YES];
        NSUInteger    badgeNum = [badge integerValue];
        
        [weakSelf updateBadgeNum:badgeNum];
    }];
    
    [ARNPush registerForTypes:(UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)
                launchOptions:launchOptions
                   categories:nil];
    
    // アプリ起動時にはバッジの数を初期化（バッジを0にして非表示）する
    [self updateBadgeNum:0];
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // アプリ起動時にはバッジの数を初期化（バッジを0にして非表示）する
    [self updateBadgeNum:0];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    [ARTCoreDataFetcher cleanUp];
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - Custome URL Scheme

- (BOOL)  application:(UIApplication *)application
              openURL:(NSURL *)url
    sourceApplication:(NSString *)sourceApplication
           annotation:(id)annotation
{
    if ([url.absoluteString hasPrefix:ARTFacebookCutsomURLScheme]) {
        [[NSNotificationCenter defaultCenter] postNotificationName:ARTFacebookCutsomURLSchemeNotification
                                                            object:nil
                                                          userInfo:@{ @"url": url }];
        return YES;
    }
    
    return NO;
}

// -----------------------------------------------------------------------------------------------------------------------//
#pragma mark - Push Notification

// プッシュ通知受信
- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
#ifdef DEBUG
    NSAssert(NO, @"no call didReceiveRemoteNotification. call ARNPush");
#endif
}

- (void)updateBadgeNum:(NSUInteger)badgeNum
{
    if (badgeNum <= 0) {
        ARTUserDefaults.shared.iconBadgeCount = 0;
    } else {
        ARTUserDefaults.shared.iconBadgeCount += badgeNum;
    }
    
    [UIApplication sharedApplication].applicationIconBadgeNumber = ARTUserDefaults.shared.iconBadgeCount;
}

@end
