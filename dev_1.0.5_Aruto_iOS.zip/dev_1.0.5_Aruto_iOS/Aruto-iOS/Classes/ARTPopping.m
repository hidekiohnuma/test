//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTPopping.h"
#import <POP/POP.h>

@implementation ARTPopping

+ (void)scaleAnimationWithView:(UIView *)view
{
    POPSpringAnimation *scaleAnimation = [POPSpringAnimation animationWithPropertyNamed:kPOPLayerScaleXY];
    scaleAnimation.velocity         = [NSValue valueWithCGSize:CGSizeMake(3.f, 3.f)];
    scaleAnimation.toValue          = [NSValue valueWithCGSize:CGSizeMake(1.f, 1.f)];
    scaleAnimation.springBounciness = 18.0f;
    [view.layer pop_addAnimation:scaleAnimation forKey:@"layerScaleSpringAnimation"];
}

+ (void)scale2AnimationWithView:(UIView *)view
{
    POPSpringAnimation *scaleAnimation = [POPSpringAnimation animationWithPropertyNamed:kPOPLayerScaleX];
    scaleAnimation.velocity         = [NSValue valueWithCGSize:CGSizeMake(3.f, 3.f)];
    scaleAnimation.toValue          = [NSValue valueWithCGSize:CGSizeMake(1.f, 1.f)];
    scaleAnimation.springBounciness = 10.0f;
    [view.layer pop_addAnimation:scaleAnimation forKey:@"layerScaleSpringAnimation"];
}

+ (void)zoomAnimationWithView:(UIView *)view
{
    POPSpringAnimation *scaleAnimation = [POPSpringAnimation animationWithPropertyNamed:kPOPLayerScaleXY];
    scaleAnimation.velocity  = [NSValue valueWithCGSize:CGSizeMake(3.f, 3.f)];
    scaleAnimation.fromValue = [NSValue valueWithCGSize:CGSizeMake(1.1f, 1.1f)];
    scaleAnimation.toValue   = [NSValue valueWithCGSize:CGSizeMake(1.0f, 1.0f)];
    [view.layer pop_addAnimation:scaleAnimation forKey:@"layerScaleSpringAnimation"];
}

+ (void)poppinAnimationWithView:(UIView *)view
{
    POPSpringAnimation *scaleAnimation = [POPSpringAnimation animationWithPropertyNamed:kPOPLayerScaleXY];
    scaleAnimation.fromValue        = [NSValue valueWithCGPoint:CGPointMake(1.2, 1.2)];
    scaleAnimation.toValue          = [NSValue valueWithCGSize:CGSizeMake(1.0f, 1.0f)];
    scaleAnimation.springBounciness = 10.0f;
    [view.layer pop_addAnimation:scaleAnimation forKey:@"layerScaleSpringAnimation"];
}

+ (void)shakeAnimationWithView:(UIView *)view
{
    POPSpringAnimation *positionAnimation = [POPSpringAnimation animationWithPropertyNamed:kPOPLayerPositionX];
    positionAnimation.velocity         = @2000;
    positionAnimation.springBounciness = 20;
    [positionAnimation setCompletionBlock: ^(POPAnimation *animation, BOOL finished) {
         view.userInteractionEnabled = YES;
     }];
    [view.layer pop_addAnimation:positionAnimation forKey:@"positionAnimation"];
}

@end
