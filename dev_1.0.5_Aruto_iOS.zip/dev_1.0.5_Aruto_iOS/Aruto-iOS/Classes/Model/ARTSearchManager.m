//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSearchManager.h"

#import "ARTSearchUO.h"
#import "ARTSearchData.h"

@interface ARTSearchManager ()

@property (nonatomic, strong) ARTSearchData *searchData;
@property (nonatomic, strong) ARTSearchData *tempSearchData;

@end

@implementation ARTSearchManager

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Singleton

+ (instancetype)shared
{
    static ARTSearchManager *_shared = nil;
    static dispatch_once_t   onceToken;
    dispatch_once(&onceToken, ^{
            _shared = [[ARTSearchManager alloc] initWithSingleton];
        });

    return _shared;
}

- (instancetype)initWithSingleton
{
    if (!(self = [super init])) { return nil; }

    [self allClear];

    return self;
}

- (instancetype)init
{
    [self doesNotRecognizeSelector:_cmd];
    return nil;
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Search Data

- (void)allClear
{
    self.isSearched        = NO;
    self.isModal           = NO;
    self.searchIndentifier = nil;
    self.totalCount        = 0;

    self.searchData     = nil;
    self.tempSearchData = nil;
}

- (void)recoveryTempData
{
    self.tempSearchData = [self.searchData copy];
}

- (void)clearTempData
{
    self.tempSearchData = nil;
}

- (ARTSearchData *)currentSearchData
{
    if (!self.tempSearchData) {
        self.tempSearchData = ARTSearchData.new;
        [self.tempSearchData resetData];
    }
    return self.tempSearchData;
}

- (void)clearMultipleSelect
{
    ARTSearchData *searchData = [self currentSearchData];
    [searchData resetMultipleSelect];
}

- (NSString *)searchWord
{
    ARTSearchData *searchData = [self currentSearchData];
    return searchData.searchWord;
}

- (void)setSearchWord:(NSString *)searchWord
{
    ARTSearchData *searchData = [self currentSearchData];
    searchData.searchWord = searchWord;
}

- (BOOL)checkSearchItems
{
    if (![self searchWord] &&
        ![self selectDataWithSearchType:ARTSearchTypeBirthPlaceArea] &&
        ![self selectDataWithSearchType:ARTSearchTypeWorkPlaceCity] &&
        ![self selectDataWithSearchType:ARTSearchTypeJobType] &&
        ![self selectDataWithSearchType:ARTSearchTypeAge] &&
        ![self selectDataWithSearchType:ARTSearchTypeSex] &&
        ![self selectDataWithSearchType:ARTSearchTypeHobby] &&
        ![self selectDataWithSearchType:ARTSearchTypeFutureGoal] &&
        ![self selectDataWithSearchType:ARTSearchTypeSalaryHourType] &&
        ![self selectDataWithSearchType:ARTSearchTypeJobOtherOption] &&
        ![self selectDataWithSearchType:ARTSearchTypeWorkDayType] &&
        ![self selectDataWithSearchType:ARTSearchTypeSchool] &&
        ![self selectDataWithSearchType:ARTSearchTypeTrainStation]) {
        return NO;
    }
    return YES;
}

- (void)startSearchForFirst:(BOOL)isFirst
{
    if (![self checkSearchItems]) {
        [ARNAlert showNoActionAlertWithTitle:nil
                                     message:@"検索項目が選択されていません"
                                 buttonTitle:nil];
        return;
    }

    self.totalCount  = 0;
    if (isFirst) {
        self.isSearched = NO;
    }
    self.searchData = [self.tempSearchData copy];

    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeClear];
    NSUUID *uuid = [NSUUID UUID];
    self.searchIndentifier = uuid.UUIDString;
    LOG(@"searchIndentifier : %@", self.searchIndentifier);
    __weak typeof(self) weakSelf = self;

    [ARTSearchUO uoGetSearchListWithTarget:self
                                     index:0
                           completionBlock: ^(id resultObject) {
         [SVProgressHUD dismiss];

         if ([resultObject isKindOfClass:[NSError class]]) {
             NSError *error = (NSError *)resultObject;
             [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                          message:error.localizedFailureReason
                                      buttonTitle:@"OK"];
         } else {
             if (weakSelf.isModal) {
                 if (!weakSelf.isSearched) {
                     [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory searchResultViewController]];
                 }
                 [[ARTViewContainer shared] closeModalViewWithAnimationBlock: ^(id container) {
                  } completionBlock: ^(id container) {
                      if (weakSelf.isSearched) {
                          [[ARTViewContainer shared] tabViewisShow:YES];
                          [ARTSearchManager shared].isModal = NO;
                      }
                  }];
             } else {
                 [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory searchResultViewController]];
             }
         }
         weakSelf.isSearched = YES;
         [[NSNotificationCenter defaultCenter] postNotificationName:ARTNofiricationSearched object:nil];
     }];
}

- (void)startMoreLoadWithCompletionBlock:(void (^)())completionBlock
                                   index:(NSInteger)index
{
    [ARTSearchUO uoGetSearchListWithTarget:self
                                     index:index
                           completionBlock:completionBlock];
}

- (NSString *)headerTitleWithType:(ARTSearchType)searchType
{
    switch (searchType) {
        case ARTSearchTypeSelectOptionType:
            return @"検索条件";

        case ARTSearchTypeBirthPlaceArea:
            return @"出身地(地域)";

        case ARTSearchTypeBirthPlacePrefecture:
            return @"出身地(都道府県)";

        case ARTSearchTypeWorkPlaceArea:
            return @"勤務地(地域)";

        case ARTSearchTypeWorkPlacePrefecture:
            return @"勤務地(都道府県)";

        case ARTSearchTypeWorkPlaceCity:
            return @"勤務地(市区町村)";

        case ARTSearchTypeJobTypeCategory:
            return @"職種タイプ";

        case ARTSearchTypeJobType:
            return @"職種";

        case ARTSearchTypeJobOtherOption:
            return @"こだわり";

        case ARTSearchTypeAge:
            return @"年代";

        case ARTSearchTypeSex:
            return @"性別";

        case ARTSearchTypeHobbyType:
            return @"趣味タイプ";

        case ARTSearchTypeHobby:
            return @"趣味";

        case ARTSearchTypeFutureGoal:
            return @"夢・目標";

        case ARTSearchTypeSalaryHourType:
            return @"時給";

        case ARTSearchTypeWorkDayType:
            return @"日給";

        case ARTSearchTypeSchoolType:
            return @"学校タイプ";

        case ARTSearchTypeSchool:
            return @"学校";

        case ARTSearchTypeTrainLine:
            return @"路線";

        case ARTSearchTypeTrainStation:
            return @"駅";

        default:
            break;
    }
    return nil;
}

- (BOOL)isDispButtonViewWithType:(ARTSearchType)type
{
    if (type == ARTSearchTypeBirthPlaceArea ||
        type == ARTSearchTypeWorkPlaceArea ||
        type == ARTSearchTypeWorkPlacePrefecture ||
        type == ARTSearchTypeJobTypeCategory ||
        type == ARTSearchTypeHobbyType ||
        type == ARTSearchTypeTrainLine) {
        return NO;
    } else {
        return YES;
    }
}

- (BOOL)isMultipleSelectWithSearchType:(ARTSearchType)type
{
    switch (type) {
        case ARTSearchTypeSelectOptionType:
            return NO;

        case ARTSearchTypeBirthPlaceArea:
            return NO;

        case ARTSearchTypeBirthPlacePrefecture:
            return YES;

        case ARTSearchTypeWorkPlaceArea:
            return NO;

        case ARTSearchTypeWorkPlacePrefecture:
            return NO;

        case ARTSearchTypeWorkPlaceCity:
            return YES;

        case ARTSearchTypeJobTypeCategory:
            return NO;

        case ARTSearchTypeJobType:
            return YES;

        case ARTSearchTypeJobOtherOption:
            return YES;

        case ARTSearchTypeAge:
            return YES;

        case ARTSearchTypeSex:
            return YES;

        case ARTSearchTypeHobbyType:
            return NO;

        case ARTSearchTypeHobby:
            return YES;

        case ARTSearchTypeFutureGoal:
            return YES;

        case ARTSearchTypeSalaryHourType:
            return NO;

        case ARTSearchTypeWorkDayType:
            return NO;

        case ARTSearchTypeSchoolType:
            return NO;

        case ARTSearchTypeSchool:
            return NO;

        case ARTSearchTypeTrainLine:
            return NO;

        case ARTSearchTypeTrainStation:
            return YES;

        default:
            break;
    }
    return NO;
}

- (BOOL)isNeedPushWithSearchType:(ARTSearchType)type
{
    if (type == ARTSearchTypeBirthPlaceArea ||
        type == ARTSearchTypeWorkPlaceArea ||
        type == ARTSearchTypeWorkPlacePrefecture ||
        type == ARTSearchTypeJobTypeCategory ||
        type == ARTSearchTypeHobbyType ||
        type == ARTSearchTypeTrainLine) {
        return YES;
    } else {
        return NO;
    }
}

- (NSArray *)dataWithSearchType:(ARTSearchType)type
{
    ARTSearchData *searchData = [self currentSearchData];

    switch (type) {
        case ARTSearchTypeSelectOptionType:
            return nil;

        case ARTSearchTypeBirthPlaceArea:
            return [Area art_allNonDeleteEntiteis];

        case ARTSearchTypeBirthPlacePrefecture:
            return [Prefecture art_allEntiteisByAreaId:@(searchData.selectBirthPlaceArea.intValue)];

        case ARTSearchTypeWorkPlaceArea:
            return [Area art_allNonDeleteEntiteis];

        case ARTSearchTypeWorkPlacePrefecture:
            // todo : 今だけ暫定対応（関東）
            return [Prefecture art_allEntiteisForFirstApp];
        //return [Prefecture art_allEntiteisByAreaId:self.selectWorkPlaceArea];

        case ARTSearchTypeWorkPlaceCity:
            return [City art_allEntiteisByPrefectureId:@(searchData.selectWorkPlacePrefecture.intValue)];

        case ARTSearchTypeJobTypeCategory:
            return [JobTypeCategory art_allNonDeleteEntiteis];

        case ARTSearchTypeJobType:
            return [JobType art_allEntiteisByJobTypeCategoryId:searchData.selectJobCategory];

        case ARTSearchTypeJobOtherOption:
            return [JobOtherPoint art_allNonDeleteEntiteis];

        case ARTSearchTypeAge:
            return [Generation art_allNonDeleteEntiteis];

        case ARTSearchTypeSex:
            return [Sex art_allNonDeleteEntiteis];

        case ARTSearchTypeHobbyType:
            return [HobbyType art_allNonDeleteEntiteis];

        case ARTSearchTypeHobby:
            return [Hobby art_allEntiteisByHobbyTypeId:@(searchData.selectHobbyType.intValue)];

        case ARTSearchTypeFutureGoal:
            return [FutureGoal art_allNonDeleteEntiteis];

        case ARTSearchTypeSalaryHourType:
            return [SalaryHourType art_allNonDeleteEntiteis];

        case ARTSearchTypeWorkDayType:
            return [WorkDayType art_allNonDeleteEntiteis];

        case ARTSearchTypeSchoolType:
            return [SchoolType art_allNonDeleteEntiteis];

        case ARTSearchTypeSchool:
            return nil;

        case ARTSearchTypeTrainLine:
            return nil;

        case ARTSearchTypeTrainStation:
            return [TrainStation art_allEntiteisByLineId:@(searchData.selectTrainLine.intValue)];

        default:
            break;
    }
    return nil;
}

- (NSArray *)selectDataWithSearchType:(ARTSearchType)type
{
    ARTSearchData *searchData = [self currentSearchData];

    switch (type) {
        case ARTSearchTypeSelectOptionType:
            return nil;

        case ARTSearchTypeBirthPlaceArea:
            if (searchData.selectBirthPlaceArea) {
                return @[searchData.selectBirthPlaceArea];
            }
            return nil;

        case ARTSearchTypeBirthPlacePrefecture:
            if (searchData.selectBirthplaces.count > 0) {
                return searchData.selectBirthplaces.allObjects;
            }
            return nil;

        case ARTSearchTypeWorkPlaceArea:
            if (searchData.selectWorkPlaceArea) {
                return @[searchData.selectWorkPlaceArea];
            }
            return nil;

        case ARTSearchTypeWorkPlacePrefecture:
            if (searchData.selectWorkPlacePrefecture) {
                return @[searchData.selectWorkPlacePrefecture];
            }
            return nil;

        case ARTSearchTypeWorkPlaceCity:
            if (searchData.selectWorkPlaces.count > 0) {
                return searchData.selectWorkPlaces.allObjects;
            }
            return nil;

        case ARTSearchTypeJobTypeCategory:
            if (searchData.selectJobCategory) {
                return @[searchData.selectWorkPlaces];
            }
            return nil;

        case ARTSearchTypeJobType:
            if (searchData.selectJobTypes.count > 0) {
                return searchData.selectJobTypes.allObjects;
            }
            return nil;

        case ARTSearchTypeJobOtherOption:
            if (searchData.selectJobOtherOptions.count > 0) {
                return searchData.selectJobOtherOptions.allObjects;
            }
            return nil;

        case ARTSearchTypeAge:
            if (searchData.selectAges.count > 0) {
                return searchData.selectAges.allObjects;
            }
            return nil;

        case ARTSearchTypeSex:
            if (searchData.selectGenders.count > 0) {
                return searchData.selectGenders.allObjects;
            }
            return nil;

        case ARTSearchTypeHobbyType:
            if (searchData.selectHobbyType) {
                return @[searchData.selectHobbyType];
            }
            return nil;

        case ARTSearchTypeHobby:
            if (searchData.selectHobbies.count > 0) {
                return searchData.selectHobbies.allObjects;
            }
            return nil;

        case ARTSearchTypeFutureGoal:
            if (searchData.selectFutureGoals.count > 0) {
                return searchData.selectFutureGoals.allObjects;
            }
            return nil;

        case ARTSearchTypeSalaryHourType:
            if (searchData.selectSalaryHour) {
                return @[searchData.selectSalaryHour];
            }
            return nil;

        case ARTSearchTypeWorkDayType:
            if (searchData.selectWorkDayType) {
                return @[searchData.selectWorkDayType];
            }
            return nil;

        case ARTSearchTypeSchoolType:
            return nil;

        case ARTSearchTypeSchool:
            if (searchData.selectSchool) {
                return @[searchData.selectSchool];
            }
            return nil;

        case ARTSearchTypeTrainLine:
            if (searchData.selectTrainLine) {
                return @[searchData.selectTrainLine];
            }

        case ARTSearchTypeTrainStation:
            if (searchData.selectTrainStations.count > 0) {
                return searchData.selectTrainStations.allObjects;
            }
            return nil;

        default:
            break;
    }
    return nil;
}

- (BOOL)isAlreadySetDataWithSearchType:(ARTSearchType)type data:(NSString *)data
{
    ARTSearchData *searchData = [self currentSearchData];

    if (!data) { return NO; }
    switch (type) {
        case ARTSearchTypeSelectOptionType:
            break;

        case ARTSearchTypeBirthPlaceArea:
            return [searchData.selectBirthPlaceArea isEqualToString:data];

        case ARTSearchTypeBirthPlacePrefecture:
            return [searchData.selectBirthplaces containsObject:data];

        case ARTSearchTypeWorkPlaceArea:
            return [searchData.selectWorkPlaceArea isEqualToString:data];

        case ARTSearchTypeWorkPlacePrefecture:
            return [searchData.selectWorkPlacePrefecture isEqualToString:data];

        case ARTSearchTypeWorkPlaceCity:
            return [searchData.selectWorkPlaces containsObject:data];

        case ARTSearchTypeJobTypeCategory:
            return [searchData.selectJobCategory isEqualToString:data];

        case ARTSearchTypeJobType:
            return [searchData.selectJobTypes containsObject:data];

        case ARTSearchTypeJobOtherOption:
            return [searchData.selectJobOtherOptions containsObject:data];

        case ARTSearchTypeAge:
            return [searchData.selectAges containsObject:data];

        case ARTSearchTypeSex:
            return [searchData.selectGenders containsObject:data];

        case ARTSearchTypeHobbyType:
            return [searchData.selectHobbyType isEqualToString:data];

        case ARTSearchTypeHobby:
            return [searchData.selectHobbies containsObject:data];

        case ARTSearchTypeFutureGoal:
            return [searchData.selectFutureGoals containsObject:data];

        case ARTSearchTypeSalaryHourType:
            return [searchData.selectSalaryHour isEqualToString:data];

        case ARTSearchTypeWorkDayType:
            return [searchData.selectWorkDayType isEqualToString:data];

        case ARTSearchTypeSchoolType:
            break;

        case ARTSearchTypeSchool:
            return [searchData.selectSchool isEqualToString:data];

        case ARTSearchTypeTrainLine:
            return [searchData.selectTrainLine isEqualToString:data];

        case ARTSearchTypeTrainStation:
            return [searchData.selectTrainStations containsObject:data];

        default:
            break;
    }

    return NO;
}

- (void)addSelectedDataWithSearchType:(ARTSearchType)type data:(NSString *)data
{
    ARTSearchData *searchData = [self currentSearchData];

    switch (type) {
        case ARTSearchTypeSelectOptionType:
            break;

        case ARTSearchTypeBirthPlaceArea:
            searchData.selectBirthPlaceArea = data;
            break;

        case ARTSearchTypeBirthPlacePrefecture:
            if (data) { [searchData.selectBirthplaces addObject:data]; }
            break;

        case ARTSearchTypeWorkPlaceArea:
            searchData.selectWorkPlaceArea = data;
            break;

        case ARTSearchTypeWorkPlacePrefecture:
            searchData.selectWorkPlacePrefecture = data;
            break;

        case ARTSearchTypeWorkPlaceCity:
            if (data) { [searchData.selectWorkPlaces addObject:data]; }
            break;

        case ARTSearchTypeJobTypeCategory:
            searchData.selectJobCategory = data;
            break;

        case ARTSearchTypeJobType:
            if (data) { [searchData.selectJobTypes addObject:data]; }
            break;

        case ARTSearchTypeJobOtherOption:
            if (data) { [searchData.selectJobOtherOptions addObject:data]; }
            break;

        case ARTSearchTypeAge:
            if (data) { [searchData.selectAges addObject:data]; }
            break;

        case ARTSearchTypeSex:
            if (data) { [searchData.selectGenders addObject:data]; }
            break;

        case ARTSearchTypeHobbyType:
            searchData.selectHobbyType = data;
            break;

        case ARTSearchTypeHobby:
            if (data) { [searchData.selectHobbies addObject:data]; }
            break;

        case ARTSearchTypeFutureGoal:
            if (data) { [searchData.selectFutureGoals addObject:data]; }
            break;

        case ARTSearchTypeSalaryHourType:
            searchData.selectSalaryHour = data;
            break;

        case ARTSearchTypeWorkDayType:
            searchData.selectWorkDayType = data;
            break;

        case ARTSearchTypeSchoolType:
            break;

        case ARTSearchTypeSchool:
            searchData.selectSchool = data;
            break;

        case ARTSearchTypeTrainLine:
            searchData.selectTrainLine = data;
            break;

        case ARTSearchTypeTrainStation:
            if (data) { [searchData.selectTrainStations addObject:data]; }
            break;

        default:
            break;
    }
}

- (void)removeSelectedDataWithSearchType:(ARTSearchType)type data:(NSString *)data
{
    ARTSearchData *searchData = [self currentSearchData];

    switch (type) {
        case ARTSearchTypeSelectOptionType:
            break;

        case ARTSearchTypeBirthPlaceArea:
            searchData.selectBirthPlaceArea = nil;
            break;

        case ARTSearchTypeBirthPlacePrefecture:
            if (data) { [searchData.selectBirthplaces removeObject:data]; }
            break;

        case ARTSearchTypeWorkPlaceArea:
            searchData.selectWorkPlaceArea = nil;
            break;

        case ARTSearchTypeWorkPlacePrefecture:
            searchData.selectWorkPlacePrefecture = nil;
            break;

        case ARTSearchTypeWorkPlaceCity:
            if (data) { [searchData.selectWorkPlaces removeObject:data]; }
            break;

        case ARTSearchTypeJobTypeCategory:
            searchData.selectJobCategory = nil;
            break;

        case ARTSearchTypeJobType:
            if (data) { [searchData.selectJobTypes removeObject:data]; }
            break;

        case ARTSearchTypeJobOtherOption:
            if (data) { [searchData.selectJobOtherOptions removeObject:data]; }
            break;

        case ARTSearchTypeAge:
            if (data) { [searchData.selectAges removeObject:data]; }
            break;

        case ARTSearchTypeSex:
            if (data) { [searchData.selectGenders removeObject:data]; }
            break;

        case ARTSearchTypeHobbyType:
            searchData.selectHobbyType = nil;
            break;

        case ARTSearchTypeHobby:
            if (data) { [searchData.selectHobbies removeObject:data]; }
            break;

        case ARTSearchTypeFutureGoal:
            if (data) { [searchData.selectFutureGoals removeObject:data]; }
            break;

        case ARTSearchTypeSalaryHourType:
            searchData.selectSalaryHour = nil;
            break;

        case ARTSearchTypeWorkDayType:
            searchData.selectWorkDayType = nil;
            break;

        case ARTSearchTypeSchoolType:
            break;

        case ARTSearchTypeSchool:
            searchData.selectSchool = nil;
            break;

        case ARTSearchTypeTrainLine:
            searchData.selectTrainLine = nil;
            break;

        case ARTSearchTypeTrainStation:
            if (data) { [searchData.selectTrainStations removeObject:data]; }
            break;

        default:
            break;
    }
}

- (void)pushControllerWithSearchGroup:(ARTSearchGroup)searchGroup
{
    ARTSearchType  type;
    ARTSearchData *searchData = [self currentSearchData];

    switch (searchGroup) {
        case ARTSearchGroupSelectOptionType:
            type = ARTSearchTypeSelectOptionType;
            break;

        case ARTSearchGroupAge:
            type = ARTSearchTypeAge;
            break;

        case ARTSearchGroupSex:
            type = ARTSearchTypeSex;
            break;

        case ARTSearchGroupBirthPlace:
            if (!searchData.selectBirthPlaceArea) {
                type = ARTSearchTypeBirthPlaceArea;
            } else {
                type = ARTSearchTypeBirthPlacePrefecture;
            }
            break;

        case ARTSearchGroupHobby:
            if (!searchData.selectHobbyType) {
                type = ARTSearchTypeHobbyType;
            } else {
                type = ARTSearchTypeHobby;
            }
            break;

        case ARTSearchGroupFutureGoal:
            type = ARTSearchTypeFutureGoal;
            break;

        case ARTSearchGroupSchool:
            type = ARTSearchTypeSchool;
            break;

        case ARTSearchGroupWorkPlace:
            if (!searchData.selectWorkPlaceArea) {
                type = ARTSearchTypeWorkPlaceArea;
            } else if (!searchData.selectWorkPlacePrefecture) {
                type = ARTSearchTypeWorkPlacePrefecture;
            } else {
                type = ARTSearchTypeWorkPlaceCity;
            }
            break;

        case ARTSearchGroupJobType:
            if (!searchData.selectJobCategory) {
                type = ARTSearchTypeJobTypeCategory;
            } else {
                type = ARTSearchTypeJobType;
            }
            break;

        case ARTSearchGroupSalaryHour:
            type = ARTSearchTypeSalaryHourType;
            break;

        case ARTSearchGroupJobOtherOption:
            type = ARTSearchTypeJobOtherOption;
            break;

        case ARTSearchGroupWorkDayType:
            type = ARTSearchTypeWorkDayType;
            break;

        case ARTSearchGroupTrain:
            if (!searchData.selectTrainLine) {
                type = ARTSearchTypeTrainLine;
            } else {
                type = ARTSearchTypeTrainStation;
            }
            break;

        default:
            break;
    }
    if (self.isModal) {
        [[ARTViewContainer shared] pushActiveModalNavController:[ARTViewControllerFactory searchControllerWithType:type isModal:YES needBack:YES]];
    } else {
        [[ARTViewContainer shared] pushActiveNavController:[ARTViewControllerFactory searchControllerWithType:type isModal:NO needBack:YES]];
    }
}

- (void)pushControllerWithSearchType:(ARTSearchType)searchType
{
    switch (searchType) {
        case ARTSearchTypeSelectOptionType:
            break;

        case ARTSearchTypeBirthPlaceArea:
            [self pushControllerWithSearchGroup:ARTSearchGroupBirthPlace];
            break;

        case ARTSearchTypeBirthPlacePrefecture:
            [self pushControllerWithSearchGroup:ARTSearchGroupBirthPlace];
            break;

        case ARTSearchTypeWorkPlaceArea:
            [self pushControllerWithSearchGroup:ARTSearchGroupWorkPlace];
            break;

        case ARTSearchTypeWorkPlacePrefecture:
            [self pushControllerWithSearchGroup:ARTSearchGroupWorkPlace];
            break;

        case ARTSearchTypeWorkPlaceCity:
            [self pushControllerWithSearchGroup:ARTSearchGroupWorkPlace];
            break;

        case ARTSearchTypeJobTypeCategory:
            [self pushControllerWithSearchGroup:ARTSearchGroupJobType];
            break;

        case ARTSearchTypeJobType:
            [self pushControllerWithSearchGroup:ARTSearchGroupJobType];
            break;

        case ARTSearchTypeJobOtherOption:
            [self pushControllerWithSearchGroup:ARTSearchGroupJobOtherOption];
            break;

        case ARTSearchTypeAge:
            [self pushControllerWithSearchGroup:ARTSearchGroupAge];
            break;

        case ARTSearchTypeSex:
            [self pushControllerWithSearchGroup:ARTSearchGroupSex];
            break;

        case ARTSearchTypeHobbyType:
            [self pushControllerWithSearchGroup:ARTSearchGroupHobby];
            break;

        case ARTSearchTypeHobby:
            [self pushControllerWithSearchGroup:ARTSearchGroupHobby];
            break;

        case ARTSearchTypeFutureGoal:
            [self pushControllerWithSearchGroup:ARTSearchGroupFutureGoal];
            break;

        case ARTSearchTypeSalaryHourType:
            [self pushControllerWithSearchGroup:ARTSearchGroupSalaryHour];
            break;

        case ARTSearchTypeWorkDayType:
            [self pushControllerWithSearchGroup:ARTSearchGroupWorkDayType];
            break;

        case ARTSearchTypeSchoolType:
            break;

        case ARTSearchTypeSchool:
            break;

        case ARTSearchTypeTrainLine:
            [self pushControllerWithSearchGroup:ARTSearchGroupTrain];
            break;

        case ARTSearchTypeTrainStation:
            break;

        default:
            break;
    }
}

- (void)presentSearchOptionViewController
{
    self.isModal = YES;
    [self clearMultipleSelect];
    if (self.isSearched) {
        [self recoveryTempData];
    }

    __weak typeof(self) weakSelf = self;

    [[ARTViewContainer shared] showModalViewWithController:[ARTViewControllerFactory searchControllerWithType:ARTSearchTypeSelectOptionType isModal:YES needBack:NO]
                                                  animated:YES
                                            animationBlock: ^{ }
                                           completionBlock: ^(UINavigationController *resultNavController) {
         if (weakSelf.isSearched) {
             [[ARTViewContainer shared] tabViewisShow:YES];
         }
     }];
}

@end
