//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTMessageDataModel.h"

@implementation ARTMessageDataModel

- (instancetype)init
{
    if (!(self = [super init])) { return nil; }
    
    self.messages = [NSMutableArray new];
    
    JSQMessagesBubbleImageFactory *bubbleFactory = [[JSQMessagesBubbleImageFactory alloc] init];
    
    self.outgoingBubbleImageData = [bubbleFactory outgoingMessagesBubbleImageWithColor:[UIColor whiteColor]];
    self.incomingBubbleImageData = [bubbleFactory incomingMessagesBubbleImageWithColor:[UIColor whiteColor]];
    
    JSQMessagesAvatarImage *defoImage = [JSQMessagesAvatarImageFactory avatarImageWithImage:[UIImage imageNamed:@"no_image_private"]
                                                                                   diameter:kJSQMessagesCollectionViewAvatarSizeDefault];
    
    self.avatars = @{ kARTAvatarDefault : defoImage };
    
    return self;
}

@end
