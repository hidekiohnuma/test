//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTUserDefaults.h"
#import <ARNUserDefaultsProxy.h>

@implementation ARTUserDefaults

+ (instancetype)shared
{
    static ARTUserDefaults *_shared = nil;
    static dispatch_once_t  onceToken;
    dispatch_once(&onceToken, ^{
            _shared = (ARTUserDefaults *)[[ARNUserDefaultsProxy alloc] initWithTarget:[[ARTUserDefaults alloc] initWithSingleton]];
        });
    return _shared;
}

- (instancetype)initWithSingleton
{
    if (!(self = [super init])) { return nil; }

    return self;
}

- (instancetype)init
{
    [self doesNotRecognizeSelector:_cmd];
    return nil;
}

@end
