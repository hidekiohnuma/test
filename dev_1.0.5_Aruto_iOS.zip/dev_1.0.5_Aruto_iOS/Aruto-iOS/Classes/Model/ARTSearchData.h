//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

@interface ARTSearchData : NSObject <NSCopying>

// Serash Datas
@property (nonatomic, strong) NSMutableSet *selectAges;
@property (nonatomic, strong) NSMutableSet *selectGenders;
@property (nonatomic, strong) NSMutableSet *selectFutureGoals;
@property (nonatomic, strong) NSMutableSet *selectHobbies;
@property (nonatomic, strong) NSMutableSet *selectJobTypes;
@property (nonatomic, strong) NSMutableSet *selectJobOtherOptions;
@property (nonatomic, strong) NSMutableSet *selectWorkPlaces;
@property (nonatomic, strong) NSMutableSet *selectTrainStations;
@property (nonatomic, strong) NSMutableSet *selectBirthplaces;
@property (nonatomic, copy) NSString       *selectSchool;
@property (nonatomic, copy) NSString       *selectSalaryHour;
@property (nonatomic, copy) NSString       *selectSalaryDay;
@property (nonatomic, copy) NSString       *selectWorkDayType;
@property (nonatomic, copy) NSString       *searchWord;

// Multiple Transition Group

// Birthplace
@property (nonatomic, copy) NSString *selectBirthPlaceArea;
// Hobby
@property (nonatomic, copy) NSString *selectHobbyType;
// JObType
@property (nonatomic, copy) NSString *selectJobCategory;
// WorkPlace
@property (nonatomic, copy) NSString *selectWorkPlaceArea;
@property (nonatomic, copy) NSString *selectWorkPlacePrefecture;
// Train
@property (nonatomic, copy) NSString *selectTrainLine;

- (void)resetData;
- (void)resetMultipleSelect;

@end
