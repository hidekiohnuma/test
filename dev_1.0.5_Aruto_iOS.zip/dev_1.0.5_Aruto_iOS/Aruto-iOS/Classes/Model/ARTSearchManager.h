//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

@interface ARTSearchManager : NSObject

@property (nonatomic, assign) BOOL      isSearched;
@property (nonatomic, assign) BOOL      isStaffSearch;
@property (nonatomic, assign) BOOL      isModal;
@property (nonatomic, assign) NSInteger totalCount;
@property (nonatomic, copy) NSString   *searchIndentifier;

+ (instancetype)shared;

- (void)allClear;
- (void)recoveryTempData;
- (void)clearTempData;
- (void)clearMultipleSelect;

- (NSString *)searchWord;
- (void)setSearchWord:(NSString *)searchWord;

- (BOOL)checkSearchItems;
- (void)startSearchForFirst:(BOOL)isFirst;
- (void)startMoreLoadWithCompletionBlock:(void (^)())completionBlock
                                   index:(NSInteger)index;

- (NSString *)headerTitleWithType:(ARTSearchType)searchType;

- (BOOL)isDispButtonViewWithType:(ARTSearchType)type;

- (BOOL)isMultipleSelectWithSearchType:(ARTSearchType)type;

- (BOOL)isNeedPushWithSearchType:(ARTSearchType)type;

- (NSArray *)dataWithSearchType:(ARTSearchType)type;

- (NSArray *)selectDataWithSearchType:(ARTSearchType)type;

- (BOOL)isAlreadySetDataWithSearchType:(ARTSearchType)type data:(NSString *)data;

- (void)addSelectedDataWithSearchType:(ARTSearchType)type data:(NSString *)data;

- (void)removeSelectedDataWithSearchType:(ARTSearchType)type data:(NSString *)data;

- (void)pushControllerWithSearchGroup:(ARTSearchGroup)searchGroup;

- (void)pushControllerWithSearchType:(ARTSearchType)searchType;

- (void)presentSearchOptionViewController;

@end
