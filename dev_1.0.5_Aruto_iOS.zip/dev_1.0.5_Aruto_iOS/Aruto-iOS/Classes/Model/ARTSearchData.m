//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTSearchData.h"

@implementation ARTSearchData

- (void)resetData
{
    self.searchWord            = nil;
    self.selectAges            = [NSMutableSet set];
    self.selectGenders         = [NSMutableSet set];
    self.selectFutureGoals     = [NSMutableSet set];
    self.selectHobbies         = [NSMutableSet set];
    self.selectJobTypes        = [NSMutableSet set];
    self.selectJobOtherOptions = [NSMutableSet set];
    self.selectWorkPlaces      = [NSMutableSet set];
    self.selectTrainStations   = [NSMutableSet set];
    self.selectBirthplaces     = [NSMutableSet set];
    self.selectSchool          = nil;
    self.selectSalaryHour      = nil;
    self.selectSalaryDay       = nil;
    self.selectWorkDayType     = nil;

    [self resetMultipleSelect];
}

- (void)resetMultipleSelect
{
    self.selectBirthPlaceArea      = nil;
    self.selectWorkPlacePrefecture = nil;
    self.selectHobbyType           = nil;
    self.selectJobCategory         = nil;
    // todo : 今だけ暫定対応（関東）
    self.selectWorkPlaceArea = @"3";
    self.selectTrainLine     = nil;
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - NSCopying Protocols

- (id)copyWithZone:(NSZone *)zone
{
    ARTSearchData *copyObj = [[[self class] allocWithZone:zone] init];
    if (copyObj) {
        copyObj.searchWord            = [_searchWord copyWithZone:zone];
        copyObj.selectAges            = [[NSMutableSet allocWithZone:zone] initWithSet:_selectAges copyItems:YES];
        copyObj.selectGenders         = [[NSMutableSet allocWithZone:zone] initWithSet:_selectGenders copyItems:YES];
        copyObj.selectFutureGoals     = [[NSMutableSet allocWithZone:zone] initWithSet:_selectFutureGoals copyItems:YES];
        copyObj.selectHobbies         = [[NSMutableSet allocWithZone:zone] initWithSet:_selectHobbies copyItems:YES];
        copyObj.selectJobTypes        = [[NSMutableSet allocWithZone:zone] initWithSet:_selectJobTypes copyItems:YES];
        copyObj.selectJobOtherOptions = [[NSMutableSet allocWithZone:zone] initWithSet:_selectJobOtherOptions copyItems:YES];
        copyObj.selectWorkPlaces      = [[NSMutableSet allocWithZone:zone] initWithSet:_selectWorkPlaces copyItems:YES];
        copyObj.selectTrainStations   = [[NSMutableSet allocWithZone:zone] initWithSet:_selectTrainStations copyItems:YES];
        copyObj.selectBirthplaces     = [[NSMutableSet allocWithZone:zone] initWithSet:_selectBirthplaces copyItems:YES];
        copyObj.selectSchool          = [_selectSchool copyWithZone:zone];
        copyObj.selectSalaryHour      = [_selectSalaryHour copyWithZone:zone];
        copyObj.selectSalaryDay       = [_selectSalaryDay copyWithZone:zone];
        copyObj.selectWorkDayType     = [_selectWorkDayType copyWithZone:zone];

        copyObj.selectBirthPlaceArea      = [_selectBirthPlaceArea copyWithZone:zone];
        copyObj.selectWorkPlacePrefecture = [_selectWorkPlacePrefecture copyWithZone:zone];
        copyObj.selectHobbyType           = [_selectHobbyType copyWithZone:zone];
        copyObj.selectJobCategory         = [_selectJobCategory copyWithZone:zone];
        copyObj.selectWorkPlaceArea       = [_selectWorkPlaceArea copyWithZone:zone];
        copyObj.selectTrainLine           = [_selectTrainLine copyWithZone:zone];
    }
    return copyObj;
}

@end
