//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

@interface ARTUserDefaults : NSObject

+ (instancetype)shared;

@property (nonatomic, assign) BOOL       isFinishWelcomeView;
@property (nonatomic, assign) BOOL       isFinishTutorial;
@property (nonatomic, assign) BOOL       isFinishInitialDataLoad;
@property (nonatomic, assign) BOOL       isFinishInitialBigDataLoad;
@property (nonatomic, copy) NSString    *currentVersion;
@property (nonatomic, copy) NSString    *deviceToken;
@property (nonatomic, copy) NSString    *uuid;
@property (nonatomic, assign) NSUInteger iconBadgeCount;
@property (nonatomic, assign) NSUInteger entryTotalCount;

@property (nonatomic, copy) NSString *initialDataLastUpdateTimestamp;

@end
