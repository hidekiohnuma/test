//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "JobJobOtherPoint.h"

@implementation JobJobOtherPoint

@dynamic jobId;
@dynamic jobOtherPointId;

@end
