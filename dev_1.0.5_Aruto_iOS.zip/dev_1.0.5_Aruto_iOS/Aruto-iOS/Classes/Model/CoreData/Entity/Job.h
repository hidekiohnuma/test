//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "EntityBase.h"


@interface Job : EntityBase

@property (nonatomic, retain) NSString *bonus;
@property (nonatomic, retain) NSNumber *companyId;
@property (nonatomic, retain) NSNumber *jobTypeId;
@property (nonatomic, retain) NSString *salary;
@property (nonatomic, retain) NSNumber *salaryHour;
@property (nonatomic, retain) NSNumber *salaryDay;
@property (nonatomic, retain) NSNumber *salaryMonth;
@property (nonatomic, retain) NSNumber *shopId;
@property (nonatomic, retain) NSString *title;
@property (nonatomic, retain) NSString *workDay;
@property (nonatomic, retain) NSString *workDescription;
@property (nonatomic, retain) NSString *workHour;
@property (nonatomic, retain) NSString *workHourFrom;
@property (nonatomic, retain) NSString *workHourTo;
@property (nonatomic, retain) NSString *workPeriod;
@property (nonatomic, retain) NSString *workPlace;
@property (nonatomic, retain) NSNumber *hireNumber;
@property (nonatomic, retain) NSDate   *displayBegin;
@property (nonatomic, retain) NSDate   *displayEnd;
@property (nonatomic, retain) NSNumber *workDayTypeId;

@end
