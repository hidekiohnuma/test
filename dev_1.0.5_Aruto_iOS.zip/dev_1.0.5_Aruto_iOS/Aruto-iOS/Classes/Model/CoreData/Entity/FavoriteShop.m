//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "FavoriteShop.h"


@implementation FavoriteShop

@dynamic shopId;
@dynamic jobSeekerId;

@end
