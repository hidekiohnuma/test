//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "EntryStatus.h"


@implementation EntryStatus


@end
