//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "EntityBase.h"


@implementation EntityBase

@dynamic identifier;
@dynamic created;
@dynamic displayFlg;
@dynamic dataDeleted;
@dynamic modified;
@dynamic name;
@dynamic sort;

@end
