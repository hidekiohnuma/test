//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "SchoolType.h"


@implementation SchoolType


@end
