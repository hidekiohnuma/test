//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "Shop.h"

@implementation Shop

@dynamic branchName;
@dynamic gendarRatio;
@dynamic leaderComment;
@dynamic prefectureId;
@dynamic tel;
@dynamic shopFeature;
@dynamic ageAverage;
@dynamic businessHour;
@dynamic businessTypeId;
@dynamic companyId;
@dynamic address1;
@dynamic address2;
@dynamic address3;
@dynamic thumbnailURL;
@dynamic image1URL;
@dynamic image2URL;
@dynamic image3URL;
@dynamic access;
@dynamic searchIdentifier;

@end
