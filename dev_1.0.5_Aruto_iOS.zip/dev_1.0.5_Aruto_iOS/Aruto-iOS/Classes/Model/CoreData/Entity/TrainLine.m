//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "TrainLine.h"


@implementation TrainLine

@dynamic lineName;
@dynamic lineId;

@end
