//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "TrainStation.h"


@implementation TrainStation

@dynamic stationName;
@dynamic lineId;

@end
