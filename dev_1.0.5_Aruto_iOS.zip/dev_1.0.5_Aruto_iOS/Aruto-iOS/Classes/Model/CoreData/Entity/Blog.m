//  Copyright (c) 2015年 Aruto Corp. All rights reserved.

#import "Blog.h"

@implementation Blog

@dynamic blogId;
@dynamic postDate;
@dynamic postTitle;
@dynamic postUrl;
@dynamic category;
@dynamic shopId;
@dynamic thumbnailUrl;
@dynamic searchIdentifier;

@end
