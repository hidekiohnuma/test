//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface EntityBase : NSManagedObject

@property (nonatomic, retain) NSNumber *identifier;
@property (nonatomic, retain) NSDate   *created;
@property (nonatomic, retain) NSNumber *displayFlg;
@property (nonatomic, retain) NSDate   *dataDeleted;
@property (nonatomic, retain) NSDate   *modified;
@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSNumber *sort;

@end
