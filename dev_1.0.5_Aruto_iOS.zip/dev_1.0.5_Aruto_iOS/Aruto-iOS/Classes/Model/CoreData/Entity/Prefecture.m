//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "Prefecture.h"


@implementation Prefecture

@dynamic areaId;

@end
