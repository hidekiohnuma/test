//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "EntityBase.h"


@interface Shop : EntityBase

@property (nonatomic, retain) NSString *branchName;
@property (nonatomic, retain) NSString *gendarRatio;
@property (nonatomic, retain) NSString *leaderComment;
@property (nonatomic, retain) NSNumber *prefectureId;
@property (nonatomic, retain) NSString *tel;
@property (nonatomic, retain) NSString *shopFeature;
@property (nonatomic, retain) NSString *ageAverage;
@property (nonatomic, retain) NSString *businessHour;
@property (nonatomic, retain) NSNumber *businessTypeId;
@property (nonatomic, retain) NSNumber *companyId;
@property (nonatomic, retain) NSString *address1;
@property (nonatomic, retain) NSString *address2;
@property (nonatomic, retain) NSString *address3;
@property (nonatomic, retain) NSString *thumbnailURL;
@property (nonatomic, retain) NSString *image1URL;
@property (nonatomic, retain) NSString *image2URL;
@property (nonatomic, retain) NSString *image3URL;
@property (nonatomic, retain) NSString *access;
@property (nonatomic, retain) NSString *searchIdentifier;

@end
