//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "WorkDayType.h"


@implementation WorkDayType


@end
