//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "EntryMessage.h"


@implementation EntryMessage

@dynamic entryId;
@dynamic message;
@dynamic userId;

@end
