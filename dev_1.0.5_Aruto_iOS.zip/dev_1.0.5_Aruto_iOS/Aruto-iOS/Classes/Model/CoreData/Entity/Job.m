//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "Job.h"


@implementation Job

@dynamic bonus;
@dynamic companyId;
@dynamic jobTypeId;
@dynamic salary;
@dynamic salaryHour;
@dynamic salaryDay;
@dynamic salaryMonth;
@dynamic shopId;
@dynamic title;
@dynamic workDay;
@dynamic workDescription;
@dynamic workHour;
@dynamic workHourFrom;
@dynamic workHourTo;
@dynamic workPeriod;
@dynamic workPlace;
@dynamic hireNumber;
@dynamic displayBegin;
@dynamic displayEnd;
@dynamic workDayTypeId;

@end
