//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "Staff.h"

@implementation Staff

@dynamic age;
@dynamic privateAnswers;
@dynamic workAnswers;
@dynamic otherAnswers;
@dynamic favoriteAnswers;
@dynamic futureGoalId;
@dynamic futureGoalComment;
@dynamic hobbyId;
@dynamic hobbyComment;
@dynamic sexId;
@dynamic shopId;
@dynamic hometownPrefectureId;
@dynamic recommendStaffFlg;
@dynamic recommendStaffSort;
@dynamic pickupStaffFlg;
@dynamic pickupStaffSort;
@dynamic highschoolId;
@dynamic collegeId;
@dynamic thumbnailURL;
@dynamic thumbnailURL2;
@dynamic workImageURL;
@dynamic privateImageURL;
@dynamic searchIdentifier;
@dynamic isContainsRankAccess;
@dynamic isContainsRankAruto;
@dynamic isContainsRankMale;
@dynamic isContainsRankFemale;
@dynamic isContainsRankPickup;
@dynamic favoriteCount;
@dynamic accessCount;
@dynamic birthday;
@dynamic generationId;
@dynamic cityId;

- (void)setPrivateAnswers:(NSDictionary *)dict
{
    [self willChangeValueForKey:@"setPrivateAnswers"];

    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:dict];
    [self setPrimitiveValue:data forKey:@"privateAnswers"];

    [self didChangeValueForKey:@"setPrivateAnswers"];
}

- (NSDictionary *)privateAnswers
{
    NSData *data = [self primitiveValueForKey:@"privateAnswers"];
    if (!data) { return nil; }

    return [NSKeyedUnarchiver unarchiveObjectWithData:data];
}

- (void)setWorkAnswers:(NSDictionary *)dict
{
    [self willChangeValueForKey:@"setWorkAnswers"];

    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:dict];
    [self setPrimitiveValue:data forKey:@"workAnswers"];

    [self didChangeValueForKey:@"setWorkAnswers"];
}

- (NSDictionary *)workAnswers
{
    NSData *data = [self primitiveValueForKey:@"workAnswers"];
    if (!data) { return nil; }

    return [NSKeyedUnarchiver unarchiveObjectWithData:data];
}

- (void)setFavoriteAnswers:(NSDictionary *)dict
{
    [self willChangeValueForKey:@"setFavoriteAnswers"];

    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:dict];
    [self setPrimitiveValue:data forKey:@"favoriteAnswers"];

    [self didChangeValueForKey:@"setFavoriteAnswers"];
}

- (NSDictionary *)favoriteAnswers
{
    NSData *data = [self primitiveValueForKey:@"favoriteAnswers"];
    if (!data) { return nil; }

    return [NSKeyedUnarchiver unarchiveObjectWithData:data];
}

- (void)setOtherAnswers:(NSDictionary *)dict
{
    [self willChangeValueForKey:@"setOtherAnswers"];

    NSData *data = [NSKeyedArchiver archivedDataWithRootObject:dict];
    [self setPrimitiveValue:data forKey:@"otherAnswers"];

    [self didChangeValueForKey:@"setOtherAnswers"];
}

- (NSDictionary *)otherAnswers
{
    NSData *data = [self primitiveValueForKey:@"otherAnswers"];
    if (!data) { return nil; }

    return [NSKeyedUnarchiver unarchiveObjectWithData:data];
}

@end
