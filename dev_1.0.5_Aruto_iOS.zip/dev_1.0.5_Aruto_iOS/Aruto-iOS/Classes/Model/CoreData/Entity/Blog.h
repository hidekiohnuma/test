//  Copyright (c) 2015年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "EntityBase.h"


@interface Blog : EntityBase

@property (nonatomic, retain) NSNumber *blogId;
@property (nonatomic, retain) NSDate   *postDate;
@property (nonatomic, retain) NSString *postTitle;
@property (nonatomic, retain) NSString *postUrl;
@property (nonatomic, retain) NSString *category;
@property (nonatomic, retain) NSNumber *shopId;
@property (nonatomic, retain) NSString *thumbnailUrl;
@property (nonatomic, retain) NSString *searchIdentifier;

@end
