//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "EntityBase.h"


@interface User : EntityBase

@property (nonatomic, retain) NSNumber *jobSeekerId;
@property (nonatomic, retain) NSNumber *notificationForAllflg;
@property (nonatomic, retain) NSNumber *notificationForYouflg;
@property (nonatomic, retain) NSString *deviceToken;
@property (nonatomic, retain) NSString *firstName;
@property (nonatomic, retain) NSString *lastName;
@property (nonatomic, retain) NSString *firstNameKana;
@property (nonatomic, retain) NSString *lastNameKana;
@property (nonatomic, retain) NSString *contactType;
@property (nonatomic, retain) NSString *tel;
@property (nonatomic, retain) NSDate   *birthDayDate;

@end
