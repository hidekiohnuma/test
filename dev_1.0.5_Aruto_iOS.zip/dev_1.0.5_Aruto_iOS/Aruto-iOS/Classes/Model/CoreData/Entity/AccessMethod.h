//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "EntityBase.h"


@interface AccessMethod : EntityBase


@end
