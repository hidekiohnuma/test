//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "User.h"


@implementation User

@dynamic jobSeekerId;
@dynamic notificationForAllflg;
@dynamic notificationForYouflg;
@dynamic deviceToken;
@dynamic firstName;
@dynamic lastName;
@dynamic firstNameKana;
@dynamic lastNameKana;
@dynamic contactType;
@dynamic tel;
@dynamic birthDayDate;

@end
