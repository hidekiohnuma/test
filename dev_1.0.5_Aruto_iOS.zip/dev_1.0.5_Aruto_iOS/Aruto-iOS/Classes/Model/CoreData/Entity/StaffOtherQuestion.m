//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "StaffOtherQuestion.h"


@implementation StaffOtherQuestion

@dynamic questionType;
@dynamic title;

@end
