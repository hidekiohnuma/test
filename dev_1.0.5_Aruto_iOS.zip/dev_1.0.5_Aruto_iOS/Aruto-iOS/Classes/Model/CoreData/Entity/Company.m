//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "Company.h"


@implementation Company


@end
