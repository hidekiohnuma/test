//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "EntityBase.h"

@class Favorite;

@interface Staff : EntityBase

@property (nonatomic, retain) NSString     *age;
@property (nonatomic, retain) NSDictionary *privateAnswers;
@property (nonatomic, retain) NSDictionary *workAnswers;
@property (nonatomic, retain) NSDictionary *otherAnswers;
@property (nonatomic, retain) NSDictionary *favoriteAnswers;
@property (nonatomic, retain) NSNumber     *futureGoalId;
@property (nonatomic, retain) NSString     *futureGoalComment;
@property (nonatomic, retain) NSNumber     *hobbyId;
@property (nonatomic, retain) NSString     *hobbyComment;
@property (nonatomic, retain) NSNumber     *sexId;
@property (nonatomic, retain) NSNumber     *shopId;
@property (nonatomic, retain) NSNumber     *hometownPrefectureId;
@property (nonatomic, retain) NSNumber     *recommendStaffFlg;
@property (nonatomic, retain) NSNumber     *recommendStaffSort;
@property (nonatomic, retain) NSNumber     *pickupStaffFlg;
@property (nonatomic, retain) NSNumber     *pickupStaffSort;
@property (nonatomic, retain) NSNumber     *highschoolId;
@property (nonatomic, retain) NSNumber     *collegeId;
@property (nonatomic, retain) NSString     *thumbnailURL;
@property (nonatomic, retain) NSString     *thumbnailURL2;
@property (nonatomic, retain) NSString     *workImageURL;
@property (nonatomic, retain) NSString     *privateImageURL;
@property (nonatomic, retain) NSString     *searchIdentifier;
@property (nonatomic, retain) NSNumber     *isContainsRankAccess;
@property (nonatomic, retain) NSNumber     *isContainsRankAruto;
@property (nonatomic, retain) NSNumber     *isContainsRankMale;
@property (nonatomic, retain) NSNumber     *isContainsRankFemale;
@property (nonatomic, retain) NSNumber     *isContainsRankPickup;
@property (nonatomic, retain) NSNumber     *favoriteCount;
@property (nonatomic, retain) NSNumber     *accessCount;
@property (nonatomic, retain) NSDate       *birthday;
@property (nonatomic, retain) NSNumber     *generationId;
@property (nonatomic, retain) NSNumber     *cityId;

@end
