//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>
#import "EntityBase.h"


@interface Entry : EntityBase

@property (nonatomic, retain) NSNumber *entryStatusId;
@property (nonatomic, retain) NSDate   *interviewDate;
@property (nonatomic, retain) NSNumber *jobId;

@end
