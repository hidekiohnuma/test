//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "AccessMethod.h"


@implementation AccessMethod


@end
