//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "Entry.h"


@implementation Entry

@dynamic entryStatusId;
@dynamic interviewDate;
@dynamic jobId;

@end
