//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "ARTCoreDataFetcher.h"

#import "CoreData+MagicalRecord.h"

@implementation ARTCoreDataFetcher

+ (void)setUp
{
    [MagicalRecord setupCoreDataStackWithAutoMigratingSqliteStoreNamed:@"ARTDataModel.sqlite"];
}

+ (void)cleanUp
{
    [MagicalRecord cleanUp];
}

+ (void)cleanData
{
    [Staff art_deleteAllEntiteis];
    [Shop art_deleteAllEntiteis];
    [Job art_deleteAllEntiteis];
    [Company art_deleteAllEntiteis];
    [Entry art_deleteAllEntiteis];
}

+ (void)saveWithBlock:(void (^)(NSManagedObjectContext *localContext))block
           completion:(void (^)())completion
{
    [MagicalRecord saveWithBlockAndWait:block];
    art_SafeBlockCall(completion, YES, nil);
}

+ (id)entityForIdentifier:(NSNumber *)identifier managedObject:(id)managedObject localContext:(NSManagedObjectContext *)localContext
{
    @synchronized(self)
    {
        id entity = [[managedObject class] MR_findFirstByAttribute:@"identifier" withValue:identifier inContext:localContext];
        if (entity) {
            //LOG(@"update_entity :%@", identifier);
            return entity;
        } else {
            //LOG(@"create_entity :%@", identifier);
            return [[managedObject class] MR_createInContext:localContext];
        }
    }
}

@end

@implementation EntityBase (ARTCoreDataFetcher)

+ (NSArray *)art_allEntiteis
{
    return [self MR_findAllSortedBy:@"sort" ascending:YES];
}

+ (NSArray *)art_allNonDeleteEntiteis
{
    NSArray *result = [self art_sortEntityForLocalContext:nil
                                          predicateFormat:@"dataDeleted == NULL AND displayFlg == YES"
                                            argumentArray:nil
                                               fetchLimit:0
                                                assending:YES];
    return result;
}

+ (void)art_deleteAllEntiteis
{
    [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
        [self MR_deleteAllMatchingPredicate:nil inContext:localContext];
    } completion:nil];
}

+ (void)art_updateAllEntityDisplayFlag:(BOOL)displayFlag
{
    dispatch_group_t disGroup = dispatch_group_create();
    dispatch_group_enter(disGroup);
    [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
        NSArray *result = [self art_fetchForLocalContext:localContext
                                         predicateFormat:nil
                                           argumentArray:nil
                                              isFirstObj:NO
                                              fetchLimit:0
                                         sortDescriptors:nil];
        for (EntityBase *entity in result) {
            entity.displayFlg = @(displayFlag);
        }
    } completion:^{
        dispatch_group_leave(disGroup);
    }];
    dispatch_group_wait(disGroup, DISPATCH_TIME_FOREVER);
}

+ (void)art_updateEntityDisplayFlagForEntityIds:(NSArray *)entityIdArray
{
    if (!entityIdArray || !entityIdArray.count) {
        return;
    }
    
    dispatch_group_t disGroup = dispatch_group_create();
    dispatch_group_enter(disGroup);
    [ARTCoreDataFetcher saveWithBlock: ^(NSManagedObjectContext *localContext) {
        NSArray *result = [self art_fetchForLocalContext:localContext
                                         predicateFormat:@"identifier in %@ AND dataDeleted == NULL"
                                           argumentArray:@[entityIdArray]
                                              isFirstObj:NO
                                              fetchLimit:0
                                         sortDescriptors:nil];
        for (EntityBase *entity in result) {
            entity.displayFlg = @YES;
        }
    } completion:^{
        dispatch_group_leave(disGroup);
    }];
    dispatch_group_wait(disGroup, DISPATCH_TIME_FOREVER);
}

+ (void)art_deleteAllEntiteisForLocalContext:(NSManagedObjectContext *)localContext
{
    [self MR_deleteAllMatchingPredicate:nil inContext:localContext];
}

+ (id)art_baseUpdateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    //LOG(@"resultDict :%@", resultDict);
    EntityBase *entity = [ARTCoreDataFetcher entityForIdentifier:@([resultDict[@"id"] integerValue]) managedObject:self localContext:localContext];
    entity.identifier = [ARTUtils nullCheckWithObject:resultDict[@"id"] isNumeric:YES];
    if (!resultDict[@"created"] || [resultDict[@"created"] isEqual:[NSNull null]]) {
        entity.created = nil;
    } else {
        entity.created = [NSDate art_formatForDateStringYYYYMMDD_HHMMSS:resultDict[@"created"]];
    }
    
    entity.name = [ARTUtils nullCheckWithObject:resultDict[@"name"] isNumeric:NO];
    
    if (!resultDict[@"modified"] || [resultDict[@"modified"] isEqual:[NSNull null]]) {
        entity.modified = nil;
    } else {
        entity.modified = [NSDate art_formatForDateStringYYYYMMDD_HHMMSS:resultDict[@"modified"]];
    }
    if (!resultDict[@"deleted"] || [resultDict[@"deleted"] isEqual:[NSNull null]]) {
        entity.dataDeleted = nil;
    } else {
        entity.dataDeleted = [NSDate art_formatForDateStringYYYYMMDD_HHMMSS:resultDict[@"deleted"]];
    }
    if (resultDict[@"sort"] && ![resultDict[@"sort"] isEqual:[NSNull null]]) {
        entity.sort = @([resultDict[@"sort"] intValue]);
    }
    
    if (resultDict[@"display_flg"] && ![resultDict[@"display_flg"] isEqual:[NSNull null]]) {
        entity.displayFlg = @([resultDict[@"display_flg"] boolValue]);
    } else {
        entity.displayFlg = @YES;
    }
    
    //LOG(@"entity : %@", entity);
    //LOG(@"entity.name : %@", entity.name);
    
    return entity;
}

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    return [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
}

+ (id)art_fetchForLocalContext:(NSManagedObjectContext *)localContext
               predicateFormat:(NSString *)predicateFormat
                 argumentArray:(NSArray *)arguments
                    isFirstObj:(BOOL)isFirstObj
                    fetchLimit:(NSInteger)fetchLimit
               sortDescriptors:(NSArray *)sortDescriptors
{
    @synchronized(self)
    {
        if (!localContext) {
            localContext = [NSManagedObjectContext MR_contextForCurrentThread];
        }
        
        NSFetchRequest *request = NSFetchRequest.new;
        [request setEntity:[NSEntityDescription entityForName:NSStringFromClass(self)
                                       inManagedObjectContext:localContext]];
        
        if (predicateFormat) {
            [request setPredicate:[NSPredicate predicateWithFormat:predicateFormat argumentArray:arguments]];
        }
        if (sortDescriptors) {
            [request setSortDescriptors:sortDescriptors];
        }
        if (isFirstObj) {
            return [self MR_executeFetchRequestAndReturnFirstObject:request inContext:localContext];
        }
        if (fetchLimit > 0) {
            [request setFetchLimit:fetchLimit];
        }
        return [self MR_executeFetchRequest:request inContext:localContext];
    }
}

+ (id)art_onceEntitiyForId:(NSNumber *)identifier localContext:(NSManagedObjectContext *)localContext
{
    id entity = [self art_fetchForLocalContext:localContext
                               predicateFormat:@"identifier == %@ AND dataDeleted == NULL AND displayFlg == YES"
                                 argumentArray:@[identifier]
                                    isFirstObj:YES
                                    fetchLimit:1
                               sortDescriptors:nil];
    return entity;
}

+ (NSArray *)art_sortEntityForLocalContext:(NSManagedObjectContext *)localContext
                           predicateFormat:(NSString *)predicateFormat
                             argumentArray:(NSArray *)arguments
                                fetchLimit:(NSInteger)fetchLimit
                                 assending:(BOOL)assending
{
    NSArray *result = [self art_fetchForLocalContext:localContext
                                     predicateFormat:predicateFormat
                                       argumentArray:arguments
                                          isFirstObj:NO
                                          fetchLimit:fetchLimit
                                     sortDescriptors:@[[[NSSortDescriptor alloc] initWithKey:@"sort" ascending:assending]]];
    return result;
}

+ (NSString *)art_nameForId:(NSNumber *)identifier
{
    if (!identifier) { return nil; }
    
    EntityBase *entity = [self art_onceEntitiyForId:identifier localContext:nil];
    if (entity.name) {
        return entity.name;
    } else {
        return @"";
    }
}

@end

@implementation Prefecture (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    Prefecture *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.areaId = [ARTUtils nullCheckWithObject:resultDict[@"area_id"] isNumeric:YES];
    
    return entity;
}

+ (NSArray *)art_allEntiteisByAreaId:(NSNumber *)areaId
{
    if (!areaId) { return nil; }
    
    NSArray *result = [self art_sortEntityForLocalContext:nil
                                          predicateFormat:@"areaId == %@ AND dataDeleted == NULL AND displayFlg == YES"
                                            argumentArray:@[areaId]
                                               fetchLimit:0
                                                assending:YES];
    return result;
}

// todo : 今だけの暫定（関東の指定のみ）
+ (NSArray *)art_allEntiteisForFirstApp
{
    NSArray *array  = @[@11, @12, @13, @14];
    NSArray *result = [self art_sortEntityForLocalContext:nil
                                          predicateFormat:@"identifier in %@ AND dataDeleted == NULL AND displayFlg == YES"
                                            argumentArray:@[array]
                                               fetchLimit:0
                                                assending:YES];
    return result;
}

@end

@implementation City (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    City *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.prefectureId = [ARTUtils nullCheckWithObject:resultDict[@"prefecture_id"] isNumeric:YES];
    
    return entity;
}

+ (NSArray *)art_allEntiteisByPrefectureId:(NSNumber *)prefectureId
{
    if (!prefectureId) { return nil; }
    
    NSArray *result = [self art_sortEntityForLocalContext:nil
                                          predicateFormat:@"prefectureId == %@ AND dataDeleted == NULL AND displayFlg == YES"
                                            argumentArray:@[prefectureId]
                                               fetchLimit:0
                                                assending:YES];
    return result;
}

@end

@implementation Generation (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    Generation *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.ageFrom = [ARTUtils nullCheckWithObject:resultDict[@"age_from"] isNumeric:YES];
    entity.ageTo   = [ARTUtils nullCheckWithObject:resultDict[@"age_to"] isNumeric:YES];
    
    return entity;
}

+ (NSString *)art_generationForAge:(NSNumber *)age
{
    if (!age) { return nil; }
    
    Generation *result = [self art_fetchForLocalContext:nil
                                        predicateFormat:@"ageFrom <= %@ AND ageTo >= %@ AND dataDeleted == NULL AND displayFlg == YES"
                                          argumentArray:@[age, age]
                                             isFirstObj:YES
                                             fetchLimit:1
                                        sortDescriptors:nil];
    
    if (result) {
        return result.name;
    }
    return nil;
}

@end

@implementation JobType (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    JobType *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.jobTypeCategoryId = [ARTUtils nullCheckWithObject:resultDict[@"job_type_category_id"] isNumeric:YES];
    
    return entity;
}

+ (NSArray *)art_allEntiteisByJobTypeCategoryId:(NSString *)jobTypeCategoryId
{
    if (!jobTypeCategoryId) { return nil; }
    
    NSArray *result = [self art_sortEntityForLocalContext:nil
                                          predicateFormat:@"jobTypeCategoryId == %@ AND dataDeleted == NULL AND displayFlg == YES"
                                            argumentArray:@[jobTypeCategoryId]
                                               fetchLimit:0
                                                assending:YES];
    return result;
}

@end

@implementation School (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    School *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.schoolTypeId = [ARTUtils nullCheckWithObject:resultDict[@"school_type_id"] isNumeric:YES];
    entity.prefectureId = [ARTUtils nullCheckWithObject:resultDict[@"prefecture_id"] isNumeric:YES];
    //LOG(@"entity : %@", entity);
    //LOG(@"entity.name : %@", entity.name);
    
    return entity;
}

+ (NSArray *)art_searchHighSchoolBySchoolNameText:(NSString *)schoolNameText
{
    return [self art_searchBySchoolNameText:schoolNameText schoolTypeId:@1];
}

+ (NSArray *)art_searchUnivercityBySchoolNameText:(NSString *)schoolNameText
{
    return [self art_searchBySchoolNameText:schoolNameText schoolTypeId:@4];
}

+ (NSArray *)art_searchJuniorCollegeBySchoolNameText:(NSString *)schoolNameText
{
    return [self art_searchBySchoolNameText:schoolNameText schoolTypeId:@2];
}

+ (NSArray *)art_searchBySchoolNameText:(NSString *)schoolNameText schoolTypeId:(NSNumber *)schoolTypeId
{
    if (!schoolNameText || !schoolTypeId) { return nil; }
    
    NSArray *result = [self art_sortEntityForLocalContext:nil
                                          predicateFormat:@"name contains %@ AND schoolTypeId == %@ AND dataDeleted == NULL AND displayFlg == YES"
                                            argumentArray:@[schoolNameText, schoolTypeId]
                                               fetchLimit:100
                                                assending:YES];
    return result;
}

@end

@implementation Staff (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    //LOG(@"resultDict : %@", resultDict);
    
    Staff *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.name                 = [ARTUtils nullCheckWithObject:resultDict[@"nickname"] isNumeric:NO];
    entity.pickupStaffFlg       = [ARTUtils nullCheckWithObject:resultDict[@"pickup_staff_flg"] isNumeric:YES];
    entity.pickupStaffSort      = [ARTUtils nullCheckWithObject:resultDict[@"pickup_staff_sort"] isNumeric:YES];
    entity.recommendStaffFlg    = [ARTUtils nullCheckWithObject:resultDict[@"recommend_staff_flg"] isNumeric:YES];
    entity.recommendStaffSort   = [ARTUtils nullCheckWithObject:resultDict[@"recommend_staff_sort"] isNumeric:YES];
    entity.sexId                = [ARTUtils nullCheckWithObject:resultDict[@"sex_id"] isNumeric:YES];
    entity.shopId               = [ARTUtils nullCheckWithObject:resultDict[@"shop_id"] isNumeric:YES];
    entity.hobbyId              = [ARTUtils nullCheckWithObject:resultDict[@"hobby_id"] isNumeric:YES];
    entity.hobbyComment         = [ARTUtils nullCheckWithObject:resultDict[@"hobby_comment"] isNumeric:NO];
    entity.hometownPrefectureId = [ARTUtils nullCheckWithObject:resultDict[@"hometown_prefecture_id"] isNumeric:YES];
    entity.futureGoalId         = [ARTUtils nullCheckWithObject:resultDict[@"future_goal_id"] isNumeric:YES];
    entity.futureGoalComment    = [ARTUtils nullCheckWithObject:resultDict[@"future_goal_comment"] isNumeric:NO];
    entity.thumbnailURL         = [ARTUtils nullCheckWithObject:resultDict[@"work_image_s_url"] isNumeric:NO];
    entity.thumbnailURL2        = [ARTUtils nullCheckWithObject:resultDict[@"work_image_s2_url"] isNumeric:NO];
    entity.workImageURL         = [ARTUtils nullCheckWithObject:resultDict[@"work_image_url"] isNumeric:NO];
    entity.privateImageURL      = [ARTUtils nullCheckWithObject:resultDict[@"private_image_url"] isNumeric:NO];
    entity.favoriteCount        = [ARTUtils nullCheckWithObject:resultDict[@"favorite_cnt"] isNumeric:YES];
    entity.accessCount          = [ARTUtils nullCheckWithObject:resultDict[@"access_cnt"] isNumeric:YES];
    entity.collegeId            = [ARTUtils nullCheckWithObject:resultDict[@"college_id"] isNumeric:YES];
    entity.highschoolId         = [ARTUtils nullCheckWithObject:resultDict[@"highschool_id"] isNumeric:YES];
    entity.generationId         = [ARTUtils nullCheckWithObject:resultDict[@"generation_id"] isNumeric:YES];
    entity.cityId               = [ARTUtils nullCheckWithObject:resultDict[@"city_id"] isNumeric:YES];
    
    if (!resultDict[@"birthday"] || [resultDict[@"birthday"] isEqual:[NSNull null]]) {
        entity.birthday = nil;
    } else {
        entity.birthday = [NSDate art_formatForDateStringYYYYMMDD_HHMMSS:resultDict[@"birthday"]];
    }
    
    if (resultDict[@"answer_private"] && ![resultDict[@"answer_private"] isEqual:[NSNull null]]) {
        NSData       *data      = [resultDict[@"answer_private"] dataUsingEncoding:NSUTF8StringEncoding];
        NSError      *jsonError = nil;
        NSDictionary *json      = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
        entity.privateAnswers = json;
    }
    
    if (resultDict[@"answer_work"] && ![resultDict[@"answer_work"] isEqual:[NSNull null]]) {
        NSData       *data      = [resultDict[@"answer_work"] dataUsingEncoding:NSUTF8StringEncoding];
        NSError      *jsonError = nil;
        NSDictionary *json      = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
        entity.workAnswers = json;
    }
    
    if (resultDict[@"answer_favorite"] && ![resultDict[@"answer_favorite"] isEqual:[NSNull null]]) {
        NSData       *data      = [resultDict[@"answer_favorite"] dataUsingEncoding:NSUTF8StringEncoding];
        NSError      *jsonError = nil;
        NSDictionary *json      = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
        entity.favoriteAnswers = json;
    }
    
    if (resultDict[@"answer_other"] && ![resultDict[@"answer_other"] isEqual:[NSNull null]]) {
        NSData       *data      = [resultDict[@"answer_other"] dataUsingEncoding:NSUTF8StringEncoding];
        NSError      *jsonError = nil;
        NSDictionary *json      = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
        entity.otherAnswers = json;
    }
    
    //LOG(@"entity : %@", entity);
    return entity;
}

+ (void)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict
                                 localContext:(NSManagedObjectContext *)localContext
                                     listType:(ARTRankListType)listType
{
    Staff *entity = [self art_updateOrInsertEntityForResultDict:resultDict localContext:localContext];
    if (listType == ARTRankListTypeAccess) {
        entity.isContainsRankAccess = @YES;
    } else if (listType == ARTRankListTypeAruto) {
        entity.isContainsRankAruto = @YES;
    } else if (listType == ARTRankListTypeMale) {
        entity.isContainsRankMale = @YES;
    } else if (listType == ARTRankListTypeFemale) {
        entity.isContainsRankFemale = @YES;
    } else if (listType == ARTRankListTypePickup) {
        entity.isContainsRankPickup = @YES;
    }
}

+ (void)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict
                                 localContext:(NSManagedObjectContext *)localContext
                             searchIdentifier:(NSString *)searchIdentifier
{
    Staff *entity = [self art_updateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.searchIdentifier = [ARTSearchManager shared].searchIndentifier;
}

+ (Staff *)art_topStaffForListType:(ARTRankListType)listType
{
    NSArray *array = [self art_listForListType:listType fetchCount:1];
    if (array && array.count) {
        return array[0];
    }
    return nil;
}

+ (NSArray *)art_staffListForListType:(ARTRankListType)listType
{
    return [self art_listForListType:listType fetchCount:20];
}

+ (NSArray *)art_listForListType:(ARTRankListType)listType fetchCount:(NSInteger)fetchCount
{
    @synchronized(self)
    {
        NSArray *array = nil;
        
        NSFetchRequest *request = [[NSFetchRequest alloc] init];
        
        if (listType == ARTRankListTypePickup) {
            [request setPredicate:[NSPredicate predicateWithFormat:@"isContainsRankPickup == YES AND dataDeleted == NULL AND displayFlg == YES"]];
            [request setSortDescriptors:@[[[NSSortDescriptor alloc] initWithKey:@"pickupStaffSort" ascending:YES]]];
        } else if (listType == ARTRankListTypeAccess) {
            [request setPredicate:[NSPredicate predicateWithFormat:@"isContainsRankAccess == YES AND dataDeleted == NULL AND displayFlg == YES"]];
            [request setSortDescriptors:@[[[NSSortDescriptor alloc] initWithKey:@"accessCount" ascending:NO]]];
        } else if (listType == ARTRankListTypeAruto) {
            [request setPredicate:[NSPredicate predicateWithFormat:@"isContainsRankAruto == YES AND dataDeleted == NULL AND displayFlg == YES"]];
            [request setSortDescriptors:@[[[NSSortDescriptor alloc] initWithKey:@"recommendStaffSort" ascending:NO]]];
        } else if (listType == ARTRankListTypeMale) {
            [request setPredicate:[NSPredicate predicateWithFormat:@"isContainsRankMale == YES AND dataDeleted == NULL AND displayFlg == YES"]];
            [request setSortDescriptors:@[[[NSSortDescriptor alloc] initWithKey:@"favoriteCount" ascending:NO]]];
        } else if (listType == ARTRankListTypeFemale) {
            [request setPredicate:[NSPredicate predicateWithFormat:@"isContainsRankFemale == YES AND dataDeleted == NULL AND displayFlg == YES"]];
            [request setSortDescriptors:@[[[NSSortDescriptor alloc] initWithKey:@"favoriteCount" ascending:NO]]];
        }
        [request setEntity:[NSEntityDescription entityForName:NSStringFromClass(self)
                                       inManagedObjectContext:[NSManagedObjectContext MR_contextForCurrentThread]]];
        [request setFetchLimit:fetchCount];
        array = [self MR_executeFetchRequest:request];
        
        return array;
    }
}

+ (NSArray *)art_staffListForShopId:(NSNumber *)shopId
{
    if (!shopId) { return nil; }
    
    NSArray *result = [self art_sortEntityForLocalContext:nil
                                          predicateFormat:@"shopId == %@ AND dataDeleted == NULL AND displayFlg == YES"
                                            argumentArray:@[shopId]
                                               fetchLimit:0
                                                assending:YES];
    return result;
}

+ (Staff *)art_staffWithStaffId:(NSNumber *)staffId localContext:(NSManagedObjectContext *)localContext
{
    if (!staffId) { return nil; }
    
    Staff *entity = [self art_fetchForLocalContext:localContext
                                   predicateFormat:@"identifier == %@ AND dataDeleted == NULL AND displayFlg == YES"
                                     argumentArray:@[staffId]
                                        isFirstObj:YES
                                        fetchLimit:1
                                   sortDescriptors:nil];
    return entity;
}

+ (NSArray *)art_allFavoriteEntiteis
{
    NSArray *favoriteArray = [FavoriteStaff art_allFavoriteStaffIds];
    if (!favoriteArray || !favoriteArray.count) {
        return nil;
    }
    
    NSArray *result = [self art_sortEntityForLocalContext:nil
                                          predicateFormat:@"identifier in %@ AND dataDeleted == NULL AND displayFlg == YES"
                                            argumentArray:@[favoriteArray]
                                               fetchLimit:0
                                                assending:YES];
    return result;
}

+ (NSArray *)art_searchResultEntities
{
    NSArray *result = [self art_sortEntityForLocalContext:nil
                                          predicateFormat:@"searchIdentifier == %@ AND dataDeleted == NULL AND displayFlg == YES"
                                            argumentArray:@[[ARTSearchManager shared].searchIndentifier]
                                               fetchLimit:0
                                                assending:YES];
    return result;
}

@end

@implementation Shop (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    //LOG(@"resultDict : %@", resultDict);
    
    Shop *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.branchName     = [ARTUtils nullCheckWithObject:resultDict[@"branch_name"] isNumeric:NO];
    entity.address1       = [ARTUtils nullCheckWithObject:resultDict[@"address1"] isNumeric:NO];
    entity.address2       = [ARTUtils nullCheckWithObject:resultDict[@"address2"] isNumeric:NO];
    entity.address3       = [ARTUtils nullCheckWithObject:resultDict[@"address3"] isNumeric:NO];
    entity.ageAverage     = [ARTUtils nullCheckWithObject:resultDict[@"age_average"] isNumeric:NO];
    entity.gendarRatio    = [ARTUtils nullCheckWithObject:resultDict[@"gender_ratio"] isNumeric:NO];
    entity.businessHour   = [ARTUtils nullCheckWithObject:resultDict[@"business_hour"] isNumeric:NO];
    entity.businessTypeId = [ARTUtils nullCheckWithObject:resultDict[@"business_type_id"] isNumeric:YES];
    entity.companyId      = [ARTUtils nullCheckWithObject:resultDict[@"company_id"] isNumeric:YES];
    entity.businessHour   = [ARTUtils nullCheckWithObject:resultDict[@"business_hour"] isNumeric:NO];
    entity.leaderComment  = [ARTUtils nullCheckWithObject:resultDict[@"leader_comment"] isNumeric:NO];
    entity.prefectureId   = [ARTUtils nullCheckWithObject:resultDict[@"prefecture_id"] isNumeric:YES];
    entity.shopFeature    = [ARTUtils nullCheckWithObject:resultDict[@"shop_feature"] isNumeric:NO];
    entity.tel            = [ARTUtils nullCheckWithObject:resultDict[@"tel"] isNumeric:NO];
    entity.thumbnailURL   = [ARTUtils nullCheckWithObject:resultDict[@"image1_s_url"] isNumeric:NO];
    entity.image1URL      = [ARTUtils nullCheckWithObject:resultDict[@"image1_url"] isNumeric:NO];
    entity.image2URL      = [ARTUtils nullCheckWithObject:resultDict[@"image2_url"] isNumeric:NO];
    entity.image3URL      = [ARTUtils nullCheckWithObject:resultDict[@"image3_url"] isNumeric:NO];
    
    if (resultDict[@"nearest_station"] && ![resultDict[@"nearest_station"] isEqual:[NSNull null]]) {
        NSData       *data      = [resultDict[@"nearest_station"] dataUsingEncoding:NSUTF8StringEncoding];
        NSError      *jsonError = nil;
        NSDictionary *json      = [NSJSONSerialization JSONObjectWithData:data options:0 error:&jsonError];
        //LOG(@"nearest_station json : %@", json);
        
        NSArray *nearestStations = json[@"NearestStation"];
        if (nearestStations && nearestStations.count > 0) {
            NSDictionary *dict = nearestStations[0];
            
            NSMutableString *accessString = [NSMutableString string];
            
            //LOG(@"dict : %@", dict);
            if (dict[@"train_line"] && ![dict[@"train_line"] isEqual:[NSNull null]]) {
                [accessString appendString:dict[@"train_line"]];
            }
            if (dict[@"train_station"] && ![dict[@"train_station"] isEqual:[NSNull null]]) {
                [accessString appendString:dict[@"train_station"]];
            }
            if (dict[@"access_method_id"] && ![dict[@"access_method_id"] isEqual:[NSNull null]]) {
                [accessString appendString:[AccessMethod art_nameForId:@([dict[@"access_method_id"] intValue])]];
            }
            if (dict[@"access_time"] && ![dict[@"access_time"] isEqual:[NSNull null]]) {
                [accessString appendString:dict[@"access_time"]];
            }
            
            entity.access = accessString;
        }
    }
    
    //LOG(@"entity : %@", entity);
    
    return entity;
}

+ (void)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict
                                 localContext:(NSManagedObjectContext *)localContext
                             searchIdentifier:(NSString *)searchIdentifier
{
    Shop *entity = [self art_updateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.searchIdentifier = [ARTSearchManager shared].searchIndentifier;
}

+ (NSArray *)art_allFavoriteEntiteis
{
    NSArray *favoriteArray = [FavoriteShop art_allFavoriteShopIds];
    if (!favoriteArray || !favoriteArray.count) {
        return nil;
    }
    
    NSArray *result = [self art_sortEntityForLocalContext:nil
                                          predicateFormat:@"identifier in %@ AND dataDeleted == NULL AND displayFlg == YES"
                                            argumentArray:@[favoriteArray]
                                               fetchLimit:0
                                                assending:YES];
    return result;
}

+ (NSArray *)art_searchResultEntities
{
    NSArray *result = [self art_sortEntityForLocalContext:nil
                                          predicateFormat:@"searchIdentifier == %@ AND dataDeleted == NULL AND displayFlg == YES"
                                            argumentArray:@[[ARTSearchManager shared].searchIndentifier]
                                               fetchLimit:0
                                                assending:YES];
    return result;
}

+ (Shop *)art_shopWithShopId:(NSNumber *)shopId localContext:(NSManagedObjectContext *)localContext
{
    if (!shopId) { return nil; }
    
    Shop *entity = [self art_fetchForLocalContext:localContext
                                  predicateFormat:@"identifier == %@ AND dataDeleted == NULL AND displayFlg == YES"
                                    argumentArray:@[shopId]
                                       isFirstObj:YES
                                       fetchLimit:1
                                  sortDescriptors:nil];
    return entity;
}

+ (NSString *)art_shopNameForShop:(Shop *)shop
{
    if (shop.name && shop.branchName) {
        return [NSString stringWithFormat:@"%@ %@", shop.name, shop.branchName];
    } else if (shop.name) {
        return shop.name.copy;
    }
    return nil;
}

@end

@implementation Job (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    //LOG(@"resultDict : %@", resultDict);
    
    Job *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.bonus           = [ARTUtils nullCheckWithObject:resultDict[@"bonus"] isNumeric:NO];
    entity.jobTypeId       = [ARTUtils nullCheckWithObject:resultDict[@"job_type_id"] isNumeric:YES];
    entity.companyId       = [ARTUtils nullCheckWithObject:resultDict[@"company_id"] isNumeric:YES];
    entity.hireNumber      = [ARTUtils nullCheckWithObject:resultDict[@"hire_number"] isNumeric:YES];
    entity.salary          = [ARTUtils nullCheckWithObject:resultDict[@"salary"] isNumeric:NO];
    entity.salaryDay       = [ARTUtils nullCheckWithObject:resultDict[@"salary_day"] isNumeric:YES];
    entity.salaryHour      = [ARTUtils nullCheckWithObject:resultDict[@"salary_hour"] isNumeric:YES];
    entity.salaryMonth     = [ARTUtils nullCheckWithObject:resultDict[@"salary_month"] isNumeric:YES];
    entity.shopId          = [ARTUtils nullCheckWithObject:resultDict[@"shop_id"] isNumeric:YES];
    entity.title           = [ARTUtils nullCheckWithObject:resultDict[@"title"] isNumeric:NO];
    entity.workDay         = [ARTUtils nullCheckWithObject:resultDict[@"work_day"] isNumeric:NO];
    entity.workDescription = [ARTUtils nullCheckWithObject:resultDict[@"work_description"] isNumeric:NO];
    entity.workHour        = [ARTUtils nullCheckWithObject:resultDict[@"work_hour"] isNumeric:NO];
    entity.workHourFrom    = [ARTUtils nullCheckWithObject:resultDict[@"work_hour_from"] isNumeric:NO];
    entity.workHourTo      = [ARTUtils nullCheckWithObject:resultDict[@"work_hour_to"] isNumeric:NO];
    entity.workPeriod      = [ARTUtils nullCheckWithObject:resultDict[@"work_period"] isNumeric:NO];
    entity.workPlace       = [ARTUtils nullCheckWithObject:resultDict[@"work_place"] isNumeric:NO];
    entity.workDayTypeId   = [ARTUtils nullCheckWithObject:resultDict[@"work_day_type_id"] isNumeric:YES];
    
    if (!resultDict[@"display_begin"] || [resultDict[@"display_begin"] isEqual:[NSNull null]]) {
        entity.displayBegin = nil;
    } else {
        entity.displayBegin = [NSDate art_formatForDateStringYYYYMMDD_HHMMSS:resultDict[@"display_begin"]];
    }
    if (!resultDict[@"display_end"] || [resultDict[@"display_end"] isEqual:[NSNull null]]) {
        entity.displayEnd = nil;
    } else {
        entity.displayEnd = [NSDate art_formatForDateStringYYYYMMDD_HHMMSS:resultDict[@"display_end"]];
    }
    
    //LOG(@"entity : %@", entity);
    
    return entity;
}

+ (NSArray *)art_jobListForShopId:(NSNumber *)shopId
{
    if (!shopId) { return nil; }
    
    NSArray *result = [self art_sortEntityForLocalContext:nil
                                          predicateFormat:@"shopId == %@ AND dataDeleted == NULL AND displayFlg == YES"
                                            argumentArray:@[shopId]
                                               fetchLimit:0
                                                assending:YES];
    return result;
}

+ (Job *)art_jobWithJobId:(NSNumber *)jobId localContext:(NSManagedObjectContext *)localContext
{
    if (!jobId) { return nil; }
    
    Job *entity = [self art_fetchForLocalContext:localContext
                                 predicateFormat:@"identifier == %@ AND dataDeleted == NULL AND displayFlg == YES"
                                   argumentArray:@[jobId]
                                      isFirstObj:YES
                                      fetchLimit:1
                                 sortDescriptors:nil];
    return entity;
}

@end

@implementation Hobby (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    Hobby *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.hobbyTypeId = [ARTUtils nullCheckWithObject:resultDict[@"hobby_type_id"] isNumeric:YES];
    
    return entity;
}

+ (NSArray *)art_allEntiteisByHobbyTypeId:(NSNumber *)hobbyTypeId
{
    if (!hobbyTypeId) { return nil; }
    
    NSArray *result = [self art_sortEntityForLocalContext:nil
                                          predicateFormat:@"hobbyTypeId == %@ AND dataDeleted == NULL AND displayFlg == YES"
                                            argumentArray:@[hobbyTypeId]
                                               fetchLimit:0
                                                assending:YES];
    return result;
}

@end

@implementation User (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict
                              jobSeekerDict:(NSDictionary *)jobSeekerDict
                               localContext:(NSManagedObjectContext *)localContext
{
    User *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.identifier = @([resultDict[@"id"] integerValue]);
    entity.jobSeekerId           = [ARTUtils nullCheckWithObject:resultDict[@"job_seeker_id"] isNumeric:YES];
    entity.notificationForAllflg = [ARTUtils nullCheckWithObject:resultDict[@"notification_for_all_flg"] isNumeric:YES];
    entity.notificationForYouflg = [ARTUtils nullCheckWithObject:resultDict[@"notification_for_you_flg"] isNumeric:YES];
    
    if (!jobSeekerDict) {
        return entity;
    }
    
    entity.firstName     = [ARTUtils nullCheckWithObject:jobSeekerDict[@"name1"] isNumeric:NO];
    entity.lastName      = [ARTUtils nullCheckWithObject:jobSeekerDict[@"name2"] isNumeric:NO];
    entity.firstNameKana = [ARTUtils nullCheckWithObject:jobSeekerDict[@"name1_kana"] isNumeric:NO];
    entity.lastNameKana  = [ARTUtils nullCheckWithObject:jobSeekerDict[@"name2_kana"] isNumeric:NO];
    entity.tel           = [ARTUtils nullCheckWithObject:jobSeekerDict[@"tel"] isNumeric:NO];
    entity.contactType   = [ARTUtils nullCheckWithObject:jobSeekerDict[@"contact_method"] isNumeric:NO];
    if (!jobSeekerDict[@"birthday"] || [jobSeekerDict[@"birthday"] isEqual:[NSNull null]]) {
        entity.birthDayDate = nil;
    } else {
        entity.birthDayDate = [NSDate art_formatForDateStringYYYYMMDD_HHMMSS:jobSeekerDict[@"birthday"]];
    }
    
    //LOG(@"entityentity : %@", entity);
    
    return entity;
}

+ (id)art_updateEntityForJobSeekerDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    User *entity = [User art_userForLocalContext:localContext];
    if (!entity) {
        return nil;
    }
    entity.firstName     = [ARTUtils nullCheckWithObject:resultDict[@"name1"] isNumeric:NO];
    entity.lastName      = [ARTUtils nullCheckWithObject:resultDict[@"name2"] isNumeric:NO];
    entity.firstNameKana = [ARTUtils nullCheckWithObject:resultDict[@"name1_kana"] isNumeric:NO];
    entity.lastNameKana  = [ARTUtils nullCheckWithObject:resultDict[@"name2_kana"] isNumeric:NO];
    entity.tel           = [ARTUtils nullCheckWithObject:resultDict[@"tel"] isNumeric:NO];
    entity.contactType   = [ARTUtils nullCheckWithObject:resultDict[@"contact_method"] isNumeric:NO];
    if (!resultDict[@"birthday"] || [resultDict[@"birthday"] isEqual:[NSNull null]]) {
        entity.birthDayDate = nil;
    } else {
        entity.birthDayDate = [NSDate art_formatForDateStringYYYYMMDD_HHMMSS:resultDict[@"birthday"]];
    }
    
    return entity;
}

+ (User *)art_userForLocalContext:(NSManagedObjectContext *)localContext
{
    User *entity = [self art_fetchForLocalContext:localContext
                                  predicateFormat:@"identifier != NULL AND dataDeleted == NULL"
                                    argumentArray:nil
                                       isFirstObj:YES
                                       fetchLimit:1
                                  sortDescriptors:nil];
    return entity;
}

+ (NSNumber *)art_userId
{
    return [self art_userForLocalContext:nil].identifier;
}

@end

@implementation StaffOtherQuestion (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    StaffOtherQuestion *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.title        = [ARTUtils nullCheckWithObject:resultDict[@"title"] isNumeric:NO];
    entity.questionType = [ARTUtils nullCheckWithObject:resultDict[@"question_type"] isNumeric:NO];
    
    return entity;
}

+ (NSString *)art_questionTitleForName:(NSString *)name
{
    if (!name) { return nil; }
    StaffOtherQuestion *entity = [self art_fetchForLocalContext:nil
                                                predicateFormat:@"name == %@ AND dataDeleted == NULL"
                                                  argumentArray:@[name]
                                                     isFirstObj:YES
                                                     fetchLimit:1
                                                sortDescriptors:nil];
    return entity.title;
}

@end

@implementation Company (ARTCoreDataFetcher)

@end

@implementation JobJobOtherPoint (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    JobJobOtherPoint *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.jobId           = [ARTUtils nullCheckWithObject:resultDict[@"job_id"] isNumeric:YES];
    entity.jobOtherPointId = [ARTUtils nullCheckWithObject:resultDict[@"job_other_point_id"] isNumeric:YES];
    
    return entity;
}

+ (NSArray *)art_allEntiteisByJobId:(NSNumber *)jobId
{
    if (!jobId) { return nil; }
    
    NSArray *result = [self art_fetchForLocalContext:nil
                                     predicateFormat:@"jobId == %@ AND dataDeleted == NULL AND displayFlg == YES"
                                       argumentArray:@[jobId]
                                          isFirstObj:NO
                                          fetchLimit:0
                                     sortDescriptors:@[[[NSSortDescriptor alloc] initWithKey:@"identifier" ascending:YES]]];
    return result;
}

@end

@implementation TrainLine (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    TrainLine *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.lineName = [ARTUtils nullCheckWithObject:resultDict[@"line_name"] isNumeric:NO];
    entity.lineId   = [ARTUtils nullCheckWithObject:resultDict[@"line_cd"] isNumeric:YES];
    
    return entity;
}

+ (NSArray *)art_searchTrainLineNameText:(NSString *)lineNameText
{
    if (!lineNameText) { return nil; }
    
    NSArray *result = [self art_fetchForLocalContext:nil
                                     predicateFormat:@"lineName contains %@ AND dataDeleted == NULL AND displayFlg == YES"
                                       argumentArray:@[lineNameText]
                                          isFirstObj:NO
                                          fetchLimit:0
                                     sortDescriptors:@[[[NSSortDescriptor alloc] initWithKey:@"identifier" ascending:YES]]];
    return result;
}

+ (NSArray *)art_defaultTrains
{
    NSArray *lineIdArray = @[@11302, @11313, @11312, @26001, @26003, @24006, @28002, @25001];
    NSArray *result = [self art_fetchForLocalContext:nil
                                     predicateFormat:@"lineId in %@ AND dataDeleted == NULL AND displayFlg == YES"
                                       argumentArray:@[lineIdArray]
                                          isFirstObj:NO
                                          fetchLimit:0
                                     sortDescriptors:@[[[NSSortDescriptor alloc] initWithKey:@"identifier" ascending:YES]]];
    return result;
}

@end

@implementation TrainStation (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    TrainStation *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.stationName = [ARTUtils nullCheckWithObject:resultDict[@"station_name"] isNumeric:NO];
    entity.lineId      = [ARTUtils nullCheckWithObject:resultDict[@"line_cd"] isNumeric:YES];
    
    return entity;
}

+ (NSArray *)art_allEntiteisByLineId:(NSNumber *)lineId
{
    if (!lineId) { return nil; }
    
    NSArray *result = [self art_fetchForLocalContext:nil
                                     predicateFormat:@"lineId == %@ AND dataDeleted == NULL AND displayFlg == YES"
                                       argumentArray:@[lineId]
                                          isFirstObj:NO
                                          fetchLimit:0
                                     sortDescriptors:@[[[NSSortDescriptor alloc] initWithKey:@"identifier" ascending:YES]]];
    return result;
}

@end

@implementation WorkDayType (ARTCoreDataFetcher)

@end

@implementation AccessMethod (ARTCoreDataFetcher)

@end

@implementation Entry (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    Entry *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    if (!resultDict[@"interview_date"] || [resultDict[@"interview_date"] isEqual:[NSNull null]]) {
        entity.interviewDate = nil;
    } else {
        entity.interviewDate = [NSDate art_formatForDateStringYYYYMMDD_HHMMSS:resultDict[@"interview_date"]];
    }
    entity.entryStatusId = [ARTUtils nullCheckWithObject:resultDict[@"entry_status_id"] isNumeric:YES];
    entity.jobId         = [ARTUtils nullCheckWithObject:resultDict[@"job_id"] isNumeric:YES];
    
    return entity;
}

+ (Entry *)art_findById:(NSNumber *)entryId localContext:(NSManagedObjectContext *)localContext
{
    if (!entryId) { return nil; }
    
    Entry *entity = [self art_fetchForLocalContext:localContext
                                   predicateFormat:@"identifier == %@ AND dataDeleted == NULL AND displayFlg == YES"
                                     argumentArray:@[entryId]
                                        isFirstObj:YES
                                        fetchLimit:1
                                   sortDescriptors:nil];
    
    return entity;
}

@end

@implementation EntryMessage (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    EntryMessage *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.entryId = [ARTUtils nullCheckWithObject:resultDict[@"entry_id"] isNumeric:YES];
    entity.userId  = [ARTUtils nullCheckWithObject:resultDict[@"user_id"] isNumeric:YES];
    entity.message = [ARTUtils nullCheckWithObject:resultDict[@"content"] isNumeric:NO];
    
    return entity;
}

+ (NSArray *)art_allEntiteisByEntryId:(NSNumber *)entryId
{
    if (!entryId) { return nil; }
    
    NSArray *result = [self art_fetchForLocalContext:nil
                                     predicateFormat:@"entryId == %@ AND dataDeleted == NULL"
                                       argumentArray:@[entryId]
                                          isFirstObj:NO
                                          fetchLimit:0
                                     sortDescriptors:@[[[NSSortDescriptor alloc] initWithKey:@"created" ascending:YES]]];
    return result;
}

@end

@implementation FavoriteStaff (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    FavoriteStaff *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.staffId     = [ARTUtils nullCheckWithObject:resultDict[@"staff_id"] isNumeric:YES];
    entity.jobSeekerId = [ARTUtils nullCheckWithObject:resultDict[@"job_seeker_id"] isNumeric:YES];
    
    return entity;
}

+ (NSArray *)art_allFavoriteStaffIds
{
    NSMutableArray *idArray       = [NSMutableArray array];
    NSArray        *favoriteArray = [self art_allNonDeleteEntiteis];
    
    for (FavoriteStaff *entity in favoriteArray) {
        if (entity.staffId) {
            [idArray addObject:entity.staffId.copy];
        }
    }
    return idArray;
}

+ (BOOL)art_isFavoriteForStaffId:(NSNumber *)staffId
{
    if (!staffId) { return NO; }
    
    FavoriteStaff *entity = [self art_fetchForLocalContext:nil
                                           predicateFormat:@"staffId == %@ AND dataDeleted == NULL"
                                             argumentArray:@[staffId]
                                                isFirstObj:YES
                                                fetchLimit:1
                                           sortDescriptors:nil];
    if (entity) {
        return YES;
    }
    return NO;
}

@end

@implementation FavoriteShop (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext
{
    //LOG(@"resultDict : %@", resultDict);
    FavoriteShop *entity = [self art_baseUpdateOrInsertEntityForResultDict:resultDict localContext:localContext];
    entity.shopId      = [ARTUtils nullCheckWithObject:resultDict[@"shop_id"] isNumeric:YES];
    entity.jobSeekerId = [ARTUtils nullCheckWithObject:resultDict[@"job_seeker_id"] isNumeric:YES];
    
    //LOG(@"%@", entity);
    return entity;
}

+ (NSArray *)art_allFavoriteShopIds
{
    NSMutableArray *idArray       = [NSMutableArray array];
    NSArray        *favoriteArray = [self art_allNonDeleteEntiteis];
    
    for (FavoriteShop *entity in favoriteArray) {
        if (entity.shopId) {
            [idArray addObject:entity.shopId.copy];
        }
    }
    return idArray;
}

+ (BOOL)art_isFavoriteForShopId:(NSNumber *)shopId
{
    if (!shopId) { return NO; }
    
    FavoriteShop *entity = [self art_fetchForLocalContext:nil
                                          predicateFormat:@"shopId == %@ AND dataDeleted == NULL"
                                            argumentArray:@[shopId]
                                               isFirstObj:YES
                                               fetchLimit:1
                                          sortDescriptors:nil];
    if (entity) {
        return YES;
    }
    return NO;
}

@end