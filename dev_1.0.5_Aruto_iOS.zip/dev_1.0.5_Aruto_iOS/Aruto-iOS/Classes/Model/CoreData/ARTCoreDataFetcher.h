//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

#import "SchoolType.h"
#import "School.h"
#import "WorkDayType.h"
#import "EntryStatus.h"
#import "SalaryDayType.h"
#import "SalaryHourType.h"
#import "Prefecture.h"
#import "Area.h"
#import "City.h"
#import "JobTypeCategory.h"
#import "JobType.h"
#import "JobOtherPoint.h"
#import "Sex.h"
#import "Staff.h"
#import "Shop.h"
#import "HobbyType.h"
#import "Hobby.h"
#import "Generation.h"
#import "FutureGoal.h"
#import "Job.h"
#import "Entry.h"
#import "User.h"
#import "StaffOtherQuestion.h"
#import "Company.h"
#import "JobJobOtherPoint.h"
#import "TrainLine.h"
#import "TrainStation.h"
#import "AccessMethod.h"
#import "EntryMessage.h"
#import "FavoriteStaff.h"
#import "FavoriteShop.h"

@interface ARTCoreDataFetcher : NSObject

+ (void)setUp;
+ (void)cleanData;
+ (void)cleanUp;
+ (void)saveWithBlock:(void (^)(NSManagedObjectContext *localContext))block
           completion:(void (^)())completion;

@end

@interface EntityBase (ARTCoreDataFetcher)

+ (NSArray *)art_allEntiteis;
+ (NSArray *)art_allNonDeleteEntiteis;
+ (void)art_updateAllEntityDisplayFlag:(BOOL)displayFlag;
+ (void)art_updateEntityDisplayFlagForEntityIds:(NSArray *)entityIdArray;

+ (void)art_deleteAllEntiteis;
+ (void)art_deleteAllEntiteisForLocalContext:(NSManagedObjectContext *)localContext;

+ (id)art_onceEntitiyForId:(NSNumber *)identifier localContext:(NSManagedObjectContext *)localContext;
+ (NSString *)art_nameForId:(NSNumber *)identifier;

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext;

@end

@interface Prefecture (ARTCoreDataFetcher)

+ (NSArray *)art_allEntiteisByAreaId:(NSNumber *)areaId;
+ (NSArray *)art_allEntiteisForFirstApp;

@end

@interface City (ARTCoreDataFetcher)

+ (NSArray *)art_allEntiteisByPrefectureId:(NSNumber *)prefectureId;

@end

@interface Generation (ARTCoreDataFetcher)

+ (NSString *)art_generationForAge:(NSNumber *)age;

@end

@interface JobType (ARTCoreDataFetcher)

+ (NSArray *)art_allEntiteisByJobTypeCategoryId:(NSString *)jobTypeCategoryId;

@end

@interface School (ARTCoreDataFetcher)

+ (NSArray *)art_searchHighSchoolBySchoolNameText:(NSString *)schoolNameText;
+ (NSArray *)art_searchUnivercityBySchoolNameText:(NSString *)schoolNameText;
+ (NSArray *)art_searchJuniorCollegeBySchoolNameText:(NSString *)schoolNameText;

@end

@interface Staff (ARTCoreDataFetcher)

+ (void)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict
                                 localContext:(NSManagedObjectContext *)localContext
                                     listType:(ARTRankListType)listType;

+ (void)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict
                                 localContext:(NSManagedObjectContext *)localContext
                             searchIdentifier:(NSString *)searchIdentifier;

+ (Staff *)art_topStaffForListType:(ARTRankListType)listType;
+ (NSArray *)art_staffListForListType:(ARTRankListType)listType;
+ (NSArray *)art_staffListForShopId:(NSNumber *)shopId;

+ (NSArray *)art_allFavoriteEntiteis;
+ (NSArray *)art_searchResultEntities;

+ (Staff *)art_staffWithStaffId:(NSNumber *)staffId localContext:(NSManagedObjectContext *)localContext;;

@end

@interface Shop (ARTCoreDataFetcher)

+ (void)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict
                                 localContext:(NSManagedObjectContext *)localContext
                             searchIdentifier:(NSString *)searchIdentifier;

+ (NSArray *)art_allFavoriteEntiteis;
+ (NSArray *)art_searchResultEntities;

+ (Shop *)art_shopWithShopId:(NSNumber *)shopId localContext:(NSManagedObjectContext *)localContext;

+ (NSString *)art_shopNameForShop:(Shop *)shop;

@end

@interface Job (ARTCoreDataFetcher)

+ (NSArray *)art_jobListForShopId:(NSNumber *)shopId;

+ (Job *)art_jobWithJobId:(NSNumber *)jobId localContext:(NSManagedObjectContext *)localContext;

@end

@interface Hobby (ARTCoreDataFetcher)

+ (NSArray *)art_allEntiteisByHobbyTypeId:(NSNumber *)hobbyTypeId;

@end

@interface User (ARTCoreDataFetcher)

+ (id)art_updateOrInsertEntityForResultDict:(NSDictionary *)resultDict
                              jobSeekerDict:(NSDictionary *)jobSeekerDict
                               localContext:(NSManagedObjectContext *)localContext;

+ (id)art_updateEntityForJobSeekerDict:(NSDictionary *)resultDict localContext:(NSManagedObjectContext *)localContext;

+ (User *)art_userForLocalContext:(NSManagedObjectContext *)localContext;
+ (NSNumber *)art_userId;

@end

@interface StaffOtherQuestion (ARTCoreDataFetcher)

+ (NSString *)art_questionTitleForName:(NSString *)name;

@end

@interface Company (ARTCoreDataFetcher)


@end

@interface JobJobOtherPoint (ARTCoreDataFetcher)

+ (NSArray *)art_allEntiteisByJobId:(NSNumber *)jobId;

@end

@interface TrainLine (ARTCoreDataFetcher)

+ (NSArray *)art_searchTrainLineNameText:(NSString *)lineNameText;
+ (NSArray *)art_defaultTrains;

@end

@interface TrainStation (ARTCoreDataFetcher)

+ (NSArray *)art_allEntiteisByLineId:(NSNumber *)lineId;

@end

@interface WorkDayType (ARTCoreDataFetcher)

@end

@interface AccessMethod (ARTCoreDataFetcher)


@end

@interface Entry (ARTCoreDataFetcher)

+ (Entry *)art_findById:(NSNumber *)entryId localContext:(NSManagedObjectContext *)localContext;

@end

@interface EntryMessage (ARTCoreDataFetcher)

+ (NSArray *)art_allEntiteisByEntryId:(NSNumber *)entryId;

@end

@interface FavoriteStaff (ARTCoreDataFetcher)

+ (NSArray *)art_allFavoriteStaffIds;

+ (BOOL)art_isFavoriteForStaffId:(NSNumber *)staffId;

@end

@interface FavoriteShop (ARTCoreDataFetcher)

+ (NSArray *)art_allFavoriteShopIds;

+ (BOOL)art_isFavoriteForShopId:(NSNumber *)shopId;

@end