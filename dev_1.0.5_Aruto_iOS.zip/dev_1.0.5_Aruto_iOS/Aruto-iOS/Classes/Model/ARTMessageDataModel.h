//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

#import <JSQMessages.h>

static NSString * const kARTAvatarDefault = @"ARTAvatarDefault";

@interface ARTMessageDataModel : NSObject

@property (strong, nonatomic) NSMutableArray *messages;

@property (strong, nonatomic) NSDictionary *avatars;

@property (strong, nonatomic) JSQMessagesBubbleImage *outgoingBubbleImageData;

@property (strong, nonatomic) JSQMessagesBubbleImage *incomingBubbleImageData;

@property (strong, nonatomic) NSDictionary *users;

@end
