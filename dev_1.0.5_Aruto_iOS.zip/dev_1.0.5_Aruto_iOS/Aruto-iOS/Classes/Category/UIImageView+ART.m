//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "UIImageView+ART.h"

#import <objc/message.h>
#import <UIImageView+WebCache.h>

static const char *ART_ImageURLString_Key = "ART_ImageURLString_Key";

@implementation UIImageView (ART)

- (void)dealloc
{
    objc_setAssociatedObject(self, &ART_ImageURLString_Key, nil, OBJC_ASSOCIATION_ASSIGN);
}

- (void)art_setImageWithURL:(NSURL *)imageURL
           placeholderImage:(UIImage *)placeholderImage
                    noImage:(UIImage *)noImage
                      alpha:(CGFloat)alpha
                 parentView:(UIView *)parentView
              needAnimation:(BOOL)needAnimation
{
    if (!imageURL) {
        self.image = noImage;
        [self art_setAnimation:self alpha:alpha parentView:parentView needAnimation:needAnimation];
        return;
    }
    objc_setAssociatedObject(self, &ART_ImageURLString_Key, imageURL.absoluteString, OBJC_ASSOCIATION_COPY);
    if (parentView) {
        parentView.alpha = 0;
        self.hidden      = YES;
    } else {
        self.alpha = 0;
    }
    if (placeholderImage) {
        self.alpha = 1;
        self.image = placeholderImage;
    }
    
    __weak typeof(self) weakSelf         = self;
    __weak typeof(parentView) weakParent = parentView;
    
    [self sd_setImageWithURL:imageURL
            placeholderImage:placeholderImage
                     options:SDWebImageRetryFailed
                   completed: ^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                       if (!weakSelf) { return; }
                       
                       if (error) {
                           if (noImage) {
                               weakSelf.image = noImage;
                           } else {
                               if (placeholderImage) {
                                   weakSelf.image = placeholderImage;
                               }
                           }
                           [weakSelf art_setAnimation:weakSelf alpha:alpha parentView:weakParent needAnimation:needAnimation];
                           return;
                       }
                       
                       NSString *associatedImageURLString = objc_getAssociatedObject(self, &ART_ImageURLString_Key);
                       if (![associatedImageURLString isEqualToString:imageURL.absoluteString]) {
                           return;
                       }
                       
                       [weakSelf art_setAnimation:weakSelf alpha:alpha parentView:weakParent needAnimation:needAnimation];
                   }];
}

- (void)art_setAnimation:(UIImageView *)imageView
                   alpha:(CGFloat)alpha
              parentView:(UIView *)parentView
           needAnimation:(BOOL)needAnimation
{
    [UIView animateWithDuration:0.28
                          delay:0
                        options:UIViewAnimationOptionTransitionCrossDissolve | UIViewAnimationOptionCurveLinear | UIViewAnimationOptionAllowUserInteraction
                     animations: ^{
                         if (parentView) {
                             imageView.hidden = NO;
                             parentView.alpha = alpha;
                         } else {
                             imageView.alpha = alpha;
                         }
                         if (needAnimation) {
                             [ARTPopping zoomAnimationWithView:imageView];
                         }
                     } completion: ^(BOOL finished) {
                     }];
}

@end
