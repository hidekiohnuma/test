//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

@interface UIView (ARTGeometory)

@property (nonatomic) CGFloat left;
@property (nonatomic) CGFloat top;
@property (nonatomic) CGFloat right;
@property (nonatomic) CGFloat bottom;
@property (nonatomic) CGFloat width;
@property (nonatomic) CGFloat height;

@end
