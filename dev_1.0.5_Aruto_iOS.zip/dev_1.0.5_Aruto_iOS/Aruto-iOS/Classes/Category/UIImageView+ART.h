//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

@interface UIImageView (ART)

- (void)art_setImageWithURL:(NSURL *)imageURL
           placeholderImage:(UIImage *)placeholderImage
                    noImage:(UIImage *)noImage
                      alpha:(CGFloat)alpha
                 parentView:(UIView *)parentView
              needAnimation:(BOOL)needAnimation;

@end
