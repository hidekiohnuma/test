//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "UIApplication+ARTNetworkActivityIndicator.h"

static NSInteger art_requestCount_ = 0;

@implementation UIApplication (ARTNetworkActivityIndicator)

+ (void)art_updateNetworkActivityIndicator
{
    dispatch_async(dispatch_get_main_queue(), ^{
            [UIApplication sharedApplication].networkActivityIndicatorVisible = (0 < art_requestCount_);
        });
}

+ (void)art_pushNetworkActivityIndicator
{
    @synchronized(self)
    {
        ++art_requestCount_;
    }
    [[self class] art_updateNetworkActivityIndicator];
}

+ (void)art_popNetworkActivityIndicator
{
    @synchronized(self)
    {
        --art_requestCount_;
        if (art_requestCount_ < 0) {
            art_requestCount_ = 0;
        }
    }
    [[self class] art_updateNetworkActivityIndicator];
}

+ (void)art_resetNetworkActivityIndicator
{
    art_requestCount_ = 0;
    [[self class] art_updateNetworkActivityIndicator];
}

+ (NSInteger)art_requestCount
{
    return art_requestCount_;
}

@end
