//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

@interface NSDate (ART)

/**
 *  Locale, TimeZone, Calendarを設定したNSDateFormatterを返す
 *
 *  @return NSDateFormatter
 */
+ (NSDateFormatter *)art_defaultFormatter;

/**
 *  曜日の文字列配列を返す
 *
 *  @return @[@"日", @"月", @"火", @"水", @"木", @"金", @"土"]
 */
+ (NSArray *)art_weekSymbol;

// -------------------------------------------------------------------------------------------------------------------------------//
// Date ← String

/**
 *  任意のフォーマットからNSDateを生成して返す
 *
 *  @param formatString フォーマット
 *  @param dateString   フォーマットで書かれた日付のString
 *
 *  @return NSDate
 */
+ (NSDate *)art_dateForFormatString:(NSString *)formatString dateString:(NSString *)dateString;

// date ← yyyy-MM-dd HH:mm:ss
/**
 *  APIの結果で返ってきた日付文字列をNSDateへ変換する
 *
 *  @param dateString yyyy-MM-dd HH:mm:ssのString
 *
 *  @return NSDate
 */
+ (NSDate *)art_formatForDateStringYYYYMMDD_HHMMSS:(NSString *)dateString;

// date ← yyyy-MM-dd
/**
 *  APIの結果で返ってきた日付文字列をNSDateへ変換する
 *
 *  @param dateString yyyy-MM-ddのString
 *
 *  @return NSDate
 */
+ (NSDate *)art_formatForDateStringYYYYMMDD:(NSString *)dateString;

// -------------------------------------------------------------------------------------------------------------------------------//
// String ← Date

/**
 *  自身の日付を任意文字列にして返す
 *
 *  @param formatString 取得したい日付の文字列 (yyyy-MM-dd, HH時, mm分等)
 *
 *  @return NSString
 */
- (NSString *)art_stringWithFormatString:(NSString *)formatString;

/**
 *  自身の日付を以下文字列にして返す
 *
 *  @return yyyy-MM-dd HH:mm:ssのString
 */
- (NSString *)art_stringWithFormatYYYYMMDD_HHMMSS;

/**
 *  自身の日付を以下文字列にして返す
 *
 *  @return yyyy-MM-DDのString
 */
- (NSString *)art_stringWithFormatYYYYMMDD;

/**
 *  自身の日付を以下文字列にして返す
 *
 *  @return yyyy-MMのString
 */
- (NSString *)art_stringWithFormatYYYYMM;

/**
 *  自身の日付を以下文字列にして返す
 *
 *  @return M/d H:mのString
 */
- (NSString *)art_stringWithFormatMDHM;

/**
 *  自身の日付を以下文字列にして返す
 *
 *  @return H:mmのString
 */
- (NSString *)art_stringWithFormatHMM;

/**
 *  自身の日付を以下文字列にして返す
 *
 *  @return D weekdayのString
 */
- (NSString *)art_stringWithFormatD_Weakday;

/**
 *  自身の日付を以下文字列にして返す
 *
 *  @return yyyy年M月d日のString
 */
- (NSString *)art_stringWithFormatJapaneseYYYYMD;

/**
 *  自身の日付を以下文字列にして返す
 *
 *  @return yyyy年M月のString
 */
- (NSString *)rss_stringWithFormatJapaneseYYYYM;

/**
 *  自身の日付を以下文字列にして返す
 *
 *  @return yyyy年M月d日 (weekday)のString
 */
- (NSString *)art_stringWithFormatJapaneseYYYYMD_Weakday;

- (NSString *)art_stringWithFormatJapaneseMD_HM;

- (NSString *)art_stringWithFormatJapaneseYYYYMD_HM;

// -------------------------------------------------------------------------------------------------------------------------------//
// Date ← Date

- (NSInteger)art_ageForDate;

// -------------------------------------------------------------------------------------------------------------------------------//
// Other

/**
 *  分を渡すとh時間mm分のStringを返す
 *
 *  @param minute 分数
 *
 *  @return h時間mm分のString
 */
+ (NSString *)art_japaneseTimeHMMAtMinute:(NSInteger)minute;

/**
 *  カレンダー上の昨日の日付を返す
 *
 *  @return NSDate
 */
- (NSDate *)art_yesterday;

/**
 *  カレンダー上の明日の日付を返す
 *
 *  @return NSDate
 */
- (NSDate *)art_tomorrow;

/**
 *  同月か判定
 *
 *  @param date 比較する日付
 *
 *  @return 同月ならYES
 */
- (BOOL)art_isEqualToMonth:(NSDate *)date;

@end
