//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface UIView (ART)

+ (instancetype)art_createViewByNib;

- (void)art_closeKeyboad;

- (void)art_pinSubview:(UIView *)subview toEdge:(NSLayoutAttribute)attribute;

- (void)art_pinAllEdgesOfSubview:(UIView *)subview;

@end
