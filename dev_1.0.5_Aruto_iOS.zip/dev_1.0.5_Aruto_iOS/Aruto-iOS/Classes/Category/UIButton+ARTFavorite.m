//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "UIButton+ARTFavorite.h"

@implementation UIButton (ARTFavorite)

- (BOOL)art_canChangeFavorite
{
    if (![[ARTUserManager shared] isLogined]) {
        NSError *error = [ARTUtils errorFOrType:ARTErrorTypeNeedLogin];
        [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                     message:error.localizedFailureReason
                                 buttonTitle:nil];
        [[ARTViewContainer shared] showUserAuthModalView];
        return NO;
    }
    if (![ARTUtils isReachable]) {
        NSError *error = [ARTUtils errorFOrType:ARTErrorTypeUONotReachable];
        [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                     message:error.localizedFailureReason
                                 buttonTitle:nil];
        return NO;
    }
    
    return YES;
}

- (void)art_setTitleForAddFavorite:(BOOL)addFavorite
{
    if (addFavorite) {
        [self setTitle:@"あとで見るに入れる" forState:UIControlStateNormal];
    } else {
        [self setTitle:@"あとで見るから削除" forState:UIControlStateNormal];
    }
}

- (void)art_addFavoriteForStaffId:(NSNumber *)staffId
{
    if (!staffId) { return; }
    
    __weak typeof(self) weakSelf = self;
    
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeClear];
    [[ARTTaskManager shared] addFavoriteWithStaffId:staffId completionBlock: ^(id resultObject) {
        if ([resultObject isKindOfClass:[NSError class]]) {
            NSError *error = (NSError *)resultObject;
            [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                         message:error.localizedFailureReason
                                     buttonTitle:nil];
        } else {
            [weakSelf art_setTitleForAddFavorite:NO];
        }
        [SVProgressHUD dismiss];
    }];
}

- (void)art_removeFavoriteForStaffId:(NSNumber *)staffId
{
    if (!staffId) { return; }
    
    __weak typeof(self) weakSelf = self;
    
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeClear];
    [[ARTTaskManager shared] removeFavoriteWithStaffId:staffId completionBlock: ^(id resultObject) {
        if ([resultObject isKindOfClass:[NSError class]]) {
            NSError *error = (NSError *)resultObject;
            [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                         message:error.localizedFailureReason
                                     buttonTitle:nil];
        } else {
            [weakSelf art_setTitleForAddFavorite:YES];
        }
        [SVProgressHUD dismiss];
    }];
}

- (void)art_addFavoriteForShopId:(NSNumber *)shopId
{
    if (!shopId) { return; }
    
    __weak typeof(self) weakSelf = self;
    
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeClear];
    [[ARTTaskManager shared] addFavoriteWithShopId:shopId completionBlock: ^(id resultObject) {
        if ([resultObject isKindOfClass:[NSError class]]) {
            NSError *error = (NSError *)resultObject;
            [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                         message:error.localizedFailureReason
                                     buttonTitle:nil];
        } else {
            [weakSelf art_setTitleForAddFavorite:NO];
        }
        [SVProgressHUD dismiss];
    }];
}

- (void)art_removeFavoriteForShopId:(NSNumber *)shopId
{
    if (!shopId) { return; }
    
    __weak typeof(self) weakSelf = self;
    
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeClear];
    [[ARTTaskManager shared] removeFavoriteWithShopId:shopId completionBlock: ^(id resultObject) {
        if ([resultObject isKindOfClass:[NSError class]]) {
            NSError *error = (NSError *)resultObject;
            [ARNAlert showNoActionAlertWithTitle:error.localizedDescription
                                         message:error.localizedFailureReason
                                     buttonTitle:nil];
        } else {
            [weakSelf art_setTitleForAddFavorite:YES];
        }
        [SVProgressHUD dismiss];
    }];
}

@end