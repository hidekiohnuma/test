//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import "UIView+ART.h"

@implementation UIView (ART)

+ (instancetype)art_createViewByNib
{
    return [[[UINib nibWithNibName:NSStringFromClass([self class]) bundle:nil] instantiateWithOwner:self options:nil] objectAtIndex:0];
}

- (void)art_closeKeyboad
{
    [self endEditing:YES];
}

- (void)art_pinSubview:(UIView *)subview toEdge:(NSLayoutAttribute)attribute
{
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self
                                                     attribute:attribute
                                                     relatedBy:NSLayoutRelationEqual
                                                        toItem:subview
                                                     attribute:attribute
                                                    multiplier:1.0f
                                                      constant:0.0f]];
}

- (void)art_pinAllEdgesOfSubview:(UIView *)subview
{
    [self art_pinSubview:subview toEdge:NSLayoutAttributeBottom];
    [self art_pinSubview:subview toEdge:NSLayoutAttributeTop];
    [self art_pinSubview:subview toEdge:NSLayoutAttributeLeading];
    [self art_pinSubview:subview toEdge:NSLayoutAttributeTrailing];
}

@end
