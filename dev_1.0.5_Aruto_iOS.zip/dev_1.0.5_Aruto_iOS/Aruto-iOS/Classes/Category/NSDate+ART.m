//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#if !__has_feature(objc_arc)
    #error This file must be compiled with ARC. Use -fobjc-arc flag (or convert project to ARC).
#endif

#import "NSDate+ART.h"

@implementation NSDate (ART)

+ (NSDateFormatter *)art_defaultFormatter
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setLocale:[NSLocale currentLocale]];
    [formatter setTimeZone:[NSTimeZone localTimeZone]];
    [formatter setCalendar:[[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar]];

    return formatter;
}

+ (NSArray *)art_weekSymbol
{
    return @[@"日", @"月", @"火", @"水", @"木", @"金", @"土"];
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Date ← String

+ (NSDate *)art_dateForFormatString:(NSString *)formatString dateString:(NSString *)dateString
{
    NSDateFormatter *formatter = [self art_defaultFormatter];
    [formatter setDateFormat:formatString];
    NSDate *date = [formatter dateFromString:dateString];

    return date;
}

+ (NSDate *)art_formatForDateStringYYYYMMDD_HHMMSS:(NSString *)dateString
{
    return [[self class] art_dateForFormatString:@"yyyy-MM-dd HH:mm:ss" dateString:dateString];
}

+ (NSDate *)art_formatForDateStringYYYYMMDD:(NSString *)dateString
{
    return [[self class] art_dateForFormatString:@"yyyy-MM-dd" dateString:dateString];;
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - String ← Date

- (NSString *)art_stringWithFormatString:(NSString *)formatString
{
    NSDateFormatter *formatter = [[self class] art_defaultFormatter];
    [formatter setDateFormat:formatString];
    NSString *dateString = [formatter stringFromDate:self];
    return dateString;
}

- (NSString *)art_stringWithFormatYYYYMMDD_HHMMSS
{
    return [self art_stringWithFormatString:@"yyyy-MM-dd HH:mm:ss"];
}

- (NSString *)art_stringWithFormatYYYYMMDD
{
    return [self art_stringWithFormatString:@"yyyy-MM-dd"];
}

- (NSString *)art_stringWithFormatYYYYMM
{
    return [self art_stringWithFormatString:@"yyyy-MM"];
}

- (NSString *)art_stringWithFormatMDHM
{
    return [self art_stringWithFormatString:@"M/d H:m"];
}

- (NSString *)art_stringWithFormatHMM
{
    NSCalendar       *cal        = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [cal components:(NSHourCalendarUnit | NSMinuteCalendarUnit) fromDate:self];

    return [NSString stringWithFormat:@"%2d:%02d", (unsigned int)components.hour, (unsigned int)components.minute];
}

- (NSString *)art_stringWithFormatD_Weakday
{
    NSCalendar       *cal        = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [cal components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit) fromDate:self];
    NSDate           *date       = [cal dateFromComponents:components];

    NSArray *weakdaysArray = [[self class] art_weekSymbol];

    NSDateFormatter *formatter = [[self class] art_defaultFormatter];
    // NSDateComponentsのweekdayの値は1〜7(日〜土)だから1引く
    [formatter setDateFormat:[NSString stringWithFormat:@"d %@", weakdaysArray[[components weekday] - 1]]];
    NSString *dateString = [formatter stringFromDate:date];
    return dateString;
}

- (NSString *)art_stringWithFormatJapaneseYYYYMD
{
    return [self art_stringWithFormatString:@"yyyy年M月d日"];
}

- (NSString *)rss_stringWithFormatJapaneseYYYYM
{
    NSCalendar       *cal        = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [cal components:(NSYearCalendarUnit | NSMonthCalendarUnit) fromDate:self];
    NSDate           *date       = [cal dateFromComponents:components];

    NSDateFormatter *formatter = [[self class] art_defaultFormatter];
    [formatter setDateFormat:@"yyyy年M月"];
    NSString *dateString = [formatter stringFromDate:date];
    return dateString;
}

- (NSString *)art_stringWithFormatJapaneseYYYYMD_Weakday
{
    NSCalendar       *cal        = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [cal components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekdayCalendarUnit) fromDate:self];
    NSDate           *date       = [cal dateFromComponents:components];

    NSArray *weakdaysArray = [[self class] art_weekSymbol];

    NSDateFormatter *formatter = [[self class] art_defaultFormatter];
    // NSDateComponentsのweekdayの値は1〜7(日〜土)だから1引く
    [formatter setDateFormat:[NSString stringWithFormat:@"yyyy年M月d日 (%@)", weakdaysArray[[components weekday] - 1]]];
    NSString *dateString = [formatter stringFromDate:date];
    return dateString;
}

- (NSString *)art_stringWithFormatJapaneseMD_HM
{
    return [self art_stringWithFormatString:@"M月d日 H時m分"];
}

- (NSString *)art_stringWithFormatJapaneseYYYYMD_HM
{
    return [self art_stringWithFormatString:@"yyyy年M月d日 H時m分"];
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Date ← Date

- (NSInteger)art_ageForDate
{
    NSCalendar       *cal  = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSCalendarUnit    unit = NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit;
    NSDateComponents *elap = [cal components:unit fromDate:self toDate:[NSDate date] options:0];

    return elap.year;
}

// -------------------------------------------------------------------------------------------------------------------------------//
#pragma mark - Other

+ (NSString *)art_japaneseTimeHMMAtMinute:(NSInteger)minute
{
    NSInteger hour = minute / 60;
    NSInteger minu = minute % 60;
    if (!hour) {
        return [NSString stringWithFormat:@"%d分", (unsigned int)minute];
    } else {
        return [NSString stringWithFormat:@"%d時間%d分", (unsigned int)hour, (unsigned int)minu];
    }
}

- (NSDate *)art_yesterday
{
    NSCalendar       *cal        = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [cal components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit) fromDate:self];
    components.day = components.day - 1;
    return [cal dateFromComponents:components];
}

- (NSDate *)art_tomorrow
{
    NSCalendar       *cal        = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *components = [cal components:(NSYearCalendarUnit | NSMonthCalendarUnit | NSDayCalendarUnit) fromDate:self];
    components.day = components.day + 1;
    return [cal dateFromComponents:components];
}

- (BOOL)art_isEqualToMonth:(NSDate *)date
{
    NSCalendar       *cal            = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDateComponents *selfComponents = [cal components:(NSYearCalendarUnit | NSMonthCalendarUnit) fromDate:self];
    NSDateComponents *components     = [cal components:(NSYearCalendarUnit | NSMonthCalendarUnit) fromDate:date];
    if (selfComponents.month == components.month) {
        return YES;
    } else {
        return NO;
    }
}

@end
