//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

@interface UIApplication (ARTNetworkActivityIndicator)

/**
 *  networkActivityIndicatorのカウントアップ
 */
+ (void)art_pushNetworkActivityIndicator;

/**
 *  networkActivityIndicatorのカウントダウン
 */
+ (void)art_popNetworkActivityIndicator;

/**
 *  networkActivityIndicatorのカウントリセット
 */
+ (void)art_resetNetworkActivityIndicator;

/**
 *  現在のカウント数を返す
 *
 *  @return カウント数
 */
+ (NSInteger)art_requestCount;

@end
