//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <UIKit/UIKit.h>

@interface UIButton (ARTFavorite)

- (BOOL)art_canChangeFavorite;

- (void)art_setTitleForAddFavorite:(BOOL)addFavorite;

- (void)art_addFavoriteForStaffId:(NSNumber *)staffId;
- (void)art_removeFavoriteForStaffId:(NSNumber *)staffId;

- (void)art_addFavoriteForShopId:(NSNumber *)shopId;
- (void)art_removeFavoriteForShopId:(NSNumber *)shopId;

@end
