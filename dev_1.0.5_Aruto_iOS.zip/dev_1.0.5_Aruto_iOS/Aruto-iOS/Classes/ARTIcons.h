//
//  ARTIcons.h
//  Aruto-iOS
//
//  Created by kunihara yoshihiro on 2015/01/13.
//  Copyright (c) 2015年 Aruto Corp. All rights reserved.
//

/*
#ifndef Aruto_iOS_IonIcons_ARTIcon_h
#define Aruto_iOS_IonIcons_ARTIcon_h


#endif
*/
#import <UIKit/UIKit.h>

#import "ARTIcon-codes.h"

@interface ARTIcons: NSObject

//================================
// Font and Label Methods
//================================

/*! Convenience method to get the ionicons font.
 */
+ (UIFont*)fontWithSize:(CGFloat)size;

/*!  Convenience method to make a sized-to-fit UILabel containing an icon in the given font size and color.
 */
+ (UILabel*)labelWithIcon:(NSString*)icon_name size:(CGFloat)size color:(UIColor*)color;

/*! Adjust an existing UILabel to show an ionicon.
 */
+ (void)label:(UILabel*)label setIcon:(NSString*)icon_name size:(CGFloat)size color:(UIColor*)color sizeToFit:(BOOL)shouldSizeToFit;

//================================
// Image Methods
//================================

/*! Create a UIImage of an ionocin, making the image and the icon the same size:
 */
+ (UIImage*)imageWithIcon:(NSString*)icon_name size:(CGFloat)size color:(UIColor*)color;

/*! Create a UIImage of an ionocin, and specify different sizes for the image and the icon:
 */
+ (UIImage*)imageWithIcon:(NSString*)icon_name iconColor:(UIColor*)color iconSize:(CGFloat)iconSize imageSize:(CGSize)imageSize;



@end
