//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

@interface ARTUtils : NSObject

+ (BOOL)isReachable;

+ (id)nullCheckWithObject:(id)checkObject isNumeric:(BOOL)isNumeric;

+ (NSString *)checkAndCreateDirectoryAtPath:(NSString *)path;

+ (BOOL)addSkipBackupAttributeToItemAtURL:(NSURL *)URL;

+ (UIImage *)imageWithColor:(UIColor *)color;

+ (void)showPopControllerAlertWithTitle:(NSString *)title message:(NSString *)message;

+ (UIView *)keyboardToolbarWithTarget:(id)target selector:(SEL)selector width:(float)width;

+ (NSString *)escapeString:(NSString *)aString;

+ (void)setBaseButtonStyle:(UIButton *)button;
+ (void)setBaseButtonStyleGray:(UIButton *)button;

+ (void)selectActionForView:(UIView *)view;

+ (BOOL)checkRegex:(NSInteger)stringType string:(NSString *)checkString;

+ (NSError *)uoErrorForDict:(NSDictionary *)dict;

+ (NSError *)errorFOrType:(ARTErrorType)type;

+ (void)addNotisForName:(NSString *)name block:(void (^)(NSNotification *note))block;

@end
