//  Copyright (c) 2014年 Aruto Corp. All rights reserved.

#import <Foundation/Foundation.h>

@interface ARTAnalytics : NSObject

+ (void)setupWithGATrackingId:(NSString *)trackingId;
+ (void)setupFlurryWithAppId:(NSString *)appId;

+ (void)sendGAScreenName:(NSString *)screenName;

+ (void)sendTrackWithCategoryName:(NSString *)categoryName
                       actionName:(NSString *)actionName
                        labelName:(NSString *)labelName
                            value:(NSNumber *)value;

+ (NSString *)dateToYYYYMMDDHHMM:(NSDate *)aDate;

@end
